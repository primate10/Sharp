﻿Public Class frmNumberZ

    Private Sub frmNumberZ_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        e.Cancel = True
    End Sub

    Private Sub frmNumberZ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.TopMost = True
        Me.Left = 0
        Me.Width = Screen.PrimaryScreen.Bounds.Width
        Me.TextBox1.Width = Me.Width
    End Sub
End Class