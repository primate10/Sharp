﻿Imports System.Deployment.Application
Public Class About

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub About_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If TextBox1.Tag = "shagged" Then
            Exit Sub
        End If
        Dim vno As String
        Dim myVersion As Version
        If (ApplicationDeployment.IsNetworkDeployed) Then
            Dim AD As ApplicationDeployment = ApplicationDeployment.CurrentDeployment
            myVersion = ApplicationDeployment.CurrentDeployment.CurrentVersion
            vno = myVersion.ToString
        Else
            vno = My.Application.Info.Version.ToString
        End If
        vno = "(" & vno & ")"
 
        Me.TextBox1.Text = "Sharp - Version 7 " & vno & Me.TextBox1.Text
        TextBox1.Tag = "shagged"
    End Sub
End Class