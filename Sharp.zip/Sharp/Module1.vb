﻿Module Module1
    Public twelfth() As Double = {200.0, 210.0, 225.0, 235.0, 250.0, 265.0, 280.0, 300.0, 315.0, 335.0, 355.0, 375.0, _
            400.0, 420.0, 450.0, 470.0, 500.0, 530.0, 560.0, 595.0, 630.0, 670.0, 710.0, 750.0, 800.0, 840.0, 900.0, _
            945.0, 1000.0, 1060.0, 1120.0, 1190.0, 1250.0, 1335.0, 1400.0, 1500.0, 1600.0, 1680.0, 1800.0, 1890.0, _
            2000.0, 2120.0, 2240.0, 2380.0, 2500.0, 2670.0, 2800.0, 3000.0, 3150.0, 3365.0, 3550.0, 3775.0, 4000.0, _
            4240.0, 4500.0, 4760.0, 5000.0, 5340.0, 5600.0, 6000.0, 6300.0, 6725.0, 7100.0, 7550.0, 8000.0}
    Public audiometric() As Double = {250.0, 500.0, 750.0, 1000.0, 1500.0, 2000.0, 3000.0, 4000.0, 6000.0}
    Public third() As Double = {200.0, 250.0, 315.0, 400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600.0, _
                              2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0}

    Public HomeDir As String

    Public Function dbsum(ByVal dblist() As Double)
        'Returns dbsum of list of SPL values
        Dim i As Integer
        Dim sum As Double

        sum = 0.0#
        For i = 0 To UBound(dblist)
            sum = sum + 10.0# ^ (dblist(i) / 10.0#)
        Next i
        dbsum = 10.0# * Math.Log10(sum)
    End Function

    Public Function interp1(ByVal X() As Double, ByVal Y() As Double, ByVal Xinterp() As Double)
        Dim Yinterp(Xinterp.Count - 1) As Double

        Dim i As Integer, j As Integer, xstart As Integer
        xstart = 0
        For i = 0 To Xinterp.Count - 1
            If Xinterp(i) < X(0) Or Xinterp(i) > X(X.Count - 1) Then
                Yinterp(i) = Interpolate(X(j), Y(j), X(j + 1), Y(j + 1), Xinterp(i), True) 'extrapolate at ends
            Else
                For j = xstart To X.Count - 2
                    If Xinterp(i) >= X(j) And Xinterp(i) <= X(j + 1) Then
                        Yinterp(i) = Interpolate(X(j), Y(j), X(j + 1), Y(j + 1), Xinterp(i))
                        xstart = j
                        Exit For
                    End If
                Next
            End If
        Next
        Return Yinterp
    End Function
    Public Function Interpolate(ByVal dblIndex1 As Double, _
     ByVal dblValue1 As Double, ByVal dblIndex2 As Double, _
     ByVal dblValue2 As Double, ByVal dblFindIndex As Double, _
     Optional ByVal boolExtrapolate As Boolean = True) As Double
        '********************************************************
        'This function will return the linear interpolated value for dblFindIndex
        '
        '  *------------+-----*
        '  a               c      b
        '  1               3     5
        '  10             x      50
        '
        ' To find x at c the correct syntax would be:
        ' x = Interpolate(1,10,5,50,3)
        ' and the answer would be 30
        '********************************************************
        ' Passing a value of true for boolExtrapolate will switch on
        ' extropolation if find index falls outside the bounds of index1 
        ' and index2.
        '********************************************************

        'Trap Errors
        On Error GoTo Interpolate_Error

        Dim dblUpperLimitIndex As Double
        Dim dblUpperLimitValue As Double
        Dim dblLowerLimitIndex As Double
        Dim dblLowerLimitValue As Double

        'Main Function
        If Not boolExtrapolate Then
            'We are not extrapolating so cap the returned values

            If dblIndex2 > dblIndex1 Then
                dblLowerLimitIndex = dblIndex1
                dblUpperLimitIndex = dblIndex2
                dblLowerLimitValue = dblValue1
                dblUpperLimitValue = dblValue2
            Else
                dblLowerLimitIndex = dblIndex2
                dblUpperLimitIndex = dblIndex1
                dblLowerLimitValue = dblValue2
                dblUpperLimitValue = dblValue1
            End If

            If dblFindIndex <= dblLowerLimitIndex Then
                'If FindIndex is less than or equal to index1, 
                'return value will allways be Value1
                Interpolate = dblLowerLimitValue
                GoTo Interpolate_Exit
            ElseIf dblFindIndex >= dblUpperLimitIndex Then
                'If FindIndex is greater than or equal to index2, 
                'return value will allways be Value2
                Interpolate = dblUpperLimitValue
                GoTo Interpolate_Exit
            End If

        End If

        'Perform the interpolation
        Interpolate = dblValue1 + (dblValue2 - dblValue1) * _
         (dblFindIndex - dblIndex1) / (dblIndex2 - dblIndex1)

        'Exit
Interpolate_Exit:
        Exit Function

        'Error Handling
Interpolate_Error:
        Dim Error_Location As String
        Error_Location = "Interpolate"
        MsgBox(Err.Description, vbExclamation, _
              Error_Location & ":" & Err.Number)
        Interpolate = 0
        GoTo Interpolate_Exit

    End Function
    Public Function Log2(ByVal X As Double) As Double
        Log2 = Math.Log(X) / Math.Log(2.0#)
    End Function
    Public Function GetDoubleFromStringUsingSB(ByVal theString As String) As Double
        Dim sb As New System.Text.StringBuilder(theString.Length)
        For Each ch As Char In theString
            If Char.IsDigit(ch) Then sb.Append(ch)
        Next
        Return Double.Parse(sb.ToString)
    End Function
    Function SlopeIntercept(ByVal X() As Double, ByVal Y() As Double) As Double()
        Dim SumX, SumXSquared, SumY, SumXY As Double, LSP As Double
        For I As Integer = 0 To X.Length - 1
            SumX += X(I)
            SumXSquared += X(I) * X(I)
            SumY += Y(I)
            SumXY += X(I) * Y(I)
        Next
        Dim Slope, Intercept, Determinant As Double
        Dim SI(1) As Double
        Determinant = X.Length * SumXSquared - SumX * SumX
        Slope = (X.Length * SumXY - SumY * SumX) / Determinant
        Intercept = (SumY * SumXSquared - SumX * SumXY) / Determinant
        SI(0) = Slope
        SI(1) = Intercept
        Return SI
    End Function
    Function LeastSquaresPoint(ByVal X() As Double, ByVal Y() As Double, ByVal X1 As Double) As Double
        Dim SumX, SumXSquared, SumY, SumXY As Double, LSP As Double
        For I As Integer = 0 To X.Length - 1
            SumX += X(I)
            SumXSquared += X(I) * X(I)
            SumY += Y(I)
            SumXY += X(I) * Y(I)
        Next
        Dim Slope, Intercept, Determinant As Double
        Determinant = X.Length * SumXSquared - SumX * SumX
        Slope = (X.Length * SumXY - SumY * SumX) / Determinant
        Intercept = (SumY * SumXSquared - SumX * SumXY) / Determinant

        LSP = Slope * X1 + Intercept
        Return LSP
    End Function
    Public Function FComp(ByVal Fin, ByVal SF, ByVal FCR) As Double
        FComp = (SF ^ (1 - 1 / FCR)) * (Fin ^ (1 / FCR))
    End Function

    Structure threevals
        Public fcr As Double
        Public f As Double
        Public startf As Double
    End Structure
End Module
