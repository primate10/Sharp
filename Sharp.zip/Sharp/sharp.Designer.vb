﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Sharp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Sharp))
        Me.OpenFD = New System.Windows.Forms.OpenFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SaveFD = New System.Windows.Forms.SaveFileDialog()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblXMLname = New System.Windows.Forms.Label()
        Me.PlotPanel = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbRvS = New System.Windows.Forms.ComboBox()
        Me.lblTip = New System.Windows.Forms.Label()
        Me.chkRFreqComp = New System.Windows.Forms.CheckBox()
        Me.chkLFreqComp = New System.Windows.Forms.CheckBox()
        Me.txtRFCC = New System.Windows.Forms.TextBox()
        Me.txtRFCR = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtLFCC = New System.Windows.Forms.TextBox()
        Me.txtLFCR = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbBI = New System.Windows.Forms.ComboBox()
        Me.lblBI = New System.Windows.Forms.Label()
        Me.zgc = New ZedGraph.ZedGraphControl()
        Me.cmbMFC = New System.Windows.Forms.ComboBox()
        Me.cmbSpeechType = New System.Windows.Forms.ComboBox()
        Me.cmbAidUn = New System.Windows.Forms.ComboBox()
        Me.cmbEar = New System.Windows.Forms.ComboBox()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.gpConditions = New System.Windows.Forms.GroupBox()
        Me.radSpect16 = New System.Windows.Forms.RadioButton()
        Me.radSpect15 = New System.Windows.Forms.RadioButton()
        Me.radSpect14 = New System.Windows.Forms.RadioButton()
        Me.radSpect13 = New System.Windows.Forms.RadioButton()
        Me.radSpect12 = New System.Windows.Forms.RadioButton()
        Me.radSpect11 = New System.Windows.Forms.RadioButton()
        Me.radSpect10 = New System.Windows.Forms.RadioButton()
        Me.radSpect9 = New System.Windows.Forms.RadioButton()
        Me.radSpect8 = New System.Windows.Forms.RadioButton()
        Me.radSpect7 = New System.Windows.Forms.RadioButton()
        Me.radSpect6 = New System.Windows.Forms.RadioButton()
        Me.radSpect5 = New System.Windows.Forms.RadioButton()
        Me.radSpect4 = New System.Windows.Forms.RadioButton()
        Me.radSpect3 = New System.Windows.Forms.RadioButton()
        Me.radSpect2 = New System.Windows.Forms.RadioButton()
        Me.radSpect1 = New System.Windows.Forms.RadioButton()
        Me.EditPanel = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmbTransducer = New System.Windows.Forms.ComboBox()
        Me.butClearAll = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.butExit = New System.Windows.Forms.Button()
        Me.Changed = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DOTCtl = New System.Windows.Forms.DateTimePicker()
        Me.RPanelThr = New System.Windows.Forms.Panel()
        Me.cmbStyleR = New System.Windows.Forms.ComboBox()
        Me.cmbSpeechTypeR = New System.Windows.Forms.ComboBox()
        Me.butRClear = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.RThreshLabel = New System.Windows.Forms.Label()
        Me.RThreshGrid = New System.Windows.Forms.DataGridView()
        Me.butDontSave = New System.Windows.Forms.Button()
        Me.LPanelThr = New System.Windows.Forms.Panel()
        Me.cmbSpeechTypeL = New System.Windows.Forms.ComboBox()
        Me.butLClear = New System.Windows.Forms.Button()
        Me.cmbStyleL = New System.Windows.Forms.ComboBox()
        Me.LThreshGrid = New System.Windows.Forms.DataGridView()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.LThreshLabel = New System.Windows.Forms.Label()
        Me.cmbAge = New System.Windows.Forms.ComboBox()
        Me.txtClientID = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.butFill = New System.Windows.Forms.Button()
        Me.butSaveAs = New System.Windows.Forms.Button()
        Me.LButtonCtlThr = New System.Windows.Forms.Button()
        Me.RbuttonCtlThr = New System.Windows.Forms.Button()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileEditMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileNewMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileOpenMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileSaveMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileSaveAsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FileRecentFilesMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileRecentFilesFilename = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.FileExitMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsFilenameMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsStyleMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsStyleCombo = New System.Windows.Forms.ToolStripComboBox()
        Me.SettingsShowSIIPointsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlotMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlotPrintMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlotFileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.NumbersMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpHelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpAboutMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Panel1.SuspendLayout()
        Me.PlotPanel.SuspendLayout()
        Me.gpConditions.SuspendLayout()
        Me.EditPanel.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.RPanelThr.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.RThreshGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LPanelThr.SuspendLayout()
        CType(Me.LThreshGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Panel1.Controls.Add(Me.lblXMLname)
        Me.Panel1.Location = New System.Drawing.Point(0, 678)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1200, 31)
        Me.Panel1.TabIndex = 37
        '
        'lblXMLname
        '
        Me.lblXMLname.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.lblXMLname.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblXMLname.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lblXMLname.Location = New System.Drawing.Point(0, 6)
        Me.lblXMLname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblXMLname.Name = "lblXMLname"
        Me.lblXMLname.Size = New System.Drawing.Size(1200, 25)
        Me.lblXMLname.TabIndex = 41
        Me.lblXMLname.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PlotPanel
        '
        Me.PlotPanel.BackColor = System.Drawing.Color.GreenYellow
        Me.PlotPanel.Controls.Add(Me.Label11)
        Me.PlotPanel.Controls.Add(Me.cmbRvS)
        Me.PlotPanel.Controls.Add(Me.lblTip)
        Me.PlotPanel.Controls.Add(Me.chkRFreqComp)
        Me.PlotPanel.Controls.Add(Me.chkLFreqComp)
        Me.PlotPanel.Controls.Add(Me.txtRFCC)
        Me.PlotPanel.Controls.Add(Me.txtRFCR)
        Me.PlotPanel.Controls.Add(Me.Label9)
        Me.PlotPanel.Controls.Add(Me.Label8)
        Me.PlotPanel.Controls.Add(Me.txtLFCC)
        Me.PlotPanel.Controls.Add(Me.txtLFCR)
        Me.PlotPanel.Controls.Add(Me.Label5)
        Me.PlotPanel.Controls.Add(Me.Label4)
        Me.PlotPanel.Controls.Add(Me.Label3)
        Me.PlotPanel.Controls.Add(Me.Label1)
        Me.PlotPanel.Controls.Add(Me.cmbBI)
        Me.PlotPanel.Controls.Add(Me.lblBI)
        Me.PlotPanel.Controls.Add(Me.zgc)
        Me.PlotPanel.Controls.Add(Me.cmbMFC)
        Me.PlotPanel.Controls.Add(Me.cmbSpeechType)
        Me.PlotPanel.Controls.Add(Me.cmbAidUn)
        Me.PlotPanel.Controls.Add(Me.cmbEar)
        Me.PlotPanel.Controls.Add(Me.lblCount)
        Me.PlotPanel.Controls.Add(Me.gpConditions)
        Me.PlotPanel.Location = New System.Drawing.Point(35, 33)
        Me.PlotPanel.Margin = New System.Windows.Forms.Padding(4)
        Me.PlotPanel.Name = "PlotPanel"
        Me.PlotPanel.Size = New System.Drawing.Size(1257, 638)
        Me.PlotPanel.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label11.Location = New System.Drawing.Point(1059, 95)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(43, 17)
        Me.Label11.TabIndex = 57
        Me.Label11.Text = "Mode"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmbRvS
        '
        Me.cmbRvS.FormattingEnabled = True
        Me.cmbRvS.Items.AddRange(New Object() {"Real ear", "Simulated"})
        Me.cmbRvS.Location = New System.Drawing.Point(1109, 90)
        Me.cmbRvS.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbRvS.Name = "cmbRvS"
        Me.cmbRvS.Size = New System.Drawing.Size(93, 24)
        Me.cmbRvS.TabIndex = 5
        '
        'lblTip
        '
        Me.lblTip.AutoSize = True
        Me.lblTip.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTip.Location = New System.Drawing.Point(879, 10)
        Me.lblTip.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTip.Name = "lblTip"
        Me.lblTip.Size = New System.Drawing.Size(30, 19)
        Me.lblTip.TabIndex = 55
        Me.lblTip.Text = "Tip"
        Me.lblTip.Visible = False
        '
        'chkRFreqComp
        '
        Me.chkRFreqComp.AutoSize = True
        Me.chkRFreqComp.BackColor = System.Drawing.SystemColors.Control
        Me.chkRFreqComp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkRFreqComp.Location = New System.Drawing.Point(520, 612)
        Me.chkRFreqComp.Margin = New System.Windows.Forms.Padding(4)
        Me.chkRFreqComp.Name = "chkRFreqComp"
        Me.chkRFreqComp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkRFreqComp.Size = New System.Drawing.Size(99, 21)
        Me.chkRFreqComp.TabIndex = 54
        Me.chkRFreqComp.Text = "Freq Comp"
        Me.chkRFreqComp.UseVisualStyleBackColor = False
        Me.chkRFreqComp.Visible = False
        '
        'chkLFreqComp
        '
        Me.chkLFreqComp.AutoSize = True
        Me.chkLFreqComp.BackColor = System.Drawing.SystemColors.Control
        Me.chkLFreqComp.ForeColor = System.Drawing.Color.Blue
        Me.chkLFreqComp.Location = New System.Drawing.Point(897, 127)
        Me.chkLFreqComp.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLFreqComp.Name = "chkLFreqComp"
        Me.chkLFreqComp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkLFreqComp.Size = New System.Drawing.Size(99, 21)
        Me.chkLFreqComp.TabIndex = 5
        Me.chkLFreqComp.Text = "Freq Comp"
        Me.chkLFreqComp.UseVisualStyleBackColor = False
        '
        'txtRFCC
        '
        Me.txtRFCC.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtRFCC.Location = New System.Drawing.Point(637, 612)
        Me.txtRFCC.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRFCC.Name = "txtRFCC"
        Me.txtRFCC.Size = New System.Drawing.Size(59, 22)
        Me.txtRFCC.TabIndex = 8
        Me.txtRFCC.Visible = False
        '
        'txtRFCR
        '
        Me.txtRFCR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtRFCR.Location = New System.Drawing.Point(705, 612)
        Me.txtRFCR.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRFCR.Name = "txtRFCR"
        Me.txtRFCR.Size = New System.Drawing.Size(59, 22)
        Me.txtRFCR.TabIndex = 9
        Me.txtRFCR.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Location = New System.Drawing.Point(1002, 128)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 17)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "FCC"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.Location = New System.Drawing.Point(1103, 128)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(35, 17)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "FCR"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtLFCC
        '
        Me.txtLFCC.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLFCC.ForeColor = System.Drawing.Color.Blue
        Me.txtLFCC.Location = New System.Drawing.Point(1038, 125)
        Me.txtLFCC.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLFCC.Name = "txtLFCC"
        Me.txtLFCC.Size = New System.Drawing.Size(59, 23)
        Me.txtLFCC.TabIndex = 6
        '
        'txtLFCR
        '
        Me.txtLFCR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLFCR.ForeColor = System.Drawing.Color.Blue
        Me.txtLFCR.Location = New System.Drawing.Point(1143, 125)
        Me.txtLFCR.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLFCR.Name = "txtLFCR"
        Me.txtLFCR.Size = New System.Drawing.Size(59, 23)
        Me.txtLFCR.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(1043, 62)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 17)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "Stimulus"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(889, 62)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 17)
        Me.Label4.TabIndex = 48
        Me.Label4.Text = "Speaker"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(1039, 29)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 17)
        Me.Label3.TabIndex = 47
        Me.Label3.Text = "Condition"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(921, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 17)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Ear"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmbBI
        '
        Me.cmbBI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBI.FormattingEnabled = True
        Me.cmbBI.Items.AddRange(New Object() {"Standard", "Nonsense", "Sentences"})
        Me.cmbBI.Location = New System.Drawing.Point(37, 478)
        Me.cmbBI.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbBI.Name = "cmbBI"
        Me.cmbBI.Size = New System.Drawing.Size(104, 24)
        Me.cmbBI.TabIndex = 43
        '
        'lblBI
        '
        Me.lblBI.AutoSize = True
        Me.lblBI.BackColor = System.Drawing.SystemColors.Window
        Me.lblBI.Location = New System.Drawing.Point(31, 510)
        Me.lblBI.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblBI.Name = "lblBI"
        Me.lblBI.Size = New System.Drawing.Size(115, 17)
        Me.lblBI.TabIndex = 39
        Me.lblBI.Text = "Band Importance"
        '
        'zgc
        '
        Me.zgc.Location = New System.Drawing.Point(0, 25)
        Me.zgc.Margin = New System.Windows.Forms.Padding(5)
        Me.zgc.Name = "zgc"
        Me.zgc.ScrollGrace = 0.0R
        Me.zgc.ScrollMaxX = 0.0R
        Me.zgc.ScrollMaxY = 0.0R
        Me.zgc.ScrollMaxY2 = 0.0R
        Me.zgc.ScrollMinX = 0.0R
        Me.zgc.ScrollMinY = 0.0R
        Me.zgc.ScrollMinY2 = 0.0R
        Me.zgc.Size = New System.Drawing.Size(870, 583)
        Me.zgc.TabIndex = 45
        Me.zgc.TabStop = False
        '
        'cmbMFC
        '
        Me.cmbMFC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMFC.FormattingEnabled = True
        Me.cmbMFC.Items.AddRange(New Object() {"Male", "Female", "Child"})
        Me.cmbMFC.Location = New System.Drawing.Point(954, 57)
        Me.cmbMFC.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbMFC.Name = "cmbMFC"
        Me.cmbMFC.Size = New System.Drawing.Size(76, 24)
        Me.cmbMFC.TabIndex = 3
        '
        'cmbSpeechType
        '
        Me.cmbSpeechType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSpeechType.FormattingEnabled = True
        Me.cmbSpeechType.Items.AddRange(New Object() {"Carrots", "Ear", "ISTS", "Female"})
        Me.cmbSpeechType.Location = New System.Drawing.Point(1109, 57)
        Me.cmbSpeechType.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbSpeechType.Name = "cmbSpeechType"
        Me.cmbSpeechType.Size = New System.Drawing.Size(93, 24)
        Me.cmbSpeechType.TabIndex = 4
        '
        'cmbAidUn
        '
        Me.cmbAidUn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAidUn.FormattingEnabled = True
        Me.cmbAidUn.Items.AddRange(New Object() {"Unaided", "Aided"})
        Me.cmbAidUn.Location = New System.Drawing.Point(1109, 24)
        Me.cmbAidUn.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbAidUn.Name = "cmbAidUn"
        Me.cmbAidUn.Size = New System.Drawing.Size(93, 24)
        Me.cmbAidUn.TabIndex = 2
        '
        'cmbEar
        '
        Me.cmbEar.BackColor = System.Drawing.SystemColors.Window
        Me.cmbEar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbEar.FormattingEnabled = True
        Me.cmbEar.Items.AddRange(New Object() {"Left", "Right"})
        Me.cmbEar.Location = New System.Drawing.Point(954, 24)
        Me.cmbEar.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbEar.Name = "cmbEar"
        Me.cmbEar.Size = New System.Drawing.Size(76, 24)
        Me.cmbEar.TabIndex = 1
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(872, 615)
        Me.lblCount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(16, 17)
        Me.lblCount.TabIndex = 36
        Me.lblCount.Text = "0"
        Me.lblCount.Visible = False
        '
        'gpConditions
        '
        Me.gpConditions.BackColor = System.Drawing.SystemColors.Control
        Me.gpConditions.Controls.Add(Me.radSpect16)
        Me.gpConditions.Controls.Add(Me.radSpect15)
        Me.gpConditions.Controls.Add(Me.radSpect14)
        Me.gpConditions.Controls.Add(Me.radSpect13)
        Me.gpConditions.Controls.Add(Me.radSpect12)
        Me.gpConditions.Controls.Add(Me.radSpect11)
        Me.gpConditions.Controls.Add(Me.radSpect10)
        Me.gpConditions.Controls.Add(Me.radSpect9)
        Me.gpConditions.Controls.Add(Me.radSpect8)
        Me.gpConditions.Controls.Add(Me.radSpect7)
        Me.gpConditions.Controls.Add(Me.radSpect6)
        Me.gpConditions.Controls.Add(Me.radSpect5)
        Me.gpConditions.Controls.Add(Me.radSpect4)
        Me.gpConditions.Controls.Add(Me.radSpect3)
        Me.gpConditions.Controls.Add(Me.radSpect2)
        Me.gpConditions.Controls.Add(Me.radSpect1)
        Me.gpConditions.Location = New System.Drawing.Point(923, 159)
        Me.gpConditions.Margin = New System.Windows.Forms.Padding(4)
        Me.gpConditions.Name = "gpConditions"
        Me.gpConditions.Padding = New System.Windows.Forms.Padding(4)
        Me.gpConditions.Size = New System.Drawing.Size(281, 460)
        Me.gpConditions.TabIndex = 10
        Me.gpConditions.TabStop = False
        Me.gpConditions.Text = "Situation"
        '
        'radSpect16
        '
        Me.radSpect16.AutoSize = True
        Me.radSpect16.Location = New System.Drawing.Point(8, 430)
        Me.radSpect16.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect16.Name = "radSpect16"
        Me.radSpect16.Size = New System.Drawing.Size(111, 21)
        Me.radSpect16.TabIndex = 32
        Me.radSpect16.TabStop = True
        Me.radSpect16.Text = "Loud speech"
        Me.radSpect16.UseVisualStyleBackColor = True
        '
        'radSpect15
        '
        Me.radSpect15.AutoSize = True
        Me.radSpect15.Location = New System.Drawing.Point(8, 402)
        Me.radSpect15.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect15.Name = "radSpect15"
        Me.radSpect15.Size = New System.Drawing.Size(128, 21)
        Me.radSpect15.TabIndex = 31
        Me.radSpect15.TabStop = True
        Me.radSpect15.Text = "Medium speech"
        Me.radSpect15.UseVisualStyleBackColor = True
        '
        'radSpect14
        '
        Me.radSpect14.AutoSize = True
        Me.radSpect14.Location = New System.Drawing.Point(8, 375)
        Me.radSpect14.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect14.Name = "radSpect14"
        Me.radSpect14.Size = New System.Drawing.Size(104, 21)
        Me.radSpect14.TabIndex = 30
        Me.radSpect14.TabStop = True
        Me.radSpect14.Text = "Soft speech"
        Me.radSpect14.UseVisualStyleBackColor = True
        '
        'radSpect13
        '
        Me.radSpect13.AutoSize = True
        Me.radSpect13.Location = New System.Drawing.Point(8, 348)
        Me.radSpect13.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect13.Name = "radSpect13"
        Me.radSpect13.Size = New System.Drawing.Size(242, 21)
        Me.radSpect13.TabIndex = 29
        Me.radSpect13.TabStop = True
        Me.radSpect13.Text = "Average conversation at 4 meters"
        Me.radSpect13.UseVisualStyleBackColor = True
        '
        'radSpect12
        '
        Me.radSpect12.AutoSize = True
        Me.radSpect12.Location = New System.Drawing.Point(8, 321)
        Me.radSpect12.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect12.Name = "radSpect12"
        Me.radSpect12.Size = New System.Drawing.Size(242, 21)
        Me.radSpect12.TabIndex = 28
        Me.radSpect12.TabStop = True
        Me.radSpect12.Text = "Average conversation at 4 meters"
        Me.radSpect12.UseVisualStyleBackColor = True
        '
        'radSpect11
        '
        Me.radSpect11.AutoSize = True
        Me.radSpect11.Location = New System.Drawing.Point(8, 294)
        Me.radSpect11.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect11.Name = "radSpect11"
        Me.radSpect11.Size = New System.Drawing.Size(242, 21)
        Me.radSpect11.TabIndex = 27
        Me.radSpect11.TabStop = True
        Me.radSpect11.Text = "Average conversation at 4 meters"
        Me.radSpect11.UseVisualStyleBackColor = True
        '
        'radSpect10
        '
        Me.radSpect10.AutoSize = True
        Me.radSpect10.Location = New System.Drawing.Point(8, 267)
        Me.radSpect10.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect10.Name = "radSpect10"
        Me.radSpect10.Size = New System.Drawing.Size(242, 21)
        Me.radSpect10.TabIndex = 26
        Me.radSpect10.TabStop = True
        Me.radSpect10.Text = "Average conversation at 4 meters"
        Me.radSpect10.UseVisualStyleBackColor = True
        '
        'radSpect9
        '
        Me.radSpect9.AutoSize = True
        Me.radSpect9.Location = New System.Drawing.Point(8, 240)
        Me.radSpect9.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect9.Name = "radSpect9"
        Me.radSpect9.Size = New System.Drawing.Size(242, 21)
        Me.radSpect9.TabIndex = 25
        Me.radSpect9.TabStop = True
        Me.radSpect9.Text = "Average conversation at 4 meters"
        Me.radSpect9.UseVisualStyleBackColor = True
        '
        'radSpect8
        '
        Me.radSpect8.AutoSize = True
        Me.radSpect8.Location = New System.Drawing.Point(8, 213)
        Me.radSpect8.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect8.Name = "radSpect8"
        Me.radSpect8.Size = New System.Drawing.Size(242, 21)
        Me.radSpect8.TabIndex = 24
        Me.radSpect8.TabStop = True
        Me.radSpect8.Text = "Average conversation at 4 meters"
        Me.radSpect8.UseVisualStyleBackColor = True
        '
        'radSpect7
        '
        Me.radSpect7.AutoSize = True
        Me.radSpect7.Location = New System.Drawing.Point(8, 186)
        Me.radSpect7.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect7.Name = "radSpect7"
        Me.radSpect7.Size = New System.Drawing.Size(242, 21)
        Me.radSpect7.TabIndex = 23
        Me.radSpect7.TabStop = True
        Me.radSpect7.Text = "Average conversation at 4 meters"
        Me.radSpect7.UseVisualStyleBackColor = True
        '
        'radSpect6
        '
        Me.radSpect6.AutoSize = True
        Me.radSpect6.Location = New System.Drawing.Point(8, 159)
        Me.radSpect6.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect6.Name = "radSpect6"
        Me.radSpect6.Size = New System.Drawing.Size(242, 21)
        Me.radSpect6.TabIndex = 22
        Me.radSpect6.TabStop = True
        Me.radSpect6.Text = "Average conversation at 4 meters"
        Me.radSpect6.UseVisualStyleBackColor = True
        '
        'radSpect5
        '
        Me.radSpect5.AutoSize = True
        Me.radSpect5.Location = New System.Drawing.Point(8, 132)
        Me.radSpect5.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect5.Name = "radSpect5"
        Me.radSpect5.Size = New System.Drawing.Size(242, 21)
        Me.radSpect5.TabIndex = 21
        Me.radSpect5.TabStop = True
        Me.radSpect5.Text = "Average conversation at 4 meters"
        Me.radSpect5.UseVisualStyleBackColor = True
        '
        'radSpect4
        '
        Me.radSpect4.AutoSize = True
        Me.radSpect4.Location = New System.Drawing.Point(8, 105)
        Me.radSpect4.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect4.Name = "radSpect4"
        Me.radSpect4.Size = New System.Drawing.Size(242, 21)
        Me.radSpect4.TabIndex = 20
        Me.radSpect4.TabStop = True
        Me.radSpect4.Text = "Average conversation at 4 meters"
        Me.radSpect4.UseVisualStyleBackColor = True
        '
        'radSpect3
        '
        Me.radSpect3.AutoSize = True
        Me.radSpect3.Location = New System.Drawing.Point(8, 78)
        Me.radSpect3.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect3.Name = "radSpect3"
        Me.radSpect3.Size = New System.Drawing.Size(242, 21)
        Me.radSpect3.TabIndex = 19
        Me.radSpect3.TabStop = True
        Me.radSpect3.Text = "Average conversation at 4 meters"
        Me.radSpect3.UseVisualStyleBackColor = True
        '
        'radSpect2
        '
        Me.radSpect2.AutoSize = True
        Me.radSpect2.Location = New System.Drawing.Point(8, 50)
        Me.radSpect2.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect2.Name = "radSpect2"
        Me.radSpect2.Size = New System.Drawing.Size(242, 21)
        Me.radSpect2.TabIndex = 18
        Me.radSpect2.TabStop = True
        Me.radSpect2.Text = "Average conversation at 4 meters"
        Me.radSpect2.UseVisualStyleBackColor = True
        '
        'radSpect1
        '
        Me.radSpect1.AutoSize = True
        Me.radSpect1.Location = New System.Drawing.Point(8, 23)
        Me.radSpect1.Margin = New System.Windows.Forms.Padding(4)
        Me.radSpect1.Name = "radSpect1"
        Me.radSpect1.Size = New System.Drawing.Size(242, 21)
        Me.radSpect1.TabIndex = 17
        Me.radSpect1.TabStop = True
        Me.radSpect1.Text = "Average conversation at 4 meters"
        Me.radSpect1.UseVisualStyleBackColor = True
        '
        'EditPanel
        '
        Me.EditPanel.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.EditPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.EditPanel.Controls.Add(Me.Label10)
        Me.EditPanel.Controls.Add(Me.cmbTransducer)
        Me.EditPanel.Controls.Add(Me.butClearAll)
        Me.EditPanel.Controls.Add(Me.Panel2)
        Me.EditPanel.Controls.Add(Me.Changed)
        Me.EditPanel.Controls.Add(Me.Label2)
        Me.EditPanel.Controls.Add(Me.DOTCtl)
        Me.EditPanel.Controls.Add(Me.RPanelThr)
        Me.EditPanel.Controls.Add(Me.butDontSave)
        Me.EditPanel.Controls.Add(Me.LPanelThr)
        Me.EditPanel.Controls.Add(Me.cmbAge)
        Me.EditPanel.Controls.Add(Me.txtClientID)
        Me.EditPanel.Controls.Add(Me.Label7)
        Me.EditPanel.Controls.Add(Me.Label12)
        Me.EditPanel.Controls.Add(Me.butFill)
        Me.EditPanel.Controls.Add(Me.butSaveAs)
        Me.EditPanel.Controls.Add(Me.LButtonCtlThr)
        Me.EditPanel.Controls.Add(Me.RbuttonCtlThr)
        Me.EditPanel.Location = New System.Drawing.Point(4, 188)
        Me.EditPanel.Margin = New System.Windows.Forms.Padding(4)
        Me.EditPanel.Name = "EditPanel"
        Me.EditPanel.Size = New System.Drawing.Size(1018, 468)
        Me.EditPanel.TabIndex = 39
        Me.EditPanel.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(775, 219)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(81, 17)
        Me.Label10.TabIndex = 62
        Me.Label10.Text = "Transducer"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbTransducer
        '
        Me.cmbTransducer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTransducer.FormattingEnabled = True
        Me.cmbTransducer.Items.AddRange(New Object() {"Insert", "Phones"})
        Me.cmbTransducer.Location = New System.Drawing.Point(863, 212)
        Me.cmbTransducer.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbTransducer.Name = "cmbTransducer"
        Me.cmbTransducer.Size = New System.Drawing.Size(111, 24)
        Me.cmbTransducer.TabIndex = 61
        '
        'butClearAll
        '
        Me.butClearAll.Location = New System.Drawing.Point(859, 368)
        Me.butClearAll.Margin = New System.Windows.Forms.Padding(4)
        Me.butClearAll.Name = "butClearAll"
        Me.butClearAll.Size = New System.Drawing.Size(92, 26)
        Me.butClearAll.TabIndex = 60
        Me.butClearAll.Text = "ClearAll"
        Me.butClearAll.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.butExit)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1017, 34)
        Me.Panel2.TabIndex = 59
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(16, 9)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(167, 20)
        Me.Label6.TabIndex = 60
        Me.Label6.Text = "Enter data by hand"
        '
        'butExit
        '
        Me.butExit.BackColor = System.Drawing.Color.Red
        Me.butExit.Font = New System.Drawing.Font("Marlett", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.butExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.butExit.Location = New System.Drawing.Point(981, 4)
        Me.butExit.Margin = New System.Windows.Forms.Padding(4)
        Me.butExit.Name = "butExit"
        Me.butExit.Size = New System.Drawing.Size(32, 28)
        Me.butExit.TabIndex = 1
        Me.butExit.TabStop = False
        Me.butExit.Text = "r"
        Me.butExit.UseVisualStyleBackColor = False
        '
        'Changed
        '
        Me.Changed.AutoSize = True
        Me.Changed.Enabled = False
        Me.Changed.Location = New System.Drawing.Point(993, 446)
        Me.Changed.Margin = New System.Windows.Forms.Padding(4)
        Me.Changed.Name = "Changed"
        Me.Changed.Size = New System.Drawing.Size(18, 17)
        Me.Changed.TabIndex = 57
        Me.Changed.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(773, 161)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 17)
        Me.Label2.TabIndex = 56
        Me.Label2.Text = "Test Date"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DOTCtl
        '
        Me.DOTCtl.CustomFormat = ""
        Me.DOTCtl.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DOTCtl.Location = New System.Drawing.Point(860, 156)
        Me.DOTCtl.Margin = New System.Windows.Forms.Padding(4)
        Me.DOTCtl.Name = "DOTCtl"
        Me.DOTCtl.Size = New System.Drawing.Size(111, 22)
        Me.DOTCtl.TabIndex = 45
        '
        'RPanelThr
        '
        Me.RPanelThr.BackColor = System.Drawing.Color.IndianRed
        Me.RPanelThr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.RPanelThr.Controls.Add(Me.cmbStyleR)
        Me.RPanelThr.Controls.Add(Me.cmbSpeechTypeR)
        Me.RPanelThr.Controls.Add(Me.butRClear)
        Me.RPanelThr.Controls.Add(Me.Panel3)
        Me.RPanelThr.Controls.Add(Me.RThreshGrid)
        Me.RPanelThr.Location = New System.Drawing.Point(19, 98)
        Me.RPanelThr.Margin = New System.Windows.Forms.Padding(4)
        Me.RPanelThr.Name = "RPanelThr"
        Me.RPanelThr.Size = New System.Drawing.Size(722, 296)
        Me.RPanelThr.TabIndex = 52
        '
        'cmbStyleR
        '
        Me.cmbStyleR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStyleR.FormattingEnabled = True
        Me.cmbStyleR.Items.AddRange(New Object() {"BTE", "ITE", "CIC"})
        Me.cmbStyleR.Location = New System.Drawing.Point(615, 41)
        Me.cmbStyleR.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbStyleR.Name = "cmbStyleR"
        Me.cmbStyleR.Size = New System.Drawing.Size(91, 24)
        Me.cmbStyleR.TabIndex = 57
        '
        'cmbSpeechTypeR
        '
        Me.cmbSpeechTypeR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSpeechTypeR.FormattingEnabled = True
        Me.cmbSpeechTypeR.Items.AddRange(New Object() {"Carrots", "Ear", "ISTA", "Female"})
        Me.cmbSpeechTypeR.Location = New System.Drawing.Point(615, 74)
        Me.cmbSpeechTypeR.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbSpeechTypeR.Name = "cmbSpeechTypeR"
        Me.cmbSpeechTypeR.Size = New System.Drawing.Size(91, 24)
        Me.cmbSpeechTypeR.TabIndex = 56
        '
        'butRClear
        '
        Me.butRClear.Location = New System.Drawing.Point(628, 260)
        Me.butRClear.Margin = New System.Windows.Forms.Padding(4)
        Me.butRClear.Name = "butRClear"
        Me.butRClear.Size = New System.Drawing.Size(61, 26)
        Me.butRClear.TabIndex = 55
        Me.butRClear.Text = "Clear"
        Me.butRClear.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel3.Controls.Add(Me.RThreshLabel)
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(833, 28)
        Me.Panel3.TabIndex = 21
        '
        'RThreshLabel
        '
        Me.RThreshLabel.AutoSize = True
        Me.RThreshLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RThreshLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.RThreshLabel.Location = New System.Drawing.Point(401, 4)
        Me.RThreshLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.RThreshLabel.Name = "RThreshLabel"
        Me.RThreshLabel.Size = New System.Drawing.Size(53, 20)
        Me.RThreshLabel.TabIndex = 0
        Me.RThreshLabel.Text = "Right"
        Me.RThreshLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RThreshGrid
        '
        Me.RThreshGrid.AllowUserToAddRows = False
        Me.RThreshGrid.AllowUserToDeleteRows = False
        Me.RThreshGrid.AllowUserToResizeColumns = False
        Me.RThreshGrid.AllowUserToResizeRows = False
        Me.RThreshGrid.ColumnHeadersHeight = 18
        Me.RThreshGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.RThreshGrid.Location = New System.Drawing.Point(-1, 28)
        Me.RThreshGrid.Margin = New System.Windows.Forms.Padding(4)
        Me.RThreshGrid.MultiSelect = False
        Me.RThreshGrid.Name = "RThreshGrid"
        Me.RThreshGrid.RowHeadersWidth = 75
        Me.RThreshGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.RThreshGrid.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.RThreshGrid.Size = New System.Drawing.Size(267, 123)
        Me.RThreshGrid.TabIndex = 19
        '
        'butDontSave
        '
        Me.butDontSave.Location = New System.Drawing.Point(192, 415)
        Me.butDontSave.Margin = New System.Windows.Forms.Padding(4)
        Me.butDontSave.Name = "butDontSave"
        Me.butDontSave.Size = New System.Drawing.Size(69, 30)
        Me.butDontSave.TabIndex = 47
        Me.butDontSave.TabStop = False
        Me.butDontSave.Text = "Close"
        Me.butDontSave.UseVisualStyleBackColor = True
        Me.butDontSave.Visible = False
        '
        'LPanelThr
        '
        Me.LPanelThr.BackColor = System.Drawing.Color.RoyalBlue
        Me.LPanelThr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LPanelThr.Controls.Add(Me.cmbSpeechTypeL)
        Me.LPanelThr.Controls.Add(Me.butLClear)
        Me.LPanelThr.Controls.Add(Me.cmbStyleL)
        Me.LPanelThr.Controls.Add(Me.LThreshGrid)
        Me.LPanelThr.Controls.Add(Me.Panel5)
        Me.LPanelThr.Location = New System.Drawing.Point(53, 111)
        Me.LPanelThr.Margin = New System.Windows.Forms.Padding(4)
        Me.LPanelThr.Name = "LPanelThr"
        Me.LPanelThr.Size = New System.Drawing.Size(722, 296)
        Me.LPanelThr.TabIndex = 48
        '
        'cmbSpeechTypeL
        '
        Me.cmbSpeechTypeL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSpeechTypeL.FormattingEnabled = True
        Me.cmbSpeechTypeL.Items.AddRange(New Object() {"Carrots", "Ear", "ISTA", "Female"})
        Me.cmbSpeechTypeL.Location = New System.Drawing.Point(615, 74)
        Me.cmbSpeechTypeL.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbSpeechTypeL.Name = "cmbSpeechTypeL"
        Me.cmbSpeechTypeL.Size = New System.Drawing.Size(91, 24)
        Me.cmbSpeechTypeL.TabIndex = 56
        '
        'butLClear
        '
        Me.butLClear.Location = New System.Drawing.Point(628, 260)
        Me.butLClear.Margin = New System.Windows.Forms.Padding(4)
        Me.butLClear.Name = "butLClear"
        Me.butLClear.Size = New System.Drawing.Size(61, 26)
        Me.butLClear.TabIndex = 55
        Me.butLClear.Text = "Clear"
        Me.butLClear.UseVisualStyleBackColor = True
        '
        'cmbStyleL
        '
        Me.cmbStyleL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStyleL.FormattingEnabled = True
        Me.cmbStyleL.Items.AddRange(New Object() {"BTE", "ITE", "CIC"})
        Me.cmbStyleL.Location = New System.Drawing.Point(615, 41)
        Me.cmbStyleL.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbStyleL.Name = "cmbStyleL"
        Me.cmbStyleL.Size = New System.Drawing.Size(91, 24)
        Me.cmbStyleL.TabIndex = 21
        '
        'LThreshGrid
        '
        Me.LThreshGrid.AllowUserToAddRows = False
        Me.LThreshGrid.AllowUserToDeleteRows = False
        Me.LThreshGrid.AllowUserToResizeColumns = False
        Me.LThreshGrid.AllowUserToResizeRows = False
        Me.LThreshGrid.ColumnHeadersHeight = 18
        Me.LThreshGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.LThreshGrid.Location = New System.Drawing.Point(-1, 28)
        Me.LThreshGrid.Margin = New System.Windows.Forms.Padding(4)
        Me.LThreshGrid.MultiSelect = False
        Me.LThreshGrid.Name = "LThreshGrid"
        Me.LThreshGrid.RowHeadersWidth = 75
        Me.LThreshGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.LThreshGrid.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.LThreshGrid.Size = New System.Drawing.Size(267, 123)
        Me.LThreshGrid.TabIndex = 20
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.Controls.Add(Me.LThreshLabel)
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(833, 28)
        Me.Panel5.TabIndex = 18
        '
        'LThreshLabel
        '
        Me.LThreshLabel.AutoSize = True
        Me.LThreshLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LThreshLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LThreshLabel.Location = New System.Drawing.Point(401, 4)
        Me.LThreshLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LThreshLabel.Name = "LThreshLabel"
        Me.LThreshLabel.Size = New System.Drawing.Size(42, 20)
        Me.LThreshLabel.TabIndex = 0
        Me.LThreshLabel.Text = "Left"
        Me.LThreshLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbAge
        '
        Me.cmbAge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAge.FormattingEnabled = True
        Me.cmbAge.Location = New System.Drawing.Point(860, 127)
        Me.cmbAge.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbAge.Name = "cmbAge"
        Me.cmbAge.Size = New System.Drawing.Size(111, 24)
        Me.cmbAge.TabIndex = 44
        '
        'txtClientID
        '
        Me.txtClientID.Location = New System.Drawing.Point(860, 97)
        Me.txtClientID.Margin = New System.Windows.Forms.Padding(4)
        Me.txtClientID.Name = "txtClientID"
        Me.txtClientID.Size = New System.Drawing.Size(111, 22)
        Me.txtClientID.TabIndex = 43
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(775, 103)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 17)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Client ID"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(775, 132)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 17)
        Me.Label12.TabIndex = 38
        Me.Label12.Text = "Age"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'butFill
        '
        Me.butFill.Location = New System.Drawing.Point(140, 415)
        Me.butFill.Margin = New System.Windows.Forms.Padding(4)
        Me.butFill.Name = "butFill"
        Me.butFill.Size = New System.Drawing.Size(44, 30)
        Me.butFill.TabIndex = 46
        Me.butFill.TabStop = False
        Me.butFill.Text = "Fill"
        Me.butFill.UseVisualStyleBackColor = True
        Me.butFill.Visible = False
        '
        'butSaveAs
        '
        Me.butSaveAs.Location = New System.Drawing.Point(460, 415)
        Me.butSaveAs.Margin = New System.Windows.Forms.Padding(4)
        Me.butSaveAs.Name = "butSaveAs"
        Me.butSaveAs.Size = New System.Drawing.Size(69, 30)
        Me.butSaveAs.TabIndex = 48
        Me.butSaveAs.TabStop = False
        Me.butSaveAs.Text = "Save"
        Me.butSaveAs.UseVisualStyleBackColor = True
        '
        'LButtonCtlThr
        '
        Me.LButtonCtlThr.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LButtonCtlThr.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LButtonCtlThr.Location = New System.Drawing.Point(89, 71)
        Me.LButtonCtlThr.Margin = New System.Windows.Forms.Padding(4)
        Me.LButtonCtlThr.Name = "LButtonCtlThr"
        Me.LButtonCtlThr.Size = New System.Drawing.Size(44, 28)
        Me.LButtonCtlThr.TabIndex = 51
        Me.LButtonCtlThr.TabStop = False
        Me.LButtonCtlThr.Text = "L"
        Me.LButtonCtlThr.UseVisualStyleBackColor = False
        '
        'RbuttonCtlThr
        '
        Me.RbuttonCtlThr.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RbuttonCtlThr.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.RbuttonCtlThr.Location = New System.Drawing.Point(48, 71)
        Me.RbuttonCtlThr.Margin = New System.Windows.Forms.Padding(4)
        Me.RbuttonCtlThr.Name = "RbuttonCtlThr"
        Me.RbuttonCtlThr.Size = New System.Drawing.Size(44, 28)
        Me.RbuttonCtlThr.TabIndex = 50
        Me.RbuttonCtlThr.TabStop = False
        Me.RbuttonCtlThr.Text = "R"
        Me.RbuttonCtlThr.UseVisualStyleBackColor = False
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileEditMenu, Me.FileNewMenu, Me.FileOpenMenu, Me.FileSaveMenu, Me.FileSaveAsMenu, Me.ToolStripSeparator1, Me.FileRecentFilesMenu, Me.ToolStripSeparator2, Me.FileExitMenu})
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(44, 24)
        Me.FileMenu.Text = "File"
        '
        'FileEditMenu
        '
        Me.FileEditMenu.Name = "FileEditMenu"
        Me.FileEditMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileEditMenu.Text = "Edit"
        '
        'FileNewMenu
        '
        Me.FileNewMenu.Name = "FileNewMenu"
        Me.FileNewMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileNewMenu.Text = "New"
        '
        'FileOpenMenu
        '
        Me.FileOpenMenu.Name = "FileOpenMenu"
        Me.FileOpenMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileOpenMenu.Text = "Open"
        '
        'FileSaveMenu
        '
        Me.FileSaveMenu.Name = "FileSaveMenu"
        Me.FileSaveMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileSaveMenu.Text = "Save"
        '
        'FileSaveAsMenu
        '
        Me.FileSaveAsMenu.Name = "FileSaveAsMenu"
        Me.FileSaveAsMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileSaveAsMenu.Text = "SaveAs"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(153, 6)
        '
        'FileRecentFilesMenu
        '
        Me.FileRecentFilesMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileRecentFilesFilename})
        Me.FileRecentFilesMenu.Name = "FileRecentFilesMenu"
        Me.FileRecentFilesMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileRecentFilesMenu.Text = "Recent Files"
        '
        'FileRecentFilesFilename
        '
        Me.FileRecentFilesFilename.Name = "FileRecentFilesFilename"
        Me.FileRecentFilesFilename.Size = New System.Drawing.Size(69, 22)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(153, 6)
        '
        'FileExitMenu
        '
        Me.FileExitMenu.Name = "FileExitMenu"
        Me.FileExitMenu.Size = New System.Drawing.Size(156, 24)
        Me.FileExitMenu.Text = "Exit"
        '
        'SettingsMenu
        '
        Me.SettingsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsFilenameMenu, Me.SettingsStyleMenu, Me.SettingsShowSIIPointsMenu})
        Me.SettingsMenu.Name = "SettingsMenu"
        Me.SettingsMenu.Size = New System.Drawing.Size(74, 24)
        Me.SettingsMenu.Text = "Settings"
        '
        'SettingsFilenameMenu
        '
        Me.SettingsFilenameMenu.CheckOnClick = True
        Me.SettingsFilenameMenu.Name = "SettingsFilenameMenu"
        Me.SettingsFilenameMenu.Size = New System.Drawing.Size(235, 24)
        Me.SettingsFilenameMenu.Text = "Show filename in graph"
        '
        'SettingsStyleMenu
        '
        Me.SettingsStyleMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsStyleCombo})
        Me.SettingsStyleMenu.Name = "SettingsStyleMenu"
        Me.SettingsStyleMenu.Size = New System.Drawing.Size(235, 24)
        Me.SettingsStyleMenu.Text = "Graph style"
        '
        'SettingsStyleCombo
        '
        Me.SettingsStyleCombo.AutoCompleteCustomSource.AddRange(New String() {"Solid", "Hatched"})
        Me.SettingsStyleCombo.Items.AddRange(New Object() {"Solid", "Hatched"})
        Me.SettingsStyleCombo.Name = "SettingsStyleCombo"
        Me.SettingsStyleCombo.Size = New System.Drawing.Size(75, 28)
        '
        'SettingsShowSIIPointsMenu
        '
        Me.SettingsShowSIIPointsMenu.CheckOnClick = True
        Me.SettingsShowSIIPointsMenu.Name = "SettingsShowSIIPointsMenu"
        Me.SettingsShowSIIPointsMenu.Size = New System.Drawing.Size(235, 24)
        Me.SettingsShowSIIPointsMenu.Text = "Show SII points"
        '
        'PlotMenu
        '
        Me.PlotMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlotPrintMenu, Me.PlotFileMenu})
        Me.PlotMenu.Name = "PlotMenu"
        Me.PlotMenu.Size = New System.Drawing.Size(51, 24)
        Me.PlotMenu.Text = "Print"
        '
        'PlotPrintMenu
        '
        Me.PlotPrintMenu.Name = "PlotPrintMenu"
        Me.PlotPrintMenu.Size = New System.Drawing.Size(130, 24)
        Me.PlotPrintMenu.Text = "Printer..."
        '
        'PlotFileMenu
        '
        Me.PlotFileMenu.Name = "PlotFileMenu"
        Me.PlotFileMenu.Size = New System.Drawing.Size(130, 24)
        Me.PlotFileMenu.Text = "File..."
        '
        'NumbersMenu
        '
        Me.NumbersMenu.Name = "NumbersMenu"
        Me.NumbersMenu.Size = New System.Drawing.Size(81, 24)
        Me.NumbersMenu.Text = "Numbers"
        '
        'HelpMenu
        '
        Me.HelpMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpHelpMenu, Me.HelpAboutMenu})
        Me.HelpMenu.Name = "HelpMenu"
        Me.HelpMenu.Size = New System.Drawing.Size(53, 24)
        Me.HelpMenu.Text = "Help"
        '
        'HelpHelpMenu
        '
        Me.HelpHelpMenu.Name = "HelpHelpMenu"
        Me.HelpHelpMenu.Size = New System.Drawing.Size(127, 24)
        Me.HelpHelpMenu.Text = "Manual"
        '
        'HelpAboutMenu
        '
        Me.HelpAboutMenu.Name = "HelpAboutMenu"
        Me.HelpAboutMenu.Size = New System.Drawing.Size(127, 24)
        Me.HelpAboutMenu.Text = "About"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.SettingsMenu, Me.PlotMenu, Me.NumbersMenu, Me.HelpMenu})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1262, 28)
        Me.MenuStrip1.TabIndex = 36
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Sharp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1262, 709)
        Me.Controls.Add(Me.EditPanel)
        Me.Controls.Add(Me.PlotPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Sharp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sharp"
        Me.Panel1.ResumeLayout(False)
        Me.PlotPanel.ResumeLayout(False)
        Me.PlotPanel.PerformLayout()
        Me.gpConditions.ResumeLayout(False)
        Me.gpConditions.PerformLayout()
        Me.EditPanel.ResumeLayout(False)
        Me.EditPanel.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.RPanelThr.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.RThreshGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LPanelThr.ResumeLayout(False)
        CType(Me.LThreshGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFD As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents SaveFD As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PlotPanel As System.Windows.Forms.Panel
    Friend WithEvents zgc As ZedGraph.ZedGraphControl
    Friend WithEvents cmbMFC As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSpeechType As System.Windows.Forms.ComboBox
    Friend WithEvents cmbAidUn As System.Windows.Forms.ComboBox
    Friend WithEvents lblBI As System.Windows.Forms.Label
    Friend WithEvents cmbBI As System.Windows.Forms.ComboBox
    Friend WithEvents cmbEar As System.Windows.Forms.ComboBox
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents gpConditions As System.Windows.Forms.GroupBox
    Friend WithEvents radSpect16 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect15 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect14 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect13 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect12 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect11 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect10 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect9 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect8 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect7 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect6 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect5 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect4 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect3 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect2 As System.Windows.Forms.RadioButton
    Friend WithEvents radSpect1 As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents EditPanel As System.Windows.Forms.Panel
    Friend WithEvents cmbAge As System.Windows.Forms.ComboBox
    Friend WithEvents txtClientID As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents butFill As System.Windows.Forms.Button
    Friend WithEvents butSaveAs As System.Windows.Forms.Button
    Friend WithEvents LPanelThr As System.Windows.Forms.Panel
    Friend WithEvents cmbStyleL As System.Windows.Forms.ComboBox
    Friend WithEvents LThreshGrid As System.Windows.Forms.DataGridView
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents LThreshLabel As System.Windows.Forms.Label
    Friend WithEvents lblXMLname As System.Windows.Forms.Label
    Friend WithEvents butDontSave As System.Windows.Forms.Button
    Friend WithEvents LButtonCtlThr As System.Windows.Forms.Button
    Friend WithEvents RbuttonCtlThr As System.Windows.Forms.Button
    Friend WithEvents RPanelThr As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents RThreshLabel As System.Windows.Forms.Label
    Friend WithEvents RThreshGrid As System.Windows.Forms.DataGridView
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DOTCtl As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Changed As System.Windows.Forms.CheckBox
    Friend WithEvents butRClear As System.Windows.Forms.Button
    Friend WithEvents butLClear As System.Windows.Forms.Button
    Friend WithEvents butExit As System.Windows.Forms.Button

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents butClearAll As System.Windows.Forms.Button
    Friend WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileEditMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileNewMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileOpenMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileSaveMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileSaveAsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileRecentFilesMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileRecentFilesFilename As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileExitMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsFilenameMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsStyleMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsStyleCombo As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents PlotMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlotPrintMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlotFileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NumbersMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpHelpMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpAboutMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents cmbSpeechTypeR As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSpeechTypeL As System.Windows.Forms.ComboBox
    Friend WithEvents txtLFCC As System.Windows.Forms.TextBox
    Friend WithEvents txtLFCR As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtRFCC As System.Windows.Forms.TextBox
    Friend WithEvents txtRFCR As System.Windows.Forms.TextBox
    Friend WithEvents chkLFreqComp As System.Windows.Forms.CheckBox
    Friend WithEvents SettingsShowSIIPointsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkRFreqComp As System.Windows.Forms.CheckBox
    Friend WithEvents lblTip As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbTransducer As System.Windows.Forms.ComboBox
    Friend WithEvents cmbStyleR As System.Windows.Forms.ComboBox
    Friend WithEvents cmbRvS As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
