﻿Imports System.Xml
Imports ZedGraph
Imports System.IO

Structure test
    Dim name As String
    Dim side As String
    Dim yunit As String
    Dim envelope As String
    Dim xscale As String
    Dim xunit As String
    Dim display As String
    Dim envdisplay As String
    Dim stim_type As String
    Dim stim_level As String
    Dim vdisplay As String
    Dim venvdisplay As String
    Dim mpo_level As String
    Dim method As String
    Dim stimulus As String
    Dim unit As String
    Dim interval As String
    Dim HI_Type As String
    Dim reservegain As String
    Dim data() As Double
End Structure

Public Class Sharp
    Dim ClientID As String
    Dim SessionID As String
    Dim Model As String
    Dim Age As String
    Dim Transducer As String
    Dim SessionDate As String
    Dim HI_Type(1) As String
    Dim peaks(1, 7, 64) As Double
    Dim rmses(1, 7, 64) As Double
    Dim valleys(1, 7, 64) As Double
    Dim mpo(1, 64) As Double
    Dim thresholds(1, 8) As Double
    Dim thresholdsHL(1, 8) As Double
    Dim levels(1, 7) As Double
    Dim mpo_level As Double
    Dim recd(1, 8) As Double
    Dim DTformat As String

    Dim ConditionName() As String = { _
       "Average conversation at 1 meter", _
       "Raised voice at 1 meter", _
       "Classroom teacher at 1 meter", _
       "Classroom teacher at 2 meters", _
       "Classroom teacher at 3 meters", _
       "Classroom teacher at 4 meters", _
       "Classroom teacher at 7 meters", _
       "Average conversation at 4 meters", _
       "Shout", _
       "Own voice", _
       "Head shadow at 1 meter", _
       "Cradle position, near ear", _
       "Hip position, near ear", _
       "Soft speech", _
       "Medium speech", _
       "Loud speech"}
    Dim ConditionLevel() As String = {"60", "70", "72", "66", "63", "61", "61", "48", "85", "70", "60", "68", "76", "55", "65", "75"}
    Dim pastels(,) As Integer = {{255, 230, 230}, _
                                 {255, 242, 230}, _
                                 {255, 255, 230}, _
                                 {230, 255, 230}, _
                                 {230, 255, 255}, _
                                 {230, 230, 255}, _
                                 {255, 230, 255}}
    Dim earname() As String = {"Left", "Right"}
    Dim spectrum(,) As Double = { _
        {50.0, 52.0, 46.5, 45.0, 42.0, 39.0, 36.5, 36.0, 35.5, 60.0}, _
        {60.0, 62.0, 56.5, 55.0, 52.0, 49.0, 46.5, 46.0, 45.5, 70.0}, _
        {55.5, 61.8, 61.8, 60.8, 61.3, 55.8, 53.8, 51.8, 45.8, 70.0}, _
        {49.5, 55.8, 55.8, 54.8, 55.3, 49.8, 47.8, 45.8, 39.8, 70.0}, _
        {46.0, 52.3, 52.3, 51.3, 51.8, 46.3, 44.3, 42.3, 36.3, 60.0}, _
        {44.5, 50.8, 50.8, 49.8, 50.3, 44.8, 42.8, 40.8, 34.8, 60.0}, _
        {44.5, 50.8, 50.8, 49.8, 50.3, 44.8, 42.8, 40.8, 34.8, 60.0}, _
        {38.0, 40.0, 35.0, 33.0, 30.0, 27.0, 25.0, 24.0, 24.0, 50.0}, _
        {58.0, 69.0, 73.8, 75.0, 76.3, 71.5, 68.5, 65.8, 58.8, 80.0}, _
        {60.9, 63.3, 58.9, 53.3, 46.6, 44.7, 36.7, 34.0, 34.8, 70.0}, _
        {44.1, 47.5, 40.9, 39.0, 32.8, 26.7, 19.7, 21.1, 19.5, 60.0}, _
        {56.1, 60.5, 56.4, 50.2, 46.5, 42.4, 37.8, 39.6, 40.6, 70.0}, _
        {63.6, 69.0, 62.9, 58.0, 55.3, 52.2, 49.2, 47.6, 45.0, 80.0}, _
        {46.0, 48.0, 43.2, 41.0, 38.7, 35.0, 32.8, 32.0, 31.2, 55.0}, _
        {56.0, 58.0, 53.2, 51.0, 48.7, 45.0, 42.8, 42.0, 41.2, 65.0}, _
        {59.3, 65.7, 67.0, 66.0, 64.0, 61.2, 57.4, 55.2, 46.5, 75.0}}

    ' LTASS:  0=Male, 1=Female, 2=Child
    Dim LTASS(,) As Double = { _
     {56.8, 56.0, 53.0, 57.0, 58.0, 55.0, 52.5, 51.0, 50.5, 48.0, 45.0, 44.0, 42.5, 42.0, 40.0, 41.5, 41.5, 65.0}, _
     {54.9, 53.1, 48.4, 55.8, 57.3, 58.1, 54.6, 52.0, 51.0, 51.1, 51.2, 49.3, 46.0, 40.0, 36.1, 43.5, 39.9, 65.0}, _
     {32.3, 51.5, 57.3, 54.1, 53.2, 61.2, 56.5, 52.7, 45.4, 41.1, 39.7, 35.5, 28.8, 31.2, 30.6, 32.6, 35.2, 65.0}}

    Dim LoudCorr() As Double = {-2.2, 3.3, 9.6, 6.1, 7.7, 12.4, 14.4, 15, 14.8, 15.5, 16.2, 14.8, 14.5, 13.2, 9.2, 4.2, 2.7, 75}
    Dim NormalH() As Double = {15.8, 13.7, 11.9, 10.2, 9.3, 8.9, 9.0, 8.3, 8.3, 10.2, 14.5, 17.1, 13.4, 12.4, 12.3, 16.8, 22.4}
    Dim StimType(3) As String
    Dim RvsSType() As String = {"map_rear", "map_sar"}
    Dim ranges() As String = {"soft50", "soft55", "avg60", "avg65", "avg70", "loud75", "ov75"}

    Dim max3(third.Count - 1) As Double
    Dim min3(third.Count - 1) As Double
    Dim mean3(third.Count - 1) As Double
    Dim thresh3(third.Count - 1) As Double
    Dim bi3(UBound(third)) As Double
    Dim peakf() As Double, valleyf() As Double, threshf() As Double, fsh() As Double
    Dim meanshifted() As Double

    Private SavedXMLname As String

    Private oRand As Random
    Private doplotcalls As Integer
    Private firstActivation As Boolean
    Public NumberZ As New frmNumberZ
    Public MyEula As New frmMyEula
    Private RThreshTable As New DataTable
    Private LThreshTable As New DataTable
    Private IgnoreChange As Boolean

    ' Private meanshiftedlistL As New PointPairList, meanshiftedlistH As New PointPairList

    Public farray() As String = {"250", "500", "750", "1000", "1500", "2000", "3000", "4000", "6000"}
    Public ThreshRowHeaders() As String = {"Thresh HL", "50      SPL", "55", "60", "65", "70", "75", "MPO", "RECD"}

   

    Private Sub Sharp_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        If firstActivation Then
            Me.lblXMLname.Text = HomeDir & "\demo.xml"
            Call LoadParameters()
            Call DoPlot()
            firstActivation = False
        End If
    End Sub
    Public Function Extract(ByVal XMLfile As String, ByVal force As Integer) As Boolean
        Dim m_xmld As XmlDocument
        Dim m_nodelist As XmlNodeList, nodelist1 As XmlNodeList
        Dim m_node As XmlNode, node As XmlNode, node2 As XmlNode, tnode As XmlNode, enode As XmlNode, fnode As XmlNode
        Dim strg As String
        Dim i As Integer, j As Integer, r As Integer, c As Integer, lindex(1, 7) As Integer
        Const QUOTE = """"
        Dim SessionID As String, s As String
        Dim earname() As String = {"left", "right"}
        Dim sstype(1) As String

        Extract = False

        Array.Clear(peaks, 0, peaks.Length) 'CHECK TO SEE IF ALL CLEAR!
        Array.Clear(rmses, 0, rmses.Length)
        Array.Clear(valleys, 0, valleys.Length)
        Array.Clear(mpo, 0, mpo.Length)
        Array.Clear(thresholds, 0, thresholds.Length)
        Array.Clear(thresholdsHL, 0, thresholdsHL.Length)
        Array.Clear(levels, 0, levels.Length)
        Array.Clear(lindex, 0, lindex.Length)
        Array.Clear(max3, 0, max3.Length)
        Array.Clear(min3, 0, min3.Length)
        Array.Clear(bi3, 0, bi3.Length)
        Array.Clear(mean3, 0, mean3.Length)

        Array.Clear(thresh3, 0, thresh3.Length)
        Array.Clear(recd, 0, recd.Length)

        ' initialize to missing values
        For ear = 0 To 1
            For c = 0 To UBound(thresholds, 2)
                thresholdsHL(ear, c) = -1000.0
            Next
            For c = 0 To UBound(mpo, 2)
                mpo(ear, c) = -1000.0
            Next
            For c = 0 To UBound(recd, 2)
                recd(ear, c) = -1000.0
            Next
        Next

        'Create an XML Document
        m_xmld = New XmlDocument()

        'Load the Xml file
        m_xmld.Load(XMLfile)

        'Locate the desired session
        'strg = "/session[@SessionID=" & Session & "]"
        'm_node = m_xmld.SelectSingleNode(strg)
        m_node = m_xmld.SelectSingleNode("session")

        ' Get SessionID for session
        SessionID = ""
        node = m_node.Attributes.GetNamedItem("SessionID")
        If node IsNot Nothing Then
            If Not String.IsNullOrEmpty(node.Value) Then
                SessionID = node.Value
            End If
        End If

        ' Get ClientID for session
        ClientID = ""
        node = m_node.Attributes.GetNamedItem("ClientID")
        If node IsNot Nothing Then
            If Not String.IsNullOrEmpty(node.Value) Then
                ClientID = node.Value
            End If
        End If

        ' Get Date for session
        SessionDate = ""
        node = m_node.Attributes.GetNamedItem("date")
        If node IsNot Nothing Then
            If Not String.IsNullOrEmpty(node.Value) Then
                SessionDate = node.Value
            End If
        End If

        ' Get Model to see if hand-entered
        enode = m_node.SelectSingleNode("equipment")
        If enode Is Nothing Then
            Model = "No model"
        Else
            Model = ""
            node = enode.Attributes.GetNamedItem("model")
            If node IsNot Nothing Then
                If Not String.IsNullOrEmpty(node.Value) Then
                    Model = node.Value
                End If
            End If
        End If

        If Model = "vf2" Then
            StimType(0) = "speech-wbcarrots"
            StimType(1) = "speech-wbear"
            StimType(2) = "speech-ists"
            StimType(3) = "speech-female"
        Else
            StimType(0) = "speech-carrots"
            StimType(1) = "speech-ear"
            StimType(2) = "speech-ists"
            StimType(3) = "speech-female"
        End If

        'Get key frequencies (not used, currently using hardcoded versions)
        Dim audiostring As String, thirdstring As String, twelfthstring As String
        Dim XA() As String, XT() As String, XF() As String
        strg = "test[@name=" & QUOTE & "frequencies" & QUOTE & "]"
        fnode = m_node.SelectSingleNode(strg)
        strg = "data[@name=" & QUOTE & "audiometric" & QUOTE & "]"
        node = fnode.SelectSingleNode(strg)
        audiostring = node.ChildNodes(0).Value
        XA = Split(audiostring)
        strg = "data[@name=" & QUOTE & "3rds" & QUOTE & "]"
        node = fnode.SelectSingleNode(strg)
        thirdstring = node.ChildNodes(0).Value
        XT = Split(thirdstring)
        strg = "data[@name=" & QUOTE & "12ths" & QUOTE & "]"
        node = fnode.SelectSingleNode(strg)
        twelfthstring = node.ChildNodes(0).Value
        XF = Split(twelfthstring)

        Age = ""
        strg = "test[@name=" & QUOTE & "audiometry" & QUOTE & "]"
        enode = m_node.SelectSingleNode(strg)
        node = enode.Attributes.GetNamedItem("age")
        If node IsNot Nothing Then
            If Not String.IsNullOrEmpty(node.Value) Then
                Age = node.Value
            End If
        End If


        Transducer = ""
        strg = "test[@name=" & QUOTE & "speechmap" & QUOTE & " and " & "@transducer=" & QUOTE & "insertfoam" & QUOTE & "]"
        enode = m_node.SelectSingleNode(strg)
        If enode Is Nothing Then
            strg = "test[@name=" & QUOTE & "speechmap" & QUOTE & " and " & "@transducer=" & QUOTE & "headphone" & QUOTE & "]"
            enode = m_node.SelectSingleNode(strg)
        End If
        If enode Is Nothing Then
            Transducer = ""
        Else
            node = enode.Attributes.GetNamedItem("transducer")
            If node IsNot Nothing Then
                If Not String.IsNullOrEmpty(node.Value) Then
                    Transducer = node.Value
                End If
            End If
        End If

        ' redimension and clear
        ' end redim and clear

        For ear = 0 To 1
            For i = 0 To UBound(levels, 2)
                levels(ear, i) = 0.0
            Next i
            For i = 0 To UBound(lindex, 2)
                lindex(ear, i) = -1
            Next
        Next

        For ear = 0 To 1
            'Locate the speechmap for ear
            strg = "test[@name=" & QUOTE & "speechmap" & QUOTE & " and " & "@side=" & QUOTE & earname(ear) & QUOTE & "]"
            node = m_node.SelectSingleNode(strg)

            HI_Type(ear) = ""
            tnode = node.Attributes.GetNamedItem("HI_Type")
            If tnode IsNot Nothing Then
                If Not String.IsNullOrEmpty(tnode.Value) Then
                    HI_Type(ear) = tnode.Value
                End If
            End If

            sstype(ear) = ""
            tnode = node.Attributes.GetNamedItem("stim_type")
            If tnode IsNot Nothing Then
                If Not String.IsNullOrEmpty(tnode.Value) Then
                    sstype(ear) = tnode.Value
                End If
            End If

            Dim sttype As String
            sttype = StimType(Me.cmbSpeechType.SelectedIndex)
            Dim rstype As String
            rstype = RvsSType(Me.cmbRvS.SelectedIndex)

            ' collect all the dBspl curves (peaks, rms, valleys, mpos)
            'strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and contains(@internal," & QUOTE & "map_rearspl" & QUOTE & ")]"
            'strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and contains(@internal," & QUOTE & "map_" & QUOTE & ")]"
            ''strg = "data[contains(@name," & QUOTE & "test" & QUOTE & ") and @yunit=" & QUOTE & "dBspl" & QUOTE & " and contains(@internal," & QUOTE & "map_" & QUOTE & ")]"
            'strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and contains(@name," & QUOTE & "test1_" & QUOTE & ") and contains(@internal," & QUOTE & "map_rearspl" & QUOTE & ")]"

            ' Get list of all tests containing chosen stim_type
            strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and @stim_type=" & QUOTE & sttype & QUOTE & "]"
            nodelist1 = node.SelectNodes(strg)
            Dim list As New List(Of String)
            For i = 0 To nodelist1.Count - 1
                list.Add(nodelist1.Item(i).Attributes(0).Value)
            Next
            list = list.Distinct().ToList()
            Dim vals() As String

            If Not list.Count = 0 Then
                'find all the nodes belong to tests in the list
                strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and contains(@internal," & QUOTE & rstype & QUOTE & ")]["
                For i = 0 To list.Count - 1
                    If i > 0 Then
                        strg = strg & " or "
                    End If
                    strg = strg & "@name =" & QUOTE & list(i) & QUOTE
                Next
                strg = strg & "]"

                nodelist1 = Nothing
                nodelist1 = node.SelectNodes(strg)
                ' find locations of levels 

                Dim idx As Integer
                For r = 0 To ranges.Count - 1
                    For i = 0 To nodelist1.Count - 1
                        For j = 0 To nodelist1.Item(i).Attributes.Count - 1
                            s = nodelist1.Item(i).Attributes(j).Value
                            idx = s.IndexOf("mpo")
                            If idx >= 0 Then
                                Exit For
                            End If
                            idx = s.IndexOf(ranges(r))
                            If idx = 0 Then
                                lindex(ear, r) = i
                                levels(ear, r) = GetDoubleFromStringUsingSB(s)
                            End If
                        Next
                    Next
                Next

                'extract rms levels, peaks, valleys
                'Dim vals() As String
                For i = 0 To ranges.Count - 1 'rmses 
                    If lindex(ear, i) <> -1 Then
                        s = nodelist1.Item(lindex(ear, i)).ChildNodes(0).Value 'rms
                        s = Trim(s)
                        vals = s.Split
                        If UBound(vals) > UBound(twelfth) Then
                            ReDim Preserve vals(UBound(twelfth))
                        End If
                        For j = 0 To vals.Count - 1
                            rmses(ear, i, j) = Convert.ToDouble(vals(j))
                        Next j

                        s = nodelist1.Item(lindex(ear, i) - 1).ChildNodes(0).Value 'peak (row before)
                        s = Trim(s)
                        vals = s.Split
                        If UBound(vals) > UBound(twelfth) Then
                            ReDim Preserve vals(UBound(twelfth))
                        End If
                        For j = 0 To vals.Count - 1
                            peaks(ear, i, j) = Convert.ToDouble(vals(j))
                        Next j

                        s = nodelist1.Item(lindex(ear, i) + 1).ChildNodes(0).Value 'valleys (row after)
                        s = Trim(s)
                        vals = s.Split
                        If UBound(vals) > UBound(twelfth) Then
                            ReDim Preserve vals(UBound(twelfth))
                        End If
                        For j = 0 To vals.Count - 1
                            valleys(ear, i, j) = Convert.ToDouble(vals(j))
                        Next j
                    End If
                Next i
            End If 'get rid of this to set code back

            ' get thresholds (dBspl)
            strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and @name=" & QUOTE & "threshold" & QUOTE & "]"
            node2 = node.SelectSingleNode(strg)
            s = node2.ChildNodes(0).Value
            s = Trim(s)
            vals = s.Split
            If UBound(vals) > UBound(audiometric) Then
                ReDim Preserve vals(UBound(audiometric))
            End If
            For j = 0 To vals.Count - 1
                If vals(j) = "_" Then
                    thresholds(ear, j) = -1000.0
                Else
                    thresholds(ear, j) = Convert.ToDouble(vals(j))
                End If
            Next j

            ' get thresholds (dBhl)
            strg = "data[@yunit=" & QUOTE & "dBhl" & QUOTE & " and @name=" & QUOTE & "threshold" & QUOTE & "]"
            node2 = node.SelectSingleNode(strg)
            s = node2.ChildNodes(0).Value
            s = Trim(s)
            vals = s.Split
            If UBound(vals) > UBound(audiometric) Then
                ReDim Preserve vals(UBound(audiometric))
            End If
            For j = 0 To vals.Count - 1
                If vals(j) = "_" Then
                    thresholdsHL(ear, j) = -1000.0
                Else
                    thresholdsHL(ear, j) = Convert.ToDouble(vals(j))
                End If
            Next j

            ' get RECD (dBspl)
            If Model = "SharpEntered" Then
                strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and @name=" & QUOTE & "recd" & QUOTE & "]"
                node2 = node.SelectSingleNode(strg)
                s = node2.ChildNodes(0).Value
                s = Trim(s)
                vals = s.Split
                For j = 0 To vals.Count - 1
                    If vals(j) = "_" Then
                        recd(ear, j) = -1000.0
                    Else
                        recd(ear, j) = Convert.ToDouble(vals(j))
                    End If
                Next j
            End If

            ' get mpo
            node2 = Nothing
            strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and @stim_type=" & QUOTE & "mpo" & QUOTE & "]"
            node2 = node.SelectSingleNode(strg)
            If Not node2 Is Nothing Then
                s = node2.ChildNodes(0).Value
                s = Trim(s)
                vals = s.Split
                If UBound(vals) > UBound(twelfth) Then
                    ReDim Preserve vals(UBound(twelfth))
                End If
                For j = 0 To vals.Count - 1
                    If vals(j) = "_" Then
                        mpo(ear, j) = -1000.0
                    Else
                        mpo(ear, j) = Convert.ToDouble(vals(j))
                    End If
                Next j
            End If
            'End If 'End if was here for  strg = "data[@yunit=" & QUOTE & "dBspl" & QUOTE & " and @stim_type=" & QUOTE & sttype & QUOTE & "]"

        Next ear

        ' find indexes of audiometric frequencies in twelfths table
        Dim i12(8) As Integer

        For i = 0 To audiometric.Count - 1
            For j = 0 To twelfth.Count - 1
                If twelfth(j) = audiometric(i) Then
                    i12(i) = j
                    Debug.Print(Str(i) & " " & Str(audiometric(i)) & " " & Str(i12(i)) & " " & Str(twelfth(i12(i))))
                    Exit For
                End If
            Next
        Next

        ' Fill the Entry panel
        Dim temp As String, temps() As String
        Dim ThreshTable(1) As DataTable
        Dim NewDate As DateTime
        If Model = "SharpEntered" Or force = 1 Then
            Me.lblXMLname.ForeColor = Color.DarkBlue
            Me.FileEditMenu.Enabled = True
            Me.FileSaveMenu.Enabled = False
            Me.FileSaveAsMenu.Enabled = False
            txtClientID.Text = ClientID
            If force = 1 Then
                NewDate = DateTime.ParseExact(SessionDate, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentUICulture)
            Else
                NewDate = DateTime.ParseExact(SessionDate, "MM/dd/yyyy", System.Globalization.CultureInfo.CurrentUICulture)
            End If
            Me.DOTCtl.Value = NewDate

            If Age(0) = "y" Then
                temp = " " & Age.Substring(5) & " years"
            ElseIf Age(0) = "m" Then
                temp = " " & Age.Substring(6) & " months"
            ElseIf Age(0) = "a" Then
                temp = " Adult"
            End If
            Me.cmbAge.SelectedItem = temp
            If Transducer = "insertfoam" Then
                Me.cmbTransducer.SelectedIndex = 0
            Else
                Me.cmbTransducer.SelectedIndex = 1
            End If
            Me.cmbStyleL.SelectedItem = HI_Type(0)
            Me.cmbStyleR.SelectedItem = HI_Type(1)
            Me.cmbSpeechTypeL.SelectedItem = sstype(0)
            Me.cmbSpeechTypeR.SelectedItem = sstype(1)
            ThreshTable(0) = LThreshTable
            ThreshTable(1) = RThreshTable
            ' Clear grids
            For ear = 0 To 1
                For r = 0 To ThreshTable(ear).Rows.Count - 1
                    For c = 0 To ThreshTable(ear).Columns.Count - 1
                        ThreshTable(ear).Rows(r).Item(c) = ""
                    Next
                Next
            Next

            For ear = 0 To 1
                ' threshhold in HL
                For c = 0 To ThreshTable(ear).Columns.Count - 1
                    If thresholdsHL(ear, c) = -1000.0 Then
                        ThreshTable(ear).Rows(0).Item(c) = ""
                    Else
                        ThreshTable(ear).Rows(0).Item(c) = Format$(thresholdsHL(ear, c), "##0.0")
                    End If
                Next
                ' levels
                For r = 1 To ThreshTable(ear).Rows.Count - 2
                    If lindex(ear, r - 1) <> -1 Then
                        For c = 0 To ThreshTable(ear).Columns.Count - 1
                            If rmses(ear, r - 1, i12(c)) = -1000.0 Then
                                ThreshTable(ear).Rows(r).Item(c) = ""
                            Else
                                ThreshTable(ear).Rows(r).Item(c) = Format(rmses(ear, r - 1, i12(c)), "##0.0")
                            End If
                        Next
                    End If
                Next
                'MPO
                For c = 0 To ThreshTable(ear).Columns.Count - 1
                    If mpo(ear, i12(c)) = -1000.0 Then
                        ThreshTable(ear).Rows(7).Item(c) = ""
                    Else
                        ThreshTable(ear).Rows(7).Item(c) = Format$(mpo(ear, i12(c)), "##0.0")
                    End If
                Next
                ' RECD
                For c = 0 To ThreshTable(ear).Columns.Count - 1
                    If recd(ear, c) = -1000.0 Then
                        ThreshTable(ear).Rows(8).Item(c) = ""
                    Else
                        ThreshTable(ear).Rows(8).Item(c) = Format$(recd(ear, c), "##0.0")
                    End If
                Next

            Next
        Else
            Me.lblXMLname.ForeColor = Color.Black
            Me.FileEditMenu.Enabled = False
            Me.FileSaveMenu.Enabled = False
            Me.FileSaveAsMenu.Enabled = False
        End If

        Extract = True

    End Function
    Private Sub Sharp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim key As String, index As Integer, DTformat As String
        For Each ctrl As Control In Me.gpConditions.Controls
            key = CType(ctrl, RadioButton).Name.Trim
            index = Int(GetDoubleFromStringUsingSB(key)) - 1
            CType(ctrl, RadioButton).Text = ConditionName(index)
            ToolTip1.SetToolTip(ctrl, "Input level " & ConditionLevel(index) & " dB SPL")
        Next

        DTformat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern()
        If DTformat.IndexOf("M") = 0 Then
            DTformat = "MM/dd/yyyy"
            Me.DOTCtl.Format = DateTimePickerFormat.Custom
            Me.DOTCtl.CustomFormat = DTformat
        ElseIf DTformat.IndexOf("d") = 0 Then
            DTformat = "dd/MM/yyyy"
            Me.DOTCtl.Format = DateTimePickerFormat.Custom
            Me.DOTCtl.CustomFormat = DTformat
        End If

        SavedXMLname = ""

        Me.PlotPanel.BackColor = Me.BackColor
        'Me.EditPanel.BackColor = Me.BackColor
        Me.EditPanel.Left = Me.Width / 2 - Me.EditPanel.Width / 2
        Me.EditPanel.Top = 30
        Me.butSaveAs.Top = Me.RPanelThr.Top + Me.RPanelThr.Height + 20
        Me.butDontSave.Top = Me.butSaveAs.Top
        Me.butFill.Top = Me.butSaveAs.Top
        Me.chkRFreqComp.Location = Me.chkLFreqComp.Location
        Me.txtRFCC.Location = Me.txtLFCC.Location
        Me.txtRFCR.Location = Me.txtLFCR.Location
        'Me.Changed.Top = Me.butSaveAs.Top + Me.butSaveAs.Height - Me.Changed.Height

        Me.radSpect1.Checked = True
        Me.SettingsStyleCombo.SelectedIndex = 0
        Me.cmbEar.SelectedIndex = 0
        Me.chkLFreqComp.Checked = False ' perform after pre-selecting ear
        Me.txtLFCC.Enabled = False
        Me.txtLFCR.Enabled = False
        Me.txtRFCC.Enabled = False
        Me.txtRFCR.Enabled = False
        ToolTip1.SetToolTip(Me.txtLFCC, "Cutoff frequency, Range 1500 - 6000 Hz")
        ToolTip1.SetToolTip(Me.txtRFCC, "Cutoff frequency, Range 1500 - 6000 Hz")
        ToolTip1.SetToolTip(Me.txtLFCR, "Compression Ratio, Range 1.5 - 4.0")
        ToolTip1.SetToolTip(Me.txtRFCR, "Compression Ratio, Range 1.5 - 4.0")
        Me.cmbBI.SelectedIndex = 0
        Me.cmbMFC.SelectedIndex = 0
        Me.cmbAidUn.SelectedIndex = 1
        Me.cmbSpeechType.SelectedIndex = 0
        Me.cmbRvS.SelectedIndex = 0
        Me.SettingsStyleCombo.SelectedIndex = 0
        Me.SettingsFilenameMenu.Checked = False
        For r = 0 To RThreshGrid.Rows.Count - 1
            Me.RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
            Me.LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next

        oRand = New Random(DateTime.Now.Millisecond)
        doplotcalls = 0
        ToolTip1.SetToolTip(Me.cmbBI, "Band Importance Method")
        ToolTip1.SetToolTip(Me.butFill, "Fill from the previous opened file")
        If RThreshTable.Columns.Count = 0 Then
            LPanelThr.Location = RPanelThr.Location
            LPanelThr.Visible = False
            RPanelThr.Visible = True
            ' R Thresh Grid
            For r = 0 To 8
                RThreshTable.Columns.Add(farray(r))
            Next
            For r = 0 To UBound(ThreshRowHeaders)
                RThreshTable.Rows.Add(New Object() {"", "", "", "", "", "", "", "", ""})
            Next

            RThreshGrid.DataSource = RThreshTable
            RThreshGrid.EnableHeadersVisualStyles = False
            For r = 0 To 8
                RThreshGrid.Columns(r).Width = 40
            Next
            RThreshGrid.Width = 452
            RThreshGrid.Height = 218 '196
            ''RPanelThr.Width = RThreshGrid.Width
            RPanelThr.Height = RThreshGrid.Location.Y + RThreshGrid.Height
            'RPanelThr.Location = New Point((TabPage3.Width / 2 - RPanelThr.Width / 2), RPanelThr.Location.Y)
            RThreshLabel.Location = New Point((RPanelThr.Width / 2 - RThreshLabel.Width / 2), RThreshLabel.Location.Y)
        End If
        For r = 0 To RThreshTable.Rows.Count - 1
            For c = 0 To RThreshTable.Columns.Count - 1
                RThreshTable.Rows(r).Item(c) = ""
            Next
        Next
        RThreshGrid.RowHeadersWidth = 90
        For r = 0 To RThreshGrid.Rows.Count - 1
            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next

        ' L Thresh Grid
        If LThreshTable.Columns.Count = 0 Then
            For r = 0 To 8
                LThreshTable.Columns.Add(farray(r))
            Next
            For r = 0 To UBound(ThreshRowHeaders)
                LThreshTable.Rows.Add(New Object() {"", "", "", "", "", "", "", "", ""})
            Next
            LThreshGrid.DataSource = LThreshTable
            LThreshGrid.EnableHeadersVisualStyles = False
            For r = 0 To 8
                LThreshGrid.Columns(r).Width = 40
            Next
            LThreshGrid.Width = 452 '437
            LThreshGrid.Height = 218 '196
            ''LPanelThr.Width = LThreshGrid.Width
            LPanelThr.Height = LThreshGrid.Location.Y + LThreshGrid.Height
            'LPanelThr.Location = New Point((TabPage3.Width / 2 - LPanelThr.Width / 2), LPanelThr.Location.Y)
            LThreshLabel.Location = New Point((LPanelThr.Width / 2 - LThreshLabel.Width / 2), LThreshLabel.Location.Y)
        End If
        For r = 0 To LThreshTable.Rows.Count - 1
            For c = 0 To LThreshTable.Columns.Count - 1
                LThreshTable.Rows(r).Item(c) = ""
            Next
        Next
        LThreshGrid.RowHeadersWidth = 90
        For r = 0 To LThreshGrid.Rows.Count - 1
            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next

        'txtSessionNo.Text = "1"
        IgnoreChange = False
        ' Me.Changed.Checked = False
        Me.cmbStyleL.SelectedIndex = 0
        Me.cmbStyleR.SelectedIndex = 0
        Me.cmbTransducer.SelectedIndex = 0
        Dim i As Integer
        Me.cmbAge.Items.Clear()
        Me.cmbAge.Items.Add(" Adult")
        For i = 10 To 6 Step -1
            Me.cmbAge.Items.Add(Str$(i) & " years")
        Next
        For i = 60 To 1 Step -1
            Me.cmbAge.Items.Add(Str$(i) & " months")
        Next
        Me.cmbAge.SelectedIndex = 0
        Me.Changed.Checked = False
        Me.Tag = "virgin"

        If My.Settings.RecentFile.Trim.Length > 0 Then
            Me.FileRecentFilesFilename.Text = My.Settings.RecentFile.Trim
        End If
        If My.Settings.ShowFileName Then
            Me.SettingsFilenameMenu.Checked = True
        Else
            Me.SettingsFilenameMenu.Checked = False
        End If
        If My.Settings.GraphStyle.Trim.Length > 0 Then
            Me.SettingsStyleCombo.SelectedItem = My.Settings.GraphStyle.Trim
        End If
        If My.Settings.ShowSIIpoints Then
            Me.SettingsShowSIIPointsMenu.Checked = True
        Else
            Me.SettingsShowSIIPointsMenu.Checked = False
        End If
        Dim temp As String

        ' Determine Home Directory
        If Debugger.IsAttached Then
            HomeDir = Application.StartupPath
        Else
            temp = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            If Not Directory.Exists(temp) Then
                HomeDir = Application.UserAppDataPath
            Else
                temp = temp & "\Sharp"
                If Not Directory.Exists(temp) Then
                    Directory.CreateDirectory(temp)
                End If
                HomeDir = temp
            End If
        End If
        temp = HomeDir & "\demo.xml"
        If Not File.Exists(temp) Then
            My.Computer.FileSystem.CopyFile(Application.StartupPath & "\test1.1.xml", temp, True) 'copy in demo file
        End If
        temp = HomeDir & "\SharpManual.pdf"
        If Not File.Exists(temp) Then
            My.Computer.FileSystem.CopyFile(Application.StartupPath & "\SharpManual.pdf", temp, True) 'copy in demo file
        End If

        firstActivation = True
        If Debugger.IsAttached Then
            MsgBox("EULA not written during debugging.")
            Exit Sub
        End If

        Dim EULApath As String
        EULApath = Application.StartupPath & "\EULA.rtf"
        If Not File.Exists(EULApath) Then
            MyEula.ShowDialog()
        End If

        'ToolTip1.SetToolTip(Me.zgc, "click")

    End Sub

    Private Sub ForceGridCellEndEdit(ByVal g As DataGridView)
        Dim r As Integer, c As Integer, newc As Integer
        If g.CurrentCell Is Nothing Then
            Exit Sub
        End If
        r = g.CurrentCell.RowIndex
        c = g.CurrentCell.ColumnIndex
        If c < g.ColumnCount - 1 Then
            newc = c + 1
        Else
            newc = c - 1
        End If
        g.CurrentCell = g.Rows(r).Cells(newc) ' move over
        g.CurrentCell = g.Rows(r).Cells(c)    ' and back, forcing CellEndEdit event
    End Sub

    Private Function FreqToX(ByVal x As Double) As Double
        Dim axoff As Double, transx As Double
        axoff = 1 - (Log2(250) - Log2(200))
        transx = Log2(x) - Log2(200) + axoff
        Return transx
    End Function

    Public Sub ClearEntryPanel()
        Dim r As Integer, c As Integer
        For r = 0 To Me.RThreshTable.Rows.Count - 1
            For c = 0 To Me.RThreshTable.Columns.Count - 1
                Me.RThreshTable.Rows(r).Item(c) = ""
                Me.LThreshTable.Rows(r).Item(c) = ""
            Next
        Next
        RThreshGrid.CurrentCell = RThreshGrid.Rows(0).Cells(0) ' park at first cell
        LThreshGrid.CurrentCell = LThreshGrid.Rows(0).Cells(0) ' park at first cell

        txtClientID.Text = ""
        cmbAge.SelectedIndex = 0
        Me.cmbStyleL.SelectedIndex = 0
        Me.cmbStyleR.SelectedIndex = 0
        Me.cmbSpeechTypeL.SelectedIndex = 0
        Me.cmbSpeechTypeR.SelectedIndex = 0
        Me.DOTCtl.Value = DateTime.Now

        Me.Changed.Checked = False

        RPanelThr.Visible = True
        LPanelThr.Visible = False

    End Sub

    Public Sub DoPlot()
        Dim axfreqs() As Double = {250, 500, 1000, 2000, 4000, 8000}
        Dim xlabels() As String, levlist As String

        Dim LTASSI(twelfth.Count - 1) As Double
        Dim LoudCorrI(twelfth.Count - 1) As Double
        Dim xx As Boolean
        Dim ear As Integer, i As Integer, ii As Integer
        Dim meanlist As New PointPairList
        Dim maxlist As New PointPairList
        Dim minlist As New PointPairList
        Dim highlist As New PointPairList
        Dim lowlist As New PointPairList
 
        doplotcalls = doplotcalls + 1
        Me.lblCount.Text = Str$(doplotcalls)
        '       Dim AppPath As String
        '       AppPath = System.AppDomain.CurrentDomain.BaseDirectory()
        Dim XMLname As String, justname As String, parts() As String, session As String
        XMLname = lblXMLname.Text
        justname = Path.GetFileNameWithoutExtension(XMLname)
        parts = Split(justname, ".")
        session = parts(parts.Count - 1)
        If Len(XMLname) > 0 Then
            xx = Extract(XMLname, 0)
        End If

        Dim myPane As GraphPane = zgc.GraphPane

        ear = Me.cmbEar.SelectedIndex

        'If Me.panLevels.Visible Then
        '    If Not Me.chkLevel1.Checked Then
        '        levels(ear, 1) = 0.0
        '    End If
        '    If Not Me.ChkLevel3.Checked Then
        '        levels(ear, 3) = 0.0
        '    End If
        '    If Not Me.chkLevel5.Checked Then
        '        levels(ear, 5) = 0.0
        '    End If
        ' End If

        levlist = ""
        Dim lcount As Integer
        lcount = 0
        For i = 0 To UBound(levels, 2)
            If levels(ear, i) <> 0 Then
                lcount = lcount + 1
                If Len(levlist) > 0 Then
                    levlist = levlist & ","
                End If
                levlist = levlist & Trim$(Str$(levels(ear, i)))
            End If
        Next
        Debug.Print(levlist)

        myPane.CurveList.Clear()

        myPane.GraphObjList.Clear()

        myPane.Legend.Position = LegendPos.Left
        myPane.Legend.IsHStack = False

        myPane.X2Axis.IsVisible = False
        'myPane.Border.IsVisible = False
        myPane.Border.Color = Color.White

        ReDim xlabels(axfreqs.Count - 1)
        For i = 0 To UBound(xlabels)
            xlabels(i) = Convert.ToString(axfreqs(i))
        Next
        ' Set the titles and axis labels
        'myPane.XAxis.Scale.Min = 0
        'myPane.XAxis.Scale.Max = 5.5
        ' myPane.XAxis.Title.Text = ""
        ''myPane.XAxis.Scale.MajorStep = 1000.0
        ''myPane.XAxis.Scale.MinorStep = 100.0
        'myPane.XAxis.Scale.IsVisible = False
        'myPane.XAxis.MajorTic.IsAllTics = False
        'myPane.XAxis.MinorTic.IsAllTics = False
        'Dim v As Double, ticlen As Double

        myPane.YAxis.Scale.Min = -10
        myPane.YAxis.Scale.Max = 140
        myPane.YAxis.Title.Text = "dB SPL"
        myPane.YAxis.MajorTic.IsOpposite = False
        myPane.YAxis.MinorTic.IsOpposite = False
        Dim axoff As Double
        ' Adjust X axis to accomodate octave scale
        axoff = 1 - (Log2(250) - Log2(200))
        myPane.XAxis.Scale.Min = 0 + axoff
        myPane.XAxis.Scale.Max = 5.5 + axoff
        'myPane.X2Axis.Scale.MajorStep = 1.0
        'myPane.XAxis.Type = AxisType.Text
        'myPane.XAxis.Scale.TextLabels = xlabels
        ' myPane.XAxis.Scale.IsVisible = True
        myPane.XAxis.Title.Text = "Hz"
        myPane.XAxis.MinorTic.IsAllTics = False
        'myPane.XAxis.MajorGrid.IsVisible = True
        'myPane.XAxis.MinorGrid.IsVisible = False

        'ticlen = (myPane.YAxis.Scale.Max - myPane.YAxis.Scale.Min) / 50.0

        'For i = 0 To UBound(xlabels)
        '    v = FreqToXaxfreqs(i)) 
        '    Dim text As New TextObj(xlabels(i), v, myPane.YAxis.Scale.Min - ticlen)
        '    text.Location.AlignH = AlignH.Center
        '    text.Location.AlignV = AlignV.Top
        '    text.FontSpec.Border.IsVisible = False
        '    text.FontSpec.Fill.IsVisible = False
        '    text.FontSpec.Size = myPane.XAxis.Scale.FontSpec.Size
        '    myPane.GraphObjList.Add(text)
        '    Dim line As New LineObj(v, myPane.YAxis.Scale.Min, v, myPane.YAxis.Scale.Min + ticlen)
        '    myPane.GraphObjList.Add(line)
        'Next

        myPane.YAxis.Color = Color.White ' make Y-axis at y = 0 invisible

        'Cover the x-axis labels with frequency labels (x axis was transformed to log 2)
        For i = 0 To UBound(xlabels)
            Dim text As New TextObj(xlabels(i), FreqToX(axfreqs(i)), -13, CoordType.AxisXYScale)
            text.Location.AlignH = AlignH.Center
            text.Location.AlignV = AlignV.Top
            text.FontSpec.Border.IsVisible = False
            text.FontSpec.StringAlignment = StringAlignment.Center
            text.FontSpec.Size = myPane.XAxis.Scale.FontSpec.Size
            myPane.GraphObjList.Add(text)
        Next

        Dim s As String, stemp As String
        If Age(0) = "y" Then
            stemp = Age.Substring(5) & " years"
        ElseIf Age(0) = "m" Then
            stemp = Age.Substring(6) & " months"
        ElseIf Age(0) = "a" Then
            stemp = "Adult"
        End If

        s = stemp & vbNewLine & earname(ear) & vbNewLine & StrConv(Transducer, VbStrConv.ProperCase) & vbNewLine & StrConv(HI_Type(ear), VbStrConv.ProperCase) & vbNewLine & cmbAidUn.SelectedItem.ToString & vbNewLine & _
            cmbMFC.SelectedItem.ToString & vbNewLine & cmbSpeechType.SelectedItem.ToString & vbNewLine & cmbBI.SelectedItem.ToString
        Dim etext As New TextObj(s, 0.04, 0.35, CoordType.PaneFraction)
        etext.Location.AlignH = AlignH.Left
        etext.Location.AlignV = AlignV.Top
        etext.FontSpec.Border.IsVisible = False
        etext.FontSpec.StringAlignment = StringAlignment.Near
        etext.FontSpec.Size = myPane.XAxis.Scale.FontSpec.Size
        myPane.GraphObjList.Add(etext)

        zgc.IsEnableZoom = False

        'If Me.SettingsStyleCombo.SelectedIndex = 1 Then
        '    ' Fill a rectangular area with semi-transparent pastel using the alpha value
        '    Dim arect(4) As PointD
        '    ii = oRand.Next(0, UBound(axfreqs))
        '    arect(0).X = FreqToX(axfreqs(ii))
        '    arect(0).Y = myPane.YAxis.Scale.Min
        '    arect(1).X = FreqToX(axfreqs(ii + 1))
        '    arect(1).Y = myPane.YAxis.Scale.Min
        '    arect(2).X = FreqToX(axfreqs(ii + 1))
        '    arect(2).Y = myPane.YAxis.Scale.Max
        '    arect(3).X = FreqToX(axfreqs(ii))
        '    arect(3).Y = myPane.YAxis.Scale.Max
        '    arect(4).X = FreqToX(axfreqs(ii))
        '    arect(4).Y = myPane.YAxis.Scale.Min
        '    Dim arectpoly As New PolyObj(arect, Color.LightSteelBlue, Color.White)
        '    arectpoly.IsClosedFigure = True
        '    i = oRand.Next(0, UBound(pastels))
        '    arectpoly.Fill = New Fill(Color.FromArgb(0, pastels(i, 0), pastels(i, 1), pastels(i, 2)))
        '    myPane.GraphObjList.Add(arectpoly)
        '    arectpoly.ZOrder = ZOrder.E_BehindCurves
        'End If

        Dim ilev As Integer, cond As Integer
        Dim key As String
        For Each ctrl As Control In Me.gpConditions.Controls
            If CType(ctrl, RadioButton).Checked Then
                key = CType(ctrl, RadioButton).Name.Trim
                cond = Int(GetDoubleFromStringUsingSB(key)) - 1
            End If
        Next
        ilev = 0

        s = ConditionLevel(cond) & " dB SPL"
        Dim ctext As New TextObj(s, 0.85, 0.12, CoordType.PaneFraction)
        ctext.Location.AlignH = AlignH.Left
        ctext.Location.AlignV = AlignV.Top
        ctext.FontSpec.Border.IsVisible = False
        ctext.FontSpec.StringAlignment = StringAlignment.Near
        ctext.FontSpec.Size = 10
        myPane.GraphObjList.Add(ctext)

        myPane.Title.Text = "                             " & ConditionName(cond) '& " (" & ConditionLevel(cond) & "dB SPL)"
        Dim j As Integer, k As Integer
        Dim IOx() As Double, IOy() As Double
        Dim overall As Double

        ' for mean
        overall = Convert.ToDouble(ConditionLevel(cond))
        Dim temp() As Double

        ReDim temp(third.Count - 1)
        Dim mfc As Integer
        mfc = Me.cmbMFC.SelectedIndex
        For i = 0 To third.Count - 1
            temp(i) = LTASS(mfc, i)
        Next
        LTASSI = interp1(third, temp, twelfth)
        LoudCorrI = interp1(third, LoudCorr, twelfth)

        ReDim temp(UBound(audiometric))
        For i = 0 To UBound(audiometric)
            temp(i) = spectrum(cond, i)
        Next
        Dim LTASSC(UBound(twelfth)) As Double
        LTASSC = interp1(audiometric, temp, twelfth)

        Dim threshtemp() As Double
        Dim threshfreq() As Double
        Dim threshcount As Double
        Dim threshCurve As LineItem
        Dim threshlist = New PointPairList()
        Dim EarSymbol As SymbolType
        threshcount = 0
        For i = 0 To UBound(thresholds, 2)
            If Not thresholds(ear, i) = -1000.0 Then 'missing value
                threshlist.Add(FreqToX(audiometric(i)), thresholds(ear, i))
                ReDim Preserve threshtemp(threshcount)
                ReDim Preserve threshfreq(threshcount)
                threshtemp(threshcount) = thresholds(ear, i)
                threshfreq(threshcount) = audiometric(i)
                threshcount = threshcount + 1
            End If
        Next i
        If ear = 0 Then
            EarSymbol = SymbolType.XCross
        Else
            EarSymbol = SymbolType.Circle
        End If
        threshCurve = myPane.AddCurve("Thresh", threshlist, Color.Black, EarSymbol)
        'threshCurve.Line.Fill = New Fill(Color.White)
        threshCurve.Line.IsAntiAlias = True
        If SettingsFilenameMenu.Checked Then
            s = XMLname
        Else
            s = " "
        End If
        Dim ftext As New TextObj(s, 0.01, 0.995, CoordType.PaneFraction)
        ftext.Location.AlignH = AlignH.Left
        ftext.Location.AlignV = AlignV.Bottom
        ftext.FontSpec.Border.IsVisible = False
        ftext.FontSpec.StringAlignment = StringAlignment.Near
        ftext.FontSpec.Size = 11
        myPane.GraphObjList.Add(ftext)

        If threshcount < 2 Or lcount = 0 Then
            zgc.Refresh()
            Exit Sub
        End If

        'If lcount < 2 Then
        '    zgc.Refresh()
        '    Call MsgBox("Must be at least two levels")
        '    Exit Sub
        'End If
        Dim lspmean As Double, lspmax As Double, lspmin As Double, jjj As Integer, kkk As Integer, linecount As Integer
        Dim slin(1) As Double
        Dim FILE_NAME As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\test.plt"
        Dim objwriter As New System.IO.StreamWriter(FILE_NAME)
        objwriter.WriteLine("xmin=20")
        objwriter.WriteLine("xmax=100")
        objwriter.WriteLine("ymin=40")
        objwriter.WriteLine("ymax=100")
        objwriter.WriteLine("pltype=1")
        objwriter.WriteLine("tlabel=" & s)
        If cmbAidUn.SelectedIndex = 0 Then
            For i = 0 To UBound(LTASSI)
                meanlist.Add(FreqToX(twelfth(i)), LTASSC(i)) 'mean
                maxlist.Add(FreqToX(twelfth(i)), LTASSC(i) + 15) 'max
                minlist.Add(FreqToX(twelfth(i)), LTASSC(i) - 15) 'min
            Next
        Else
            linecount = 0
            For i = 0 To UBound(rmses, 3)
                If twelfth(i) = 250 Then
                    Debug.Print("250")
                End If
                k = 0
                For j = 0 To UBound(levels, 2)
                    If levels(ear, j) <> 0 Then
                        If k > 0 Then
                            ReDim Preserve IOx(k + 2) '***
                            ReDim Preserve IOy(k + 2) '***
                        Else
                            ReDim IOx(2)
                            ReDim IOy(2)
                        End If
                        IOx(k) = LTASSI(i) + (levels(ear, j) - 15 - LTASS(0, UBound(LTASS, 2))) 'valley
                        If (levels(ear, j) = 75) Then
                            IOx(k) = IOx(k) + LoudCorrI(i) - 10
                        End If
                        IOy(k) = valleys(ear, j, i)
                        k = k + 1
                        IOx(k) = LTASSI(i) + (levels(ear, j) - LTASS(0, UBound(LTASS, 2)))
                        If (levels(ear, j) = 75) Then
                            IOx(k) = IOx(k) + LoudCorrI(i) - 10
                        End If
                        IOy(k) = rmses(ear, j, i)
                        k = k + 1
                        IOx(k) = LTASSI(i) + (levels(ear, j) + 15 - LTASS(0, UBound(LTASS, 2))) 'peak
                        If (levels(ear, j) = 75) Then
                            IOx(k) = IOx(k) + LoudCorrI(i) - 10
                        End If
                        IOy(k) = peaks(ear, j, i)
                        k = k + 1 '***
                    End If
                Next
                lspmean = LeastSquaresPoint(IOx, IOy, LTASSC(i))
                lspmax = LeastSquaresPoint(IOx, IOy, LTASSC(i) + 15)
                lspmin = LeastSquaresPoint(IOx, IOy, LTASSC(i) - 15)
                meanlist.Add(FreqToX(twelfth(i)), lspmean) 'mean
                maxlist.Add(FreqToX(twelfth(i)), lspmax) 'max USE PEAK
                minlist.Add(FreqToX(twelfth(i)), lspmin) 'min USE VALLEY
                For jjj = 0 To UBound(axfreqs) - 1
                    If twelfth(i) = axfreqs(jjj) Then
                        objwriter.WriteLine("; " & axfreqs(jjj).ToString)
                        objwriter.WriteLine("symbol=" & Str$(linecount))
                        objwriter.WriteLine("pltcol=" & Str$(linecount))
                        objwriter.WriteLine("data")
                        For kkk = 0 To UBound(IOx)
                            objwriter.WriteLine(IOx(kkk).ToString & " " & IOy(kkk).ToString)
                        Next
                        objwriter.WriteLine("plot")
                        ' objwriter.WriteLine(lspmin.ToString & " " & lspmean.ToString & " " & lspmax.ToString)
                        slin = SlopeIntercept(IOx, IOy)
                        objwriter.WriteLine("%straline " & slin(0).ToString & " " & slin(1).ToString & " 0 20 100")
                        linecount = linecount + 1
                    End If
                Next
            Next
        End If
        objwriter.WriteLine("xlen*.75, ylen*.29, """)
        objwriter.WriteLine(earname(ear) & " ear")
        objwriter.WriteLine("|0,pltlwt=1,pltcol=0| 250")
        objwriter.WriteLine("|1,pltlwt=1,pltcol=1| 500")
        objwriter.WriteLine("|2,pltlwt=1,pltcol=2| 1000")
        objwriter.WriteLine("|3,pltlwt=1,pltcol=3| 2000")
        objwriter.WriteLine("|4,pltlwt=1,pltcol=4| 4000 Hz""")
        objwriter.Close()
        objwriter = Nothing

        ' show shifted freqencies on mean plot
        Dim fcc As Double, fcr As Double, idx As Integer, CompChecked As Boolean
        fcc = -1000.0
        fcr = -1000.0
        CompChecked = False
        If Me.cmbEar.SelectedIndex = 0 Then
            CompChecked = Me.chkLFreqComp.Checked
            If CompChecked Then
                If Len(Me.txtLFCC.Text) > 0 Then
                    fcc = Val(Me.txtLFCC.Text)
                Else
                    fcc = -1000.0 'missing value
                End If
                If Len(Me.txtLFCR.Text) > 0 Then
                    fcr = Val(Me.txtLFCR.Text)
                Else
                    fcr = -1000.0 'missing value
                End If
            End If
        Else
            CompChecked = Me.chkRFreqComp.Checked
            If CompChecked Then
                If Len(Me.txtRFCC.Text) > 0 Then
                    fcc = Val(Me.txtRFCC.Text)
                Else
                    fcc = -1000.0 'missing value
                End If
                If Len(Me.txtRFCR.Text) > 0 Then
                    fcr = Val(Me.txtRFCR.Text)
                Else
                    fcr = -1000.0 'missing value
                End If
            End If
        End If
        Dim fshifted(UBound(third)) As Double ' = {200.0, 250.0, 315.0, 400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600, 2000, 2159, 2399, 2674, 2959, 3287, 3664}
        Dim a As threevals
        Dim fsh1 As Double
        If fcc <> -1000.0 And fcr <> -1000.0 Then
            a = startfreq(fcr, fcc)
            fsh1 = 0.0
            For i = 0 To UBound(third)
                If third(i) <= a.f Then
                    fshifted(i) = third(i)
                Else
                    fshifted(i) = FComp(third(i), a.startf, a.fcr)
                    If fsh1 = 0.0 Then
                        fsh1 = fshifted(i) ' note first shifted frequency
                    End If
                End If

            Next
        End If
        If CompChecked Then
            fsh = fshifted
        Else
            fsh = third
            fsh1 = 1500
        End If
        Dim meanshiftedlistL As New PointPairList, meanshiftedlistH As New PointPairList
        Dim meantemp(meanlist.Count - 1) As Double
        Dim meanshiftcurveL As LineItem, meanshiftcurveH As LineItem
        For i = 0 To UBound(meantemp)
            meantemp(i) = meanlist(i).Y
        Next
        'Dim meanshifted() As Double
        meanshifted = interp1(twelfth, meantemp, fsh)
        For i = 0 To UBound(fshifted)
            If fsh(i) < fsh1 Then
                meanshiftedlistL.Add(FreqToX(fsh(i)), meanshifted(i))
            Else
                meanshiftedlistH.Add(FreqToX(fsh(i)), meanshifted(i))
            End If
        Next
        Dim avgcurve As LineItem
        '       200 HZ is at far left edge of graph
        If SettingsShowSIIPointsMenu.Checked Then
            meanshiftcurveL = myPane.AddCurve("", meanshiftedlistL, Color.MidnightBlue, SymbolType.Diamond) ' frequency compressed
            meanshiftcurveL.Line.IsVisible = False
            meanshiftcurveH = myPane.AddCurve("", meanshiftedlistH, Color.OrangeRed, SymbolType.Diamond) ' frequency compressed
            meanshiftcurveH.Line.IsVisible = False
        Else
            avgcurve = myPane.AddCurve("RMS", meanlist, Color.Green, SymbolType.None) 'mean
        End If
        Dim first As Boolean
        Dim fshone(0) As Double, mint() As Double
        If fcc <> -1000.0 And fcr <> -1000.0 Then
            first = True
            For i = 0 To meanlist.Count - 1
                If twelfth(i) < fsh1 Then '(was fcc)
                    lowlist.Add(meanlist(i))
                Else
                    If first Then
                        'interpolate first value
                        fshone(0) = fsh1
                        mint = interp1(twelfth, meantemp, fshone)
                        highlist.Add(FreqToX(fshone(0)), mint(0))
                        lowlist.Add(FreqToX(fshone(0)), mint(0)) ' finish off lows
                        first = False
                    Else
                        'highlist.Add(meanlist(i))
                        highlist.Add(meanlist(i).X, meanlist(i).Y)
                    End If
                End If
            Next
        End If

        Dim maxcurve As LineItem, mincurve As LineItem, highcurve As LineItem, lowcurve As LineItem
        If fcc <> -1000.0 And fcr <> -1000.0 Then
            '           If SettingsShowSIIPointsMenu.Checked Then
            highcurve = myPane.AddCurve("", highlist, Color.DarkOrange, SymbolType.None) ' frequency compressed
            lowcurve = myPane.AddCurve("RMS", lowlist, Color.Blue, SymbolType.None) ' frequency compressed
        Else
            avgcurve = myPane.AddCurve("RMS", meanlist, Color.Green, SymbolType.None) 'mean
            '       End If
        End If
        mincurve = myPane.AddCurve("Min", minlist, Color.LightBlue, SymbolType.None) 'min
        'mincurve.Line.Style = System.Drawing.Drawing2D.DashStyle.Dash
        'mincurve.Line.Fill = New Fill(Color.White)
        Dim minbelow() As PointD
        ReDim minbelow(minlist.Count - 1 + 3)
        For i = 0 To minlist.Count - 1
            minbelow(i).X = minlist(i).X
            minbelow(i).Y = minlist(i).Y
        Next
        minbelow(minlist.Count).X = minbelow(minlist.Count - 1).X
        minbelow(minlist.Count).Y = myPane.YAxis.Scale.Min
        minbelow(minlist.Count + 1).X = minbelow(0).X
        minbelow(minlist.Count + 1).Y = minbelow(minlist.Count).Y
        minbelow(minlist.Count + 2).X = minbelow(0).X
        minbelow(minlist.Count + 2).Y = minbelow(0).Y
        Dim polyminbelow As New PolyObj(minbelow, Color.White, Color.White)
        polyminbelow.IsClosedFigure = True
        myPane.GraphObjList.Add(polyminbelow)
        polyminbelow.ZOrder = ZOrder.E_BehindCurves

        maxcurve = myPane.AddCurve("Peak", maxlist, Color.LightBlue, SymbolType.None) 'max
        'maxcurve.Line.IsAntiAlias = True
        ' maxcurve.Line.Style = System.Drawing.Drawing2D.DashStyle.Dash
        ' maxcurve.Line.Fill = New Fill(Color.Transparent)

        Dim mpocount As Integer
        mpocount = 0
        For i = 0 To UBound(mpo, 2)
            If mpo(ear, i) > -1000.0 Then
                mpocount = mpocount + 1
            End If
        Next
        Dim list4 = New PointPairList()
        Dim mpocurve As LineItem
        For i = 0 To UBound(mpo, 2)
            If mpocount > 0 Then
                list4.Add(FreqToX(twelfth(i)), mpo(ear, i))
            Else
                list4.Add(FreqToX(twelfth(i)), 200.0) 'if mpo missing, use high value to avoid painting red
            End If
        Next i
        If cmbAidUn.SelectedIndex = 1 Then
            mpocurve = myPane.AddCurve("MPO", list4, Color.BlueViolet, SymbolType.None)
            mpocurve.Line.IsAntiAlias = True
        End If

        'mpocurve.Line.Fill = New Fill(Color.LightCyan)

        'maxcurve.Line.Fill = New Fill(Color.LightGreen)


        'Dim valleyCurve As LineItem
        'Dim list3 = New PointPairList()
        'For i = 0 To UBound(valleys, 3)
        '    list3.Add(FreqToX(twelfth(i)) , valleys(ear, ilev, i))
        'Next i
        'valleyCurve = myPane.AddCurve("valley", list3, Color.Green, SymbolType.None)
        'valleyCurve.Line.Fill = New Fill(Color.White)

        'Dim list1 = New PointPairList()
        'For i = 0 To UBound(rmses, 3)
        '    list1.Add(FreqToX(twelfth(i)) , rmses(ear, ilev, i))
        'Next i
        'myPane.AddCurve("rms" & Convert.ToString(levels(ilev)), list1, Color.Blue, SymbolType.None)

        'Dim peakCurve As LineItem
        'Dim list2 = New PointPairList()
        'For i = 0 To UBound(peaks, 3)
        '    list2.Add(FreqToX(twelfth(i)) , peaks(ear, ilev, i))
        'Next i
        'peakCurve = myPane.AddCurve("peak", list2, Color.MediumSeaGreen, SymbolType.None)

        ''threshCurve.Line.Fill = New Fill(Color.White)

        'peakCurve.Line.Fill = New Fill(Color.LightYellow)

        ''       For cond = 0 To UBound(ConditionName)
        'Dim fname As String
        'fname = "C:\Documents and Settings\cretho\Desktop\" & "rms" & Convert.ToString(levels(ilev)) & ".bmp"
        'myPane.GetImage().Save(fname, System.Drawing.Imaging.ImageFormat.Bmp)

        'mincurve.Line.Fill = New Fill(Color.White)

        ' clear area below thresh
        Dim threshbelow() As PointD
        ReDim threshbelow(threshlist.Count - 1 + 5)
        For i = 0 To threshlist.Count - 1
            threshbelow(i).X = threshlist.Item(i).X
            threshbelow(i).Y = threshlist.Item(i).Y
        Next
        i = threshlist.Count
        threshbelow(i).X = myPane.XAxis.Scale.Max
        threshbelow(i).Y = threshbelow(i - 1).Y
        i = i + 1
        threshbelow(i).X = threshbelow(i - 1).X
        threshbelow(i).Y = myPane.YAxis.Scale.Min
        i = i + 1
        threshbelow(i).X = myPane.XAxis.Scale.Min
        threshbelow(i).Y = threshbelow(i - 1).Y
        i = i + 1
        threshbelow(i).X = threshbelow(i - 1).X
        threshbelow(i).Y = threshbelow(0).Y
        i = i + 1
        threshbelow(i).X = threshbelow(0).X
        threshbelow(i).Y = threshbelow(0).Y

        Dim polythreshbelow As New PolyObj(threshbelow, Color.White, Color.White)
        polythreshbelow.IsClosedFigure = True
        myPane.GraphObjList.Add(polythreshbelow)
        polythreshbelow.ZOrder = ZOrder.E_BehindCurves

        ' clear area above ltass max
        Dim po1() As PointD
        ReDim po1(maxlist.Count - 1 + 3)
        For i = 0 To maxlist.Count - 1
            po1(i).X = maxlist.Item(i).X
            po1(i).Y = maxlist.Item(i).Y + 0.1 'y tweaked to not blank out 1 pixel too far
        Next
        po1(maxlist.Count).X = po1(maxlist.Count - 1).X
        po1(maxlist.Count).Y = myPane.YAxis.Scale.Max
        po1(maxlist.Count + 1).X = po1(0).X
        po1(maxlist.Count + 1).Y = po1(maxlist.Count).Y
        po1(maxlist.Count + 2).X = po1(0).X
        po1(maxlist.Count + 2).Y = po1(0).Y

        Dim polygo1 As New PolyObj(po1, Color.White, Color.White)
        polygo1.IsClosedFigure = True
        myPane.GraphObjList.Add(polygo1)
        polygo1.ZOrder = ZOrder.E_BehindCurves

        ' hatch area below mpo

        ' Commented out piece colors just one freq band
        'Dim idx As Integer
        'For i = 0 To list4.Count - 1
        '    If list4.Item(i).X = FreqToX(300) Then
        '        idx = i
        '    End If
        'Next
        'Dim listtemp As New PointPairList()
        'For i = 0 To idx
        '    listtemp.Add(list4.Item(i))
        'Next

        'Dim pobelow() As PointD
        'ReDim pobelow(listtemp.Count - 1 + 3)
        'For i = 0 To listtemp.Count - 1
        '    pobelow(i).X = listtemp.Item(i).X
        '    pobelow(i).Y = listtemp.Item(i).Y
        'Next
        'pobelow(listtemp.Count).X = pobelow(listtemp.Count - 1).X
        'pobelow(listtemp.Count).Y = myPane.YAxis.Scale.Min
        'pobelow(listtemp.Count + 1).X = pobelow(0).X
        'pobelow(listtemp.Count + 1).Y = pobelow(listtemp.Count).Y
        'pobelow(listtemp.Count + 2).X = pobelow(0).X
        'pobelow(listtemp.Count + 2).Y = pobelow(0).Y
        'Dim polybelow As New PolyObj(pobelow, Color.LightCyan, Color.LightCyan)
        'Dim brush1 As System.Drawing.Brush
        'If Me.SettingsStyleCombo.SelectedIndex = 1 Then
        '    brush1 = New System.Drawing.Drawing2D.HatchBrush(Drawing.Drawing2D.HatchStyle.NarrowHorizontal, Color.Cyan, Color.White)
        'Else
        '    brush1 = New System.Drawing.SolidBrush(Color.LightCyan)
        'End If
        'polybelow.Fill = New Fill(brush1)

        Dim pobelow() As PointD
        ReDim pobelow(list4.Count - 1 + 3)
        For i = 0 To list4.Count - 1
            pobelow(i).X = list4.Item(i).X
            pobelow(i).Y = list4.Item(i).Y
        Next
        pobelow(list4.Count).X = pobelow(list4.Count - 1).X
        pobelow(list4.Count).Y = myPane.YAxis.Scale.Min
        pobelow(list4.Count + 1).X = pobelow(0).X
        pobelow(list4.Count + 1).Y = pobelow(list4.Count).Y
        pobelow(list4.Count + 2).X = pobelow(0).X
        pobelow(list4.Count + 2).Y = pobelow(0).Y
        Dim polybelow As New PolyObj(pobelow, Color.LightCyan, Color.LightCyan)
        Dim brush1 As System.Drawing.Brush
        If Me.SettingsStyleCombo.SelectedIndex = 1 Then
            brush1 = New System.Drawing.Drawing2D.HatchBrush(Drawing.Drawing2D.HatchStyle.NarrowHorizontal, Color.Cyan, Color.White)
        Else
            brush1 = New System.Drawing.SolidBrush(Color.LightCyan)
        End If
        polybelow.Fill = New Fill(brush1)

        polybelow.IsClippedToChartRect = True
        polybelow.IsClosedFigure = True
        myPane.GraphObjList.Add(polybelow)
        polybelow.ZOrder = ZOrder.E_BehindCurves

        ' grey area above mpo
        Dim po() As PointD
        ReDim po(list4.Count - 1 + 3)
        For i = 0 To list4.Count - 1
            po(i).X = list4.Item(i).X
            po(i).Y = list4.Item(i).Y
        Next
        po(list4.Count).X = po(list4.Count - 1).X
        po(list4.Count).Y = myPane.YAxis.Scale.Max
        po(list4.Count + 1).X = po(0).X
        po(list4.Count + 1).Y = po(list4.Count).Y
        po(list4.Count + 2).X = po(0).X
        po(list4.Count + 2).Y = po(0).Y
        Dim OverColor As Color
        OverColor = Color.FromArgb(254, 254, 255)
        Dim polygo As New PolyObj(po, OverColor, OverColor)
        polygo.IsClippedToChartRect = True
        polygo.IsClosedFigure = True
        myPane.GraphObjList.Add(polygo)
        Dim brush2 As System.Drawing.Brush
        If Me.SettingsStyleCombo.SelectedIndex = 1 Then
            brush2 = New System.Drawing.Drawing2D.HatchBrush(Drawing.Drawing2D.HatchStyle.NarrowHorizontal, OverColor, Color.White)
        Else
            brush2 = New System.Drawing.SolidBrush(OverColor)
        End If
        polygo.Fill = New Fill(brush2)
        polygo.ZOrder = ZOrder.E_BehindCurves

        zgc.AxisChange()
        zgc.Refresh()
        ' Dim fname As String
        'fname = "C:\Documents and Settings\cretho\Desktop\" & ConditionName(cond) & " " & ConditionLevel(cond) & ".bmp"
        'myPane.GetImage().Save(fname, System.Drawing.Imaging.ImageFormat.Bmp)

        'zgc.DoPrint()

        '        Next
        Dim si As Double
        ' Interpolate threshold at third-octave frequencies
        thresh3 = interp1(threshfreq, threshtemp, third)
        ' Pick out maxes as third-octave frequencies
        For i = 0 To UBound(max3)
            max3(i) = maxlist(i * 4).Y
            min3(i) = minlist(i * 4).Y
            mean3(i) = meanlist(i * 4).Y
        Next
        Dim b As Integer
        If cmbBI.SelectedIndex = 2 Then
            b = 5
        Else
            b = cmbBI.SelectedIndex
        End If
        Dim sitemp As String
        Dim thresh17(0 To fsh.Count - 1) As Double

        If CompChecked And fcc <> -1000.0 And fcr <> -1000 Then
            thresh17 = interp1(threshfreq, threshtemp, fsh)
            si = SIIshift(maxlist, minlist, thresh17, b, fsh)
        Else
            si = SII(max3, min3, thresh3, b)
        End If
        If CompChecked And (fcc = -1000.0 Or fcr = -1000) Then
            sitemp = "***"
        Else
            sitemp = Format$(si, "0")
        End If
        Dim sitext As New TextObj("SII = " & sitemp, 0.04, 0.73, CoordType.PaneFraction)
        sitext.Location.AlignH = AlignH.Left
        sitext.Location.AlignV = AlignV.Top
        sitext.FontSpec.Border.IsVisible = False
        sitext.FontSpec.StringAlignment = StringAlignment.Near
        sitext.FontSpec.Size = myPane.XAxis.Scale.FontSpec.Size
        myPane.GraphObjList.Add(sitext)

        Dim tlist As New PointPairList
        Dim tcurve As LineItem

        tlist.Clear()
        If Not sitemp = "***" Then
            If CompChecked Then
                For i = 0 To fsh.Count - 1
                    tlist.Add(FreqToX(fsh(i)), threshf(i))
                Next
            Else
                For i = 0 To third.Count - 1
                    tlist.Add(FreqToX(third(i)), thresh3(i))
                Next
            End If
            'tcurve = myPane.AddCurve("", tlist, Color.Pink, SymbolType.Plus)
            'tcurve.Line.IsVisible = False
        End If
        'If Me.panLevels.Visible Then
        '    Dim lvtext As New TextObj(levlist, 0.05, 0.7, CoordType.PaneFraction)
        '    lvtext.Location.AlignH = AlignH.Left
        '    lvtext.Location.AlignV = AlignV.Top
        '    lvtext.FontSpec.Border.IsVisible = False
        '    lvtext.FontSpec.StringAlignment = StringAlignment.Near
        '    lvtext.FontSpec.Size = myPane.XAxis.Scale.FontSpec.Size
        '    myPane.GraphObjList.Add(lvtext)
        'End If
         zgc.Refresh()

        If NumberZ.Visible = True Then
            Call ShowNumbers()
        End If

    End Sub

    Private Sub radSpect_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSpect9.CheckedChanged, radSpect8.CheckedChanged, radSpect7.CheckedChanged, radSpect6.CheckedChanged, radSpect5.CheckedChanged, radSpect4.CheckedChanged, radSpect3.CheckedChanged, radSpect2.CheckedChanged, radSpect16.CheckedChanged, radSpect15.CheckedChanged, radSpect14.CheckedChanged, radSpect13.CheckedChanged, radSpect12.CheckedChanged, radSpect11.CheckedChanged, radSpect10.CheckedChanged, radSpect1.CheckedChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Dim radSpect As RadioButton = CType(sender, RadioButton)
        If radSpect.Checked Then
            Call DoPlot()
        End If
    End Sub


    Private Sub SettingsStyleCombo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsStyleCombo.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
    End Sub

    Private Sub cmbEar_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbEar.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        If cmbEar.SelectedIndex = 0 Then
            txtRFCC.Visible = False
            txtRFCR.Visible = False
            txtLFCC.Visible = True
            txtLFCR.Visible = True
            chkRFreqComp.Visible = False
            chkLFreqComp.Visible = True
            If chkLFreqComp.Checked Then
                txtLFCC.Enabled = True
                txtLFCR.Enabled = True
            End If
        Else
            txtLFCC.Visible = False
            txtLFCR.Visible = False
            txtRFCC.Visible = True
            txtRFCR.Visible = True
            chkLFreqComp.Visible = False
            chkRFreqComp.Visible = True
            If chkRFreqComp.Checked Then
                txtRFCC.Enabled = True
                txtRFCR.Enabled = True
            End If
        End If
        Call DoPlot()
    End Sub
    Private Sub RbuttonCtlThr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RbuttonCtlThr.Click
        RPanelThr.Visible = True
        LPanelThr.Visible = False
        For r = 0 To RThreshGrid.Rows.Count - 1
            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next
        RThreshGrid.CurrentCell = RThreshGrid.Rows(0).Cells(0) ' park at first cell
    End Sub

    Private Sub LButtonCtlThr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LButtonCtlThr.Click
        LPanelThr.Visible = True
        RPanelThr.Visible = False
        For r = 0 To LThreshGrid.Rows.Count - 1
            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next
        LThreshGrid.CurrentCell = LThreshGrid.Rows(0).Cells(0) ' park at first cell
    End Sub

    Private Sub butFill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butFill.Click
        If Me.lblXMLname.Text.Trim.Length = 0 And SavedXMLname.Trim.Length > 0 Then
            If File.Exists(SavedXMLname) Then
                Extract(SavedXMLname, 1) ' Force as if hand-entered.
                Model = "SharpEntered"
            End If
        End If
        Me.butFill.Visible = False
        Me.ToolTip1.ShowAlways = False
        Me.ToolTip1.ShowAlways = True
    End Sub

    Public Function RFormat(ByVal v As Object, ByVal fmt As String) As String
        Dim NSpaces As Integer
        Dim Temp As String

        Temp = Format(v, fmt)
        NSpaces = Len(fmt) - Len(Temp)
        If NSpaces < 0 Then NSpaces = 0
        RFormat = Space(NSpaces) & Temp
    End Function


    Private Function SII(ByRef Peak() As Double, ByRef Valley() As Double, ByRef Thresh() As Double, ByVal b As Integer) As Double
        Dim bi(,) As Double = { _
            {0.0083, 0.0095, 0.015, 0.0289, 0.044, 0.0578, 0.0653, 0.0711, 0.0818, 0.0844, 0.0882, 0.0898, 0.0868, 0.0844, 0.0771, 0.0527, 0.0364, 0.0185}, _
            {0.0, 0.0, 0.0153, 0.0284, 0.0363, 0.0422, 0.0509, 0.0584, 0.0667, 0.0774, 0.0893, 0.1104, 0.112, 0.0981, 0.0867, 0.0728, 0.0551, 0.0}, _
            {0.0365, 0.0279, 0.0405, 0.05, 0.053, 0.0518, 0.0514, 0.0575, 0.0717, 0.0873, 0.0902, 0.0938, 0.0928, 0.0678, 0.0498, 0.0312, 0.0215, 0.0253}, _
            {0.0168, 0.013, 0.0211, 0.0344, 0.0517, 0.0737, 0.0658, 0.0644, 0.0664, 0.0802, 0.0987, 0.1171, 0.0932, 0.0783, 0.0562, 0.0337, 0.0177, 0.0176}, _
            {0.0, 0.024, 0.033, 0.039, 0.0571, 0.0691, 0.0781, 0.0751, 0.0781, 0.0811, 0.0961, 0.0901, 0.0781, 0.0691, 0.048, 0.033, 0.027, 0.024}, _
            {0.0114, 0.0153, 0.0179, 0.0558, 0.0898, 0.0944, 0.0709, 0.066, 0.0628, 0.0672, 0.0747, 0.0755, 0.082, 0.0808, 0.0483, 0.0453, 0.0274, 0.0145}, _
            {0.0, 0.0255, 0.0256, 0.036, 0.0362, 0.0514, 0.0616, 0.077, 0.0718, 0.0718, 0.1075, 0.0921, 0.1026, 0.0922, 0.0719, 0.0461, 0.0306, 0.0}}

        Dim i As Integer
        Dim total As Double, numerator As Double, denominator As Double, ratio As Double
        For i = 0 To UBound(bi3)
            bi3(i) = bi(b, i + 1) ' Copy out appropriate Band importance function (skip 160 Hz value)
        Next
        total = 0.0
        For i = 0 To UBound(Peak)
            If Peak(i) < Thresh(i) Then
                ratio = 0.0
            ElseIf Valley(i) >= Thresh(i) Then
                ratio = 1.0
            Else
                numerator = Peak(i) - Thresh(i)
                denominator = Peak(i) - Valley(i)
                ratio = numerator / denominator
                If ratio > 1.0 Then
                    ratio = 1.0
                End If
            End If
            total = total + (bi3(i) * ratio) * 100
        Next
        If total > 100.0 Then
            total = 100.0
        End If
        SII = Math.Round(total, 0, MidpointRounding.AwayFromZero)

    End Function
    Private Function SIIshift(ByVal Peak As PointPairList, ByVal Valley As PointPairList, ByVal Thresh() As Double, ByVal b As Integer, ByVal shiftfreqs() As Double) As Double
        Dim bi(,) As Double = { _
            {0.0083, 0.0095, 0.015, 0.0289, 0.044, 0.0578, 0.0653, 0.0711, 0.0818, 0.0844, 0.0882, 0.0898, 0.0868, 0.0844, 0.0771, 0.0527, 0.0364, 0.0185}, _
            {0.0, 0.0, 0.0153, 0.0284, 0.0363, 0.0422, 0.0509, 0.0584, 0.0667, 0.0774, 0.0893, 0.1104, 0.112, 0.0981, 0.0867, 0.0728, 0.0551, 0.0}, _
            {0.0365, 0.0279, 0.0405, 0.05, 0.053, 0.0518, 0.0514, 0.0575, 0.0717, 0.0873, 0.0902, 0.0938, 0.0928, 0.0678, 0.0498, 0.0312, 0.0215, 0.0253}, _
            {0.0168, 0.013, 0.0211, 0.0344, 0.0517, 0.0737, 0.0658, 0.0644, 0.0664, 0.0802, 0.0987, 0.1171, 0.0932, 0.0783, 0.0562, 0.0337, 0.0177, 0.0176}, _
            {0.0, 0.024, 0.033, 0.039, 0.0571, 0.0691, 0.0781, 0.0751, 0.0781, 0.0811, 0.0961, 0.0901, 0.0781, 0.0691, 0.048, 0.033, 0.027, 0.024}, _
            {0.0114, 0.0153, 0.0179, 0.0558, 0.0898, 0.0944, 0.0709, 0.066, 0.0628, 0.0672, 0.0747, 0.0755, 0.082, 0.0808, 0.0483, 0.0453, 0.0274, 0.0145}, _
            {0.0, 0.0255, 0.0256, 0.036, 0.0362, 0.0514, 0.0616, 0.077, 0.0718, 0.0718, 0.1075, 0.0921, 0.1026, 0.0922, 0.0719, 0.0461, 0.0306, 0.0}}

        Dim i As Integer, n
        Dim total As Double, numerator As Double, denominator As Double, ratio As Double
        n = UBound(twelfth)
        Dim peak12(n) As Double, valley12(n) As Double
        For i = 0 To UBound(bi3)
            bi3(i) = bi(b, i + 1) ' Copy out appropriate Band importance function (skip 160 Hz value)
        Next
        For i = 0 To n
            valley12(i) = Valley(i).Y 'copy peak and valley numbers at 1/12 resolution
            peak12(i) = Peak(i).Y
        Next
        ' re-interpolate values at the shifted frequencies
        peakf = interp1(twelfth, peak12, shiftfreqs)
        valleyf = interp1(twelfth, valley12, shiftfreqs)
        ''threshf = interp1(audiometric, Thresh, shiftfreqs) ' I think the problem is here

        ReDim threshf(UBound(Thresh))
        For i = 0 To UBound(Thresh)
            threshf(i) = Thresh(i)
        Next
        total = 0.0
        For i = 0 To UBound(peakf)
            If peakf(i) < threshf(i) Then
                ratio = 0.0
            ElseIf valleyf(i) >= threshf(i) Then
                ratio = 1.0
            Else
                numerator = peakf(i) - threshf(i)
                denominator = peakf(i) - valleyf(i)
                ratio = numerator / denominator
                If ratio > 1.0 Then
                    ratio = 1.0
                End If
            End If
            total = total + (bi3(i) * ratio) * 100
        Next
        If total > 100.0 Then
            total = 100.0
        End If
        SIIshift = Math.Round(total, 0, MidpointRounding.AwayFromZero)

    End Function

    Private Sub cmbBI_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbBI.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
        Me.ToolTip1.ShowAlways = False
        Me.ToolTip1.ShowAlways = True
    End Sub

    Private Sub cmbAidUn_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAidUn.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
    End Sub

    Private Sub cmbSpeechType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbSpeechType.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
    End Sub


    Public Sub ShowNumbers()
        NumberZ.TextBox1.Text = Environment.NewLine
        Dim S As String, i As Integer
        S = "         "
        For i = 0 To UBound(third)
            S = S & third(i).ToString.PadLeft(5) & "  "
        Next
        NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
        S = "peak:   "
        For i = 0 To UBound(max3)
            S = S & RFormat(max3(i), "##0.00 ")
        Next i
        NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
        S = "mean:   "
        For i = 0 To UBound(mean3)
            S = S & RFormat(mean3(i), "##0.00 ")
        Next i
        NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
        S = "valley: "
        For i = 0 To UBound(min3)
            S = S & RFormat(min3(i), "##0.00 ")
        Next i
        NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
        S = "thresh: "
        For i = 0 To UBound(thresh3)
            S = S & RFormat(thresh3(i), "##0.00 ")
        Next i
        NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine

        Dim found As Boolean
        found = False
        For i = 0 To UBound(mean3)
            If mean3(i) <> 0.0 Then
                found = True
                Exit For
            End If
        Next
        If found = False Then
            Exit Sub
        End If

        If (Me.cmbEar.SelectedIndex = 0 And Me.chkLFreqComp.Checked) Then
            If (Len(Trim$(Me.txtLFCC.Text)) = 0) Or (Len(Trim$(Me.txtLFCR.Text)) = 0) Then
                Exit Sub
            End If
        End If
        If (Me.cmbEar.SelectedIndex = 1 And Me.chkRFreqComp.Checked) Then
            If (Len(Trim$(Me.txtRFCC.Text)) = 0) Or (Len(Trim$(Me.txtRFCR.Text)) = 0) Then
                Exit Sub
            End If
        End If

        If (Me.cmbEar.SelectedIndex = 0 And Me.chkLFreqComp.Checked) Or (Me.cmbEar.SelectedIndex = 1 And Me.chkRFreqComp.Checked) Then
            NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & Environment.NewLine
            S = "         "
            For i = 0 To UBound(fsh)
                S = S & RFormat(fsh(i), "####0  ")
            Next
            NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
            S = "peak:   "
            For i = 0 To UBound(peakf)
                S = S & RFormat(peakf(i), "##0.00 ")
            Next i
            NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
            S = "valley: "
            For i = 0 To UBound(valleyf)
                S = S & RFormat(valleyf(i), "##0.00 ")
            Next i
            NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
            S = "thresh: "
            For i = 0 To UBound(threshf)
                S = S & RFormat(threshf(i), "##0.00 ")
            Next i
            NumberZ.TextBox1.Text = NumberZ.TextBox1.Text & S & Environment.NewLine
        End If
    End Sub
    Private Function CheckEntries() As Boolean
        Dim sorf As Boolean ' success or failure
        Dim ear As Integer, r As Integer, c As Integer, count As Integer, rowcount As Integer
        Dim threshtable(1) As DataTable
        Dim temp As String
        Dim v As Double

        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)

        threshtable(0) = LThreshTable
        threshtable(1) = RThreshTable

        sorf = False
        If Me.txtClientID.Text.Trim.Length <= 0 Then
            MessageBox.Show("ClientId is blank", "Parameter Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Me.txtClientID.Focus()
            sorf = False
            Return sorf
        End If

        For ear = 0 To 1
            rowcount = 0
            For r = 0 To threshtable(ear).Rows.Count - 2
                count = 0
                For c = 0 To threshtable(ear).Columns.Count - 1
                    temp = Trim(threshtable(ear).Rows(r).Item(c).ToString)
                    If Len(temp) > 0 Then
                        If Not IsNumeric(temp) Then
                            If ear = 0 Then
                                RPanelThr.Visible = False
                                LPanelThr.Visible = True
                                LThreshGrid.CurrentCell = LThreshGrid.Rows(r).Cells(c) ' park at first cell
                                LThreshGrid.BeginEdit(True)
                            Else
                                LPanelThr.Visible = False
                                RPanelThr.Visible = True
                                RThreshGrid.CurrentCell = RThreshGrid.Rows(r).Cells(c) ' park at first cell
                                RThreshGrid.BeginEdit(True)
                            End If
                            MessageBox.Show("Value must be numeric (or blank). ", "Parameter Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            sorf = False
                            Return sorf
                        End If
                        v = Val(temp)
                        If v < -40.0 Or v > 140.0 Then
                            If ear = 0 Then
                                RPanelThr.Visible = False
                                LPanelThr.Visible = True
                                LThreshGrid.CurrentCell = LThreshGrid.Rows(r).Cells(c) ' park at first cell
                                LThreshGrid.BeginEdit(True)
                            Else
                                LPanelThr.Visible = False
                                RPanelThr.Visible = True
                                RThreshGrid.CurrentCell = RThreshGrid.Rows(r).Cells(c) ' park at first cell
                                RThreshGrid.BeginEdit(True)
                            End If
                            MessageBox.Show("Value must be in range -40 to +140.", "Parameter Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            sorf = False
                            Return sorf
                        End If
                        count = count + 1
                    End If
                Next
                If count > 0 And count < 2 Then
                    If ear = 0 Then
                        RPanelThr.Visible = False
                        LPanelThr.Visible = True
                        LThreshGrid.CurrentCell = LThreshGrid.Rows(r).Cells(0) ' park at first cell
                    Else
                        LPanelThr.Visible = False
                        RPanelThr.Visible = True
                        RThreshGrid.CurrentCell = RThreshGrid.Rows(r).Cells(0) ' park at first cell
                    End If
                    MessageBox.Show("Must be at least 2 values (or none) on the row " & RThreshGrid.Rows(r).HeaderCell.Value.ToString, "Parameter Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    sorf = False
                    Return sorf
                End If
                If r >= 1 And r <= 6 Then
                    If count > 0 Then
                        rowcount = rowcount + 1
                    End If
                End If
            Next
            If rowcount > 0 And rowcount < 2 Then
                If ear = 0 Then
                    RPanelThr.Visible = False
                    LPanelThr.Visible = True
                    LThreshGrid.CurrentCell = LThreshGrid.Rows(1).Cells(0) ' park at first cell
                Else
                    LPanelThr.Visible = False
                    RPanelThr.Visible = True
                    RThreshGrid.CurrentCell = RThreshGrid.Rows(1).Cells(0) ' park at first cell
                End If
                MessageBox.Show("Must be at least 2 rows of levels 50 to 75", "Parameter Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                sorf = False
                Return sorf
            End If
        Next

        sorf = True
        Return sorf
    End Function

    'Private Function oldRECDbyAge(ByVal ageindex, ByVal freqindex) As Double
    '    Dim RECDage(,) As Double = { _
    '        {1, -0.31, 3.12, 6.28, 8.82, 8.69, 9.74, 12.2, 16.57, 16.38}, _
    '        {2, -0.55, 3.15, 6.14, 8.52, 8.29, 9.27, 11.12, 15.18, 14.97}, _
    '        {3, -0.69, 3.17, 6.06, 8.35, 8.05, 8.99, 10.49, 14.37, 14.14}, _
    '        {4, -0.8, 3.19, 6, 8.22, 7.89, 8.8, 10.04, 13.8, 13.55}, _
    '        {5, -0.87, 3.2, 5.96, 8.13, 7.76, 8.65, 9.69, 13.35, 13.1}, _
    '        {6, -0.94, 3.21, 5.92, 8.05, 7.65, 8.52, 9.4, 12.99, 12.72}, _
    '        {7, -0.99, 3.22, 5.89, 7.98, 7.56, 8.42, 9.16, 12.68, 12.41}, _
    '        {8, -1.04, 3.22, 5.86, 7.93, 7.48, 8.33, 8.96, 12.41, 12.14}, _
    '        {9, -1.08, 3.23, 5.84, 7.88, 7.42, 8.25, 8.77, 12.18, 11.9}, _
    '        {10, -1.12, 3.24, 5.82, 7.83, 7.35, 8.17, 8.61, 11.96, 11.68}, _
    '        {11, -1.15, 3.24, 5.8, 7.79, 7.3, 8.11, 8.46, 11.77, 11.49}, _
    '        {12, -1.18, 3.24, 5.78, 7.75, 7.25, 8.05, 8.32, 11.6, 11.31}, _
    '        {13, -1.21, 3.25, 5.77, 7.72, 7.2, 8, 8.2, 11.44, 11.15}, _
    '        {14, -1.23, 3.25, 5.75, 7.69, 7.16, 7.95, 8.08, 11.29, 11}, _
    '        {15, -1.26, 3.26, 5.74, 7.66, 7.12, 7.9, 7.98, 11.15, 10.86}, _
    '        {16, -1.28, 3.26, 5.73, 7.63, 7.08, 7.85, 7.87, 11.02, 10.72}, _
    '        {17, -1.3, 3.26, 5.71, 7.6, 7.05, 7.81, 7.78, 10.9, 10.6}, _
    '        {18, -1.32, 3.26, 5.7, 7.58, 7.01, 7.77, 7.69, 10.79, 10.48}, _
    '        {19, -1.34, 3.27, 5.69, 7.55, 6.98, 7.74, 7.61, 10.68, 10.37}, _
    '        {20, -1.36, 3.27, 5.68, 7.53, 6.95, 7.7, 7.53, 10.58, 10.27}, _
    '        {21, -1.38, 3.27, 5.67, 7.51, 6.92, 7.67, 7.45, 10.48, 10.17}, _
    '        {22, -1.39, 3.27, 5.66, 7.49, 6.9, 7.64, 7.38, 10.39, 10.07}, _
    '        {23, -1.41, 3.28, 5.65, 7.47, 6.87, 7.61, 7.31, 10.3, 9.98}, _
    '        {24, -1.42, 3.28, 5.64, 7.45, 6.85, 7.58, 7.24, 10.21, 9.9}, _
    '        {25, -1.44, 3.28, 5.64, 7.44, 6.82, 7.55, 7.18, 10.13, 9.81}, _
    '        {26, -1.45, 3.28, 5.63, 7.42, 6.8, 7.52, 7.12, 10.05, 9.73}, _
    '        {27, -1.46, 3.28, 5.62, 7.4, 6.78, 7.5, 7.06, 9.98, 9.66}, _
    '        {28, -1.48, 3.29, 5.61, 7.39, 6.76, 7.47, 7, 9.91, 9.58}, _
    '        {29, -1.49, 3.29, 5.61, 7.37, 6.74, 7.45, 6.95, 9.84, 9.51}, _
    '        {30, -1.5, 3.29, 5.6, 7.36, 6.72, 7.43, 6.89, 9.77, 9.44}, _
    '        {31, -1.51, 3.29, 5.59, 7.34, 6.7, 7.4, 6.84, 9.7, 9.37}, _
    '        {32, -1.52, 3.29, 5.59, 7.33, 6.68, 7.38, 6.79, 9.64, 9.31}, _
    '        {33, -1.53, 3.29, 5.58, 7.32, 6.66, 7.36, 6.75, 9.58, 9.25}, _
    '        {34, -1.54, 3.3, 5.57, 7.3, 6.64, 7.34, 6.7, 9.52, 9.19}, _
    '        {35, -1.55, 3.3, 5.57, 7.29, 6.63, 7.32, 6.65, 9.46, 9.13}, _
    '        {36, -1.56, 3.3, 5.56, 7.28, 6.61, 7.3, 6.61, 9.4, 9.07}, _
    '        {37, -1.57, 3.3, 5.56, 7.27, 6.6, 7.28, 6.57, 9.35, 9.01}, _
    '        {38, -1.58, 3.3, 5.55, 7.26, 6.58, 7.27, 6.53, 9.29, 8.96}, _
    '        {39, -1.59, 3.3, 5.55, 7.24, 6.57, 7.25, 6.48, 9.24, 8.91}, _
    '        {40, -1.6, 3.3, 5.54, 7.23, 6.55, 7.23, 6.45, 9.19, 8.85}, _
    '        {41, -1.61, 3.31, 5.54, 7.22, 6.54, 7.21, 6.41, 9.14, 8.8}, _
    '        {42, -1.62, 3.31, 5.53, 7.21, 6.52, 7.2, 6.37, 9.09, 8.76}, _
    '        {43, -1.63, 3.31, 5.53, 7.2, 6.51, 7.18, 6.33, 9.05, 8.71}, _
    '        {44, -1.63, 3.31, 5.52, 7.19, 6.5, 7.17, 6.3, 9, 8.66}, _
    '        {45, -1.64, 3.31, 5.52, 7.18, 6.48, 7.15, 6.26, 8.96, 8.61}, _
    '        {46, -1.65, 3.31, 5.51, 7.17, 6.47, 7.14, 6.23, 8.91, 8.57}, _
    '        {47, -1.66, 3.31, 5.51, 7.16, 6.46, 7.12, 6.19, 8.87, 8.53}, _
    '        {48, -1.66, 3.31, 5.51, 7.16, 6.44, 7.11, 6.16, 8.83, 8.48}, _
    '        {49, -1.67, 3.31, 5.5, 7.15, 6.43, 7.09, 6.13, 8.79, 8.44}, _
    '        {50, -1.68, 3.32, 5.5, 7.14, 6.42, 7.08, 6.1, 8.75, 8.4}, _
    '        {51, -1.69, 3.32, 5.49, 7.13, 6.41, 7.07, 6.07, 8.71, 8.36}, _
    '        {52, -1.69, 3.32, 5.49, 7.12, 6.4, 7.05, 6.04, 8.67, 8.32}, _
    '        {53, -1.7, 3.32, 5.49, 7.11, 6.39, 7.04, 6.01, 8.63, 8.28}, _
    '        {54, -1.71, 3.32, 5.48, 7.1, 6.38, 7.03, 5.98, 8.59, 8.24}, _
    '        {55, -1.71, 3.32, 5.48, 7.1, 6.37, 7.02, 5.95, 8.56, 8.21}, _
    '        {56, -1.72, 3.32, 5.47, 7.09, 6.36, 7, 5.92, 8.52, 8.17}, _
    '        {57, -1.73, 3.32, 5.47, 7.08, 6.35, 6.99, 5.89, 8.48, 8.13}, _
    '        {58, -1.73, 3.32, 5.47, 7.07, 6.33, 6.98, 5.87, 8.45, 8.1}, _
    '        {59, -1.74, 3.32, 5.46, 7.07, 6.33, 6.97, 5.84, 8.41, 8.06}, _
    '        {60, -1.74, 3.32, 5.46, 7.06, 6.32, 6.96, 5.81, 8.38, 8.03}, _
    '        {72, -1.81, 3.33, 5.42, 6.98, 6.21, 6.83, 5.53, 8.02, 7.66}, _
    '        {84, -1.86, 3.34, 5.39, 6.91, 6.12, 6.73, 5.29, 7.71, 7.34}, _
    '        {96, -1.91, 3.35, 5.37, 6.86, 6.04, 6.64, 5.08, 7.44, 7.07}, _
    '        {108, -1.95, 3.35, 5.34, 6.81, 5.97, 6.56, 4.9, 7.21, 6.83}, _
    '        {120, -1.99, 3.36, 5.32, 6.76, 5.91, 6.48, 4.73, 7, 6.61}}
    '    If ageindex = 0 Then
    '        Return (0.0) 'Adult
    '    Else
    '        Return (RECDage(65 - ageindex, freqindex + 1))
    '    End If
    'End Function

    Private Function RECDbyAge(ByVal ageindex, ByVal freqindex) As Double
        Dim RECDage(,) As Double = { _
            {1, 3, 8, 9, 12, 15, 15, 16, 20, 23}, _
            {2, 3, 7, 9, 11, 14, 14, 14, 19, 21}, _
            {3, 3, 7, 9, 11, 13, 13, 13, 18, 20}, _
            {4, 3, 7, 8, 11, 12, 13, 13, 18, 19}, _
            {5, 3, 7, 8, 11, 12, 12, 13, 17, 18}, _
            {6, 3, 6, 8, 11, 12, 12, 12, 17, 18}, _
            {7, 3, 6, 8, 10, 11, 12, 12, 16, 18}, _
            {8, 3, 6, 8, 10, 11, 11, 12, 16, 18}, _
            {9, 3, 6, 8, 10, 11, 11, 11, 16, 17}, _
            {10, 3, 6, 8, 10, 10, 11, 11, 16, 17}, _
            {11, 3, 6, 8, 10, 10, 11, 11, 16, 17}, _
            {12, 3, 6, 8, 10, 10, 11, 11, 15, 17}, _
            {13, 3, 6, 8, 10, 10, 11, 11, 15, 16}, _
            {14, 3, 6, 8, 10, 10, 10, 11, 15, 16}, _
            {15, 3, 6, 8, 10, 10, 10, 10, 15, 16}, _
            {16, 3, 6, 8, 10, 10, 10, 10, 15, 16}, _
            {17, 3, 6, 7, 10, 10, 10, 10, 15, 16}, _
            {18, 3, 6, 7, 10, 10, 10, 10, 15, 16}, _
            {19, 3, 6, 7, 10, 9, 10, 10, 14, 15}, _
            {20, 3, 6, 7, 10, 9, 10, 10, 14, 15}, _
            {21, 3, 6, 7, 10, 9, 10, 10, 14, 15}, _
            {22, 3, 5, 7, 10, 9, 10, 10, 14, 15}, _
            {23, 3, 5, 7, 10, 9, 10, 10, 14, 15}, _
            {24, 3, 5, 7, 9, 9, 10, 10, 14, 15}, _
            {25, 3, 5, 7, 9, 9, 9, 9, 14, 15}, _
            {26, 3, 5, 7, 9, 9, 9, 9, 14, 15}, _
            {27, 3, 5, 7, 9, 9, 9, 9, 14, 15}, _
            {28, 3, 5, 7, 9, 9, 9, 9, 14, 14}, _
            {29, 3, 5, 7, 9, 9, 9, 9, 14, 14}, _
            {30, 3, 5, 7, 9, 9, 9, 9, 13, 14}, _
            {31, 3, 5, 7, 9, 9, 9, 9, 13, 14}, _
            {32, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {33, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {34, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {35, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {36, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {37, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {38, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {39, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {40, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {41, 3, 5, 7, 9, 8, 9, 9, 13, 14}, _
            {42, 3, 5, 7, 9, 8, 9, 9, 13, 13}, _
            {43, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {44, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {45, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {46, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {47, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {48, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {49, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {50, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {51, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {52, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {53, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {54, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {55, 3, 5, 7, 9, 8, 8, 8, 13, 13}, _
            {56, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {57, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {58, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {59, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {60, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {72, 3, 5, 7, 9, 7, 8, 8, 13, 13}, _
            {84, 3, 5, 6, 9, 7, 7, 8, 13, 13}, _
            {96, 3, 4, 6, 8, 7, 7, 8, 13, 13}, _
            {108, 3, 4, 6, 8, 7, 7, 8, 13, 13}, _
            {120, 3, 4, 6, 8, 7, 7, 8, 13, 13}, _
            {999, 3, 4, 6, 8, 7, 7, 8, 13, 13}}     ' adult

        Return RECDage(65 - ageindex, freqindex + 1)

     End Function

    Private Function startfreq(ByVal fcr As Double, ByVal f As Double) As threevals
        Dim table(,) As Double = { _
        {0, 1500, 1600, 1700, 1800, 1900, 2000, 2100, 2200, 2300, 2400, 2500, 2600, 2700, 2800, 2900, 3000, 3100, 3200, 3300, 3400, 3500, 3600, 3700, 3800, 3900, 4000, 4100, 4200, 4300, 4400, 4500, 4600, 4700, 4800, 4900, 5000, 5100, 5200, 5300, 5400, 5500, 5600, 5700, 5800, 5900, 6000}, _
        {1.5, 1444.9, 1545.0, 1645.1, 1745.1, 1845.2, 1945.3, 2045.4, 2145.4, 2245.5, 2345.5, 2445.6, 2545.6, 2645.6, 2745.7, 2845.7, 2945.7, 3045.8, 3145.8, 3245.8, 3345.8, 3445.9, 3545.9, 3645.9, 3745.9, 3846.0, 3946.0, 4046.0, 4146.0, 4246.0, 4346.0, 4446.0, 4546.1, 4646.1, 4746.1, 4846.1, 4946.1, 5046.1, 5146.1, 5246.1, 5346.1, 5446.2, 5546.2, 5646.2, 5746.2, 5846.2, 5946.2}, _
        {1.6, 1438.1, 1538.2, 1638.3, 1738.4, 1838.5, 1938.6, 2038.6, 2138.7, 2238.7, 2338.8, 2438.8, 2538.9, 2638.9, 2739.0, 2839.0, 2939.0, 3039.1, 3139.1, 3239.1, 3339.1, 3439.2, 3539.2, 3639.2, 3739.2, 3839.2, 3939.3, 4039.3, 4139.3, 4239.3, 4339.3, 4439.3, 4539.4, 4639.4, 4739.4, 4839.4, 4939.4, 5039.4, 5139.4, 5239.4, 5339.5, 5439.5, 5539.5, 5639.5, 5739.5, 5839.5, 5939.5}, _
        {1.7, 1432.1, 1532.3, 1632.4, 1732.5, 1832.5, 1932.6, 2032.7, 2132.8, 2232.8, 2332.9, 2432.9, 2533.0, 2633.0, 2733.0, 2833.1, 2933.1, 3033.1, 3133.2, 3233.2, 3333.2, 3433.3, 3533.3, 3633.3, 3733.3, 3833.3, 3933.4, 4033.4, 4133.4, 4233.4, 4333.4, 4433.4, 4533.5, 4633.5, 4733.5, 4833.5, 4933.5, 5033.5, 5133.5, 5233.5, 5333.6, 5433.6, 5533.6, 5633.6, 5733.6, 5833.6, 5933.6}, _
        {1.8, 1426.9, 1527.0, 1627.1, 1727.2, 1827.3, 1927.4, 2027.4, 2127.5, 2227.6, 2327.6, 2427.7, 2527.7, 2627.8, 2727.8, 2827.8, 2927.9, 3027.9, 3127.9, 3228.0, 3328.0, 3428.0, 3528.0, 3628.1, 3728.1, 3828.1, 3928.1, 4028.1, 4128.1, 4228.2, 4328.2, 4428.2, 4528.2, 4628.2, 4728.2, 4828.3, 4928.3, 5028.3, 5128.3, 5228.3, 5328.3, 5428.3, 5528.3, 5628.3, 5728.4, 5828.4, 5928.4}, _
        {1.9, 1422.2, 1522.3, 1622.4, 1722.5, 1822.6, 1922.7, 2022.7, 2122.8, 2222.9, 2322.9, 2423.0, 2523.0, 2623.1, 2723.1, 2823.1, 2923.2, 3023.2, 3123.2, 3223.3, 3323.3, 3423.3, 3523.3, 3623.4, 3723.4, 3823.4, 3923.4, 4023.4, 4123.5, 4223.5, 4323.5, 4423.5, 4523.5, 4623.5, 4723.6, 4823.6, 4923.6, 5023.6, 5123.6, 5223.6, 5323.6, 5423.6, 5523.6, 5623.7, 5723.7, 5823.7, 5923.7}, _
        {2.0, 1418.0, 1518.1, 1618.2, 1718.3, 1818.4, 1918.5, 2018.5, 2118.6, 2218.7, 2318.7, 2418.8, 2518.8, 2618.8, 2718.9, 2818.9, 2919.0, 3019.0, 3119.0, 3219.1, 3319.1, 3419.1, 3519.1, 3619.2, 3719.2, 3819.2, 3919.2, 4019.2, 4119.3, 4219.3, 4319.3, 4419.3, 4519.3, 4619.3, 4719.3, 4819.4, 4919.4, 5019.4, 5119.4, 5219.4, 5319.4, 5419.4, 5519.4, 5619.4, 5719.5, 5819.5, 5919.5}, _
        {2.1, 1414.2, 1514.3, 1614.4, 1714.5, 1814.6, 1914.7, 2014.7, 2114.8, 2214.8, 2314.9, 2415.0, 2515.0, 2615.0, 2715.1, 2815.1, 2915.2, 3015.2, 3115.2, 3215.2, 3315.3, 3415.3, 3515.3, 3615.3, 3715.4, 3815.4, 3915.4, 4015.4, 4115.4, 4215.5, 4315.5, 4415.5, 4515.5, 4615.5, 4715.5, 4815.5, 4915.6, 5015.6, 5115.6, 5215.6, 5315.6, 5415.6, 5515.6, 5615.6, 5715.6, 5815.7, 5915.7}, _
        {2.2, 1410.7, 1510.8, 1610.9, 1711.0, 1811.1, 1911.2, 2011.3, 2111.3, 2211.4, 2311.4, 2411.5, 2511.5, 2611.6, 2711.6, 2811.7, 2911.7, 3011.7, 3111.8, 3211.8, 3311.8, 3411.8, 3511.9, 3611.9, 3711.9, 3811.9, 3911.9, 4012.0, 4112.0, 4212.0, 4312.0, 4412.0, 4512.0, 4612.1, 4712.1, 4812.1, 4912.1, 5012.1, 5112.1, 5212.1, 5312.1, 5412.2, 5512.2, 5612.2, 5712.2, 5812.2, 5912.2}, _
        {2.3, 1407.6, 1507.7, 1607.8, 1707.9, 1808.0, 1908.1, 2008.1, 2108.2, 2208.2, 2308.3, 2408.3, 2508.4, 2608.4, 2708.5, 2808.5, 2908.5, 3008.6, 3108.6, 3208.6, 3308.7, 3408.7, 3508.7, 3608.7, 3708.8, 3808.8, 3908.8, 4008.8, 4108.8, 4208.8, 4308.9, 4408.9, 4508.9, 4608.9, 4708.9, 4808.9, 4908.9, 5009.0, 5109.0, 5209.0, 5309.0, 5409.0, 5509.0, 5609.0, 5709.0, 5809.0, 5909.0}, _
        {2.4, 1404.7, 1504.8, 1604.9, 1705.0, 1805.1, 1905.2, 2005.2, 2105.3, 2205.4, 2305.4, 2405.5, 2505.5, 2605.5, 2705.6, 2805.6, 2905.7, 3005.7, 3105.7, 3205.7, 3305.8, 3405.8, 3505.8, 3605.8, 3705.9, 3805.9, 3905.9, 4005.9, 4105.9, 4206.0, 4306.0, 4406.0, 4506.0, 4606.0, 4706.0, 4806.0, 4906.1, 5006.1, 5106.1, 5206.1, 5306.1, 5406.1, 5506.1, 5606.1, 5706.1, 5806.1, 5906.2}, _
        {2.5, 1402.1, 1502.2, 1602.3, 1702.4, 1802.5, 1902.5, 2002.6, 2102.7, 2202.7, 2302.8, 2402.8, 2502.9, 2602.9, 2702.9, 2803.0, 2903.0, 3003.0, 3103.1, 3203.1, 3303.1, 3403.1, 3503.2, 3603.2, 3703.2, 3803.2, 3903.2, 4003.3, 4103.3, 4203.3, 4303.3, 4403.3, 4503.3, 4603.4, 4703.4, 4803.4, 4903.4, 5003.4, 5103.4, 5203.4, 5303.4, 5403.4, 5503.5, 5603.5, 5703.5, 5803.5, 5903.5}, _
        {2.6, 1399.6, 1499.7, 1599.8, 1699.9, 1800.0, 1900.1, 2000.2, 2100.2, 2200.3, 2300.3, 2400.4, 2500.4, 2600.5, 2700.5, 2800.5, 2900.6, 3000.6, 3100.6, 3200.6, 3300.7, 3400.7, 3500.7, 3600.7, 3700.8, 3800.8, 3900.8, 4000.8, 4100.8, 4200.8, 4300.9, 4400.9, 4500.9, 4600.9, 4700.9, 4800.9, 4900.9, 5001.0, 5101.0, 5201.0, 5301.0, 5401.0, 5501.0, 5601.0, 5701.0, 5801.0, 5901.0}, _
        {2.7, 1397.4, 1497.5, 1597.6, 1697.7, 1797.8, 1897.8, 1997.9, 2098.0, 2198.0, 2298.1, 2398.1, 2498.1, 2598.2, 2698.2, 2798.3, 2898.3, 2998.3, 3098.4, 3198.4, 3298.4, 3398.4, 3498.4, 3598.5, 3698.5, 3798.5, 3898.5, 3998.5, 4098.6, 4198.6, 4298.6, 4398.6, 4498.6, 4598.6, 4698.6, 4798.7, 4898.7, 4998.7, 5098.7, 5198.7, 5298.7, 5398.7, 5498.7, 5598.7, 5698.8, 5798.8, 5898.8}, _
        {2.8, 1395.3, 1495.4, 1595.5, 1695.6, 1795.7, 1895.7, 1995.8, 2095.9, 2195.9, 2296.0, 2396.0, 2496.0, 2596.1, 2696.1, 2796.2, 2896.2, 2996.2, 3096.2, 3196.3, 3296.3, 3396.3, 3496.3, 3596.4, 3696.4, 3796.4, 3896.4, 3996.4, 4096.5, 4196.5, 4296.5, 4396.5, 4496.5, 4596.5, 4696.5, 4796.6, 4896.6, 4996.6, 5096.6, 5196.6, 5296.6, 5396.6, 5496.6, 5596.6, 5696.6, 5796.7, 5896.7}, _
        {2.9, 1393.4, 1493.5, 1593.6, 1693.6, 1793.7, 1893.8, 1993.9, 2093.9, 2194.0, 2294.0, 2394.1, 2494.1, 2594.1, 2694.2, 2794.2, 2894.2, 2994.3, 3094.3, 3194.3, 3294.3, 3394.4, 3494.4, 3594.4, 3694.4, 3794.4, 3894.5, 3994.5, 4094.5, 4194.5, 4294.5, 4394.5, 4494.6, 4594.6, 4694.6, 4794.6, 4894.6, 4994.6, 5094.6, 5194.6, 5294.6, 5394.7, 5494.7, 5594.7, 5694.7, 5794.7, 5894.7}, _
        {3.0, 1391.5, 1491.6, 1591.7, 1691.8, 1791.9, 1892.0, 1992.0, 2092.1, 2192.1, 2292.2, 2392.2, 2492.3, 2592.3, 2692.3, 2792.4, 2892.4, 2992.4, 3092.5, 3192.5, 3292.5, 3392.5, 3492.6, 3592.6, 3692.6, 3792.6, 3892.6, 3992.7, 4092.7, 4192.7, 4292.7, 4392.7, 4492.7, 4592.7, 4692.8, 4792.8, 4892.8, 4992.8, 5092.8, 5192.8, 5292.8, 5392.8, 5492.8, 5592.8, 5692.9, 5792.9, 5892.9}, _
        {3.1, 1389.9, 1490.0, 1590.0, 1690.1, 1790.2, 1890.3, 1990.3, 2090.4, 2190.4, 2290.5, 2390.5, 2490.6, 2590.6, 2690.6, 2790.7, 2890.7, 2990.7, 3090.8, 3190.8, 3290.8, 3390.8, 3490.9, 3590.9, 3690.9, 3790.9, 3890.9, 3990.9, 4091.0, 4191.0, 4291.0, 4391.0, 4491.0, 4591.0, 4691.0, 4791.1, 4891.1, 4991.1, 5091.1, 5191.1, 5291.1, 5391.1, 5491.1, 5591.1, 5691.1, 5791.1, 5891.2}, _
        {3.2, 1388.3, 1488.4, 1588.5, 1688.5, 1788.6, 1888.7, 1988.7, 2088.8, 2188.8, 2288.9, 2388.9, 2489.0, 2589.0, 2689.0, 2789.1, 2889.1, 2989.1, 3089.2, 3189.2, 3289.2, 3389.2, 3489.3, 3589.3, 3689.3, 3789.3, 3889.3, 3989.3, 4089.4, 4189.4, 4289.4, 4389.4, 4489.4, 4589.4, 4689.4, 4789.4, 4889.5, 4989.5, 5089.5, 5189.5, 5289.5, 5389.5, 5489.5, 5589.5, 5689.5, 5789.5, 5889.5}, _
        {3.3, 1386.8, 1486.9, 1587.0, 1687.1, 1787.1, 1887.2, 1987.3, 2087.3, 2187.4, 2287.4, 2387.4, 2487.5, 2587.5, 2687.5, 2787.6, 2887.6, 2987.6, 3087.7, 3187.7, 3287.7, 3387.7, 3487.8, 3587.8, 3687.8, 3787.8, 3887.8, 3987.8, 4087.9, 4187.9, 4287.9, 4387.9, 4487.9, 4587.9, 4687.9, 4787.9, 4888.0, 4988.0, 5088.0, 5188.0, 5288.0, 5388.0, 5488.0, 5588.0, 5688.0, 5788.0, 5888.0}, _
        {3.4, 1385.4, 1485.5, 1585.6, 1685.7, 1785.7, 1885.8, 1985.8, 2085.9, 2185.9, 2286.0, 2386.0, 2486.1, 2586.1, 2686.1, 2786.2, 2886.2, 2986.2, 3086.3, 3186.3, 3286.3, 3386.3, 3486.3, 3586.4, 3686.4, 3786.4, 3886.4, 3986.4, 4086.4, 4186.5, 4286.5, 4386.5, 4486.5, 4586.5, 4686.5, 4786.5, 4886.5, 4986.5, 5086.6, 5186.6, 5286.6, 5386.6, 5486.6, 5586.6, 5686.6, 5786.6, 5886.6}, _
        {3.5, 1384.1, 1484.2, 1584.3, 1684.3, 1784.4, 1884.5, 1984.5, 2084.6, 2184.6, 2284.7, 2384.7, 2484.7, 2584.8, 2684.8, 2784.8, 2884.9, 2984.9, 3084.9, 3184.9, 3285.0, 3385.0, 3485.0, 3585.0, 3685.0, 3785.1, 3885.1, 3985.1, 4085.1, 4185.1, 4285.1, 4385.1, 4485.2, 4585.2, 4685.2, 4785.2, 4885.2, 4985.2, 5085.2, 5185.2, 5285.2, 5385.2, 5485.3, 5585.3, 5685.3, 5785.3, 5885.3}, _
        {3.6, 1382.8, 1482.9, 1583.0, 1683.1, 1783.2, 1883.2, 1983.3, 2083.3, 2183.4, 2283.4, 2383.5, 2483.5, 2583.5, 2683.6, 2783.6, 2883.6, 2983.6, 3083.7, 3183.7, 3283.7, 3383.7, 3483.7, 3583.8, 3683.8, 3783.8, 3883.8, 3983.8, 4083.8, 4183.9, 4283.9, 4383.9, 4483.9, 4583.9, 4683.9, 4783.9, 4883.9, 4983.9, 5084.0, 5184.0, 5284.0, 5384.0, 5484.0, 5584.0, 5684.0, 5784.0, 5884.0}, _
        {3.7, 1381.7, 1481.8, 1581.8, 1681.9, 1782.0, 1882.0, 1982.1, 2082.1, 2182.2, 2282.2, 2382.3, 2482.3, 2582.3, 2682.4, 2782.4, 2882.4, 2982.5, 3082.5, 3182.5, 3282.5, 3382.5, 3482.6, 3582.6, 3682.6, 3782.6, 3882.6, 3982.6, 4082.7, 4182.7, 4282.7, 4382.7, 4482.7, 4582.7, 4682.7, 4782.7, 4882.7, 4982.8, 5082.8, 5182.8, 5282.8, 5382.8, 5482.8, 5582.8, 5682.8, 5782.8, 5882.8}, _
        {3.8, 1380.5, 1480.6, 1580.7, 1680.8, 1780.9, 1880.9, 1981.0, 2081.0, 2181.1, 2281.1, 2381.1, 2481.2, 2581.2, 2681.2, 2781.3, 2881.3, 2981.3, 3081.4, 3181.4, 3281.4, 3381.4, 3481.4, 3581.5, 3681.5, 3781.5, 3881.5, 3981.5, 4081.5, 4181.5, 4281.6, 4381.6, 4481.6, 4581.6, 4681.6, 4781.6, 4881.6, 4981.6, 5081.6, 5181.6, 5281.7, 5381.7, 5481.7, 5581.7, 5681.7, 5781.7, 5881.7}, _
        {3.9, 1379.5, 1479.6, 1579.7, 1679.7, 1779.8, 1879.9, 1979.9, 2080.0, 2180.0, 2280.0, 2380.1, 2480.1, 2580.2, 2680.2, 2780.2, 2880.2, 2980.3, 3080.3, 3180.3, 3280.3, 3380.3, 3480.4, 3580.4, 3680.4, 3780.4, 3880.4, 3980.4, 4080.5, 4180.5, 4280.5, 4380.5, 4480.5, 4580.5, 4680.5, 4780.5, 4880.5, 4980.6, 5080.6, 5180.6, 5280.6, 5380.6, 5480.6, 5580.6, 5680.6, 5780.6, 5880.6}, _
        {4.0, 1378.5, 1478.6, 1578.7, 1678.7, 1778.8, 1878.9, 1978.9, 2079.0, 2179.0, 2279.0, 2379.1, 2479.1, 2579.1, 2679.2, 2779.2, 2879.2, 2979.2, 3079.3, 3179.3, 3279.3, 3379.3, 3479.4, 3579.4, 3679.4, 3779.4, 3879.4, 3979.4, 4079.4, 4179.5, 4279.5, 4379.5, 4479.5, 4579.5, 4679.5, 4779.5, 4879.5, 4979.5, 5079.5, 5179.6, 5279.6, 5379.6, 5479.6, 5579.6, 5679.6, 5779.6, 5879.6}}

        Dim r As Integer, c As Integer
        Dim found As Boolean
        Dim returnvals As threevals

        returnvals.f = 0
        returnvals.fcr = 0
        returnvals.startf = 0

        found = False

        f = Math.Round(f / 100, 0, MidpointRounding.AwayFromZero) * 100 ' round to nearest 100
        found = False
        For c = 1 To UBound(table, 2)
            If f = table(0, c) Then
                found = True
                Exit For
            End If
        Next
        If Not found Then
            Return returnvals
        End If

        fcr = Math.Round(fcr, 1, MidpointRounding.AwayFromZero) ' round to nearest .1
        found = False
        For r = 1 To UBound(table, 1)
            If fcr = table(r, 0) Then
                found = True
                Exit For
            End If
        Next
        If Not found Then
            Return returnvals
        End If

        returnvals.f = f
        returnvals.fcr = fcr
        returnvals.startf = table(r, c)

        Return returnvals

    End Function
    Private Function SaveXML(ByVal method As Integer) As Boolean 'method: 0=Save 1=SaveAs

        Dim rmses(1, 7, 64) As Double
        Dim peaks(1, 7, 64) As Double
        Dim valleys(1, 7, 64) As Double

        Dim recd(1, 64) As Double
        Dim recd1(1, 8)
        Dim mpo(1, 64) As Double
        Dim thresholds(1, 8) As Double
        Dim levels(1, 7) As Double
        Dim IOx() As Double, IOy() As Double
        Dim temp As String, temp1 As String, temp2 As String
        Dim testname As String, internalname As String, stimlevel As String, xmlname As String, stimulustype As String
        Dim c As Integer, r As Integer, sessno As String, i As Integer, k As Integer, ear As Integer, idx As Integer
        Dim dBvalues() As Double
        Dim freqvalues() As Double
        Dim dBvalues12(twelfth.Count - 1) As Double
        Const QUOTE = """"
        Dim ranges() As String = {"soft50", "soft55", "avg60", "avg65", "avg70", "loud75"}
        Dim ThreshTable(1) As DataTable
        Dim HAstyle(1) As String
        Dim StmType(1) As String
        Dim sttype(1) As String
        Dim sidename() As String = {"left", "right"}
        'Dim corr(,) As Double = { _
        '       {14, 5.5, 2, 0, 2, 3, 3.5, 5.5, 2}, _
        '       {26.5, 13.5, 8.5, 7.5, 7.5, 11, 9.5, 10.5, 13.5}}
        Dim corr(,) As Double = { _
            {14.5, 6.2, 2.5, 1.3, 2.5, 5.9, 5, 2, 3}, _
            {17.5, 10.2, 8.5, 9.3, 9.5, 12.9, 13, 15, 16}}

        'temp = Me.txtSessionNo.Text.ToString.Trim
        'If Not Integer.TryParse(temp, i) Then
        '   sessno = "1"
        'Else
        '   sessno = temp
        'End If
        sessno = 1

        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)

        xmlname = Me.lblXMLname.Text

        HAstyle(0) = ""
        HAstyle(1) = ""
        StmType(0) = ""
        StmType(1) = ""
        sttype(0) = ""
        sttype(1) = ""

        Array.Clear(rmses, 0, rmses.Length)
        Array.Clear(peaks, 0, peaks.Length)
        Array.Clear(valleys, 0, valleys.Length)
        Array.Clear(mpo, 0, mpo.Length)
        Array.Clear(thresholds, 0, thresholds.Length)
        Array.Clear(levels, 0, levels.Length)
        Array.Clear(recd, 0, recd.Length)
        Array.Clear(recd1, 0, recd1.Length)

        ThreshTable(0) = LThreshTable
        ThreshTable(1) = RThreshTable

        ' Copy values from tables, interpolating rmses and mpo to 12th octave,
        ' collecting available levels

        For ear = 0 To 1

            ' Get thresholds
            temp1 = ""
            k = 0
            For c = 0 To ThreshTable(ear).Columns.Count - 1
                temp2 = Trim$(ThreshTable(ear).Rows(0).Item(c).ToString)
                If Len(temp2) = 0 Then
                    thresholds(ear, c) = -1000.0
                Else
                    thresholds(ear, c) = Val(temp2)
                    k = k + 1
                End If
            Next

            ' rmses
            For r = 1 To 6
                k = 0
                Dim tempy As String
                tempy = ""
                For c = 0 To ThreshTable(ear).Columns.Count - 1
                    temp2 = Trim(ThreshTable(ear).Rows(r).Item(c).ToString)
                    If Len(temp2) > 0 Then 'skip over missing values
                        ReDim Preserve dBvalues(k)
                        ReDim Preserve freqvalues(k)
                        dBvalues(k) = Val(temp2)
                        freqvalues(k) = audiometric(c)
                        k = k + 1
                        tempy = tempy & temp2 & " "
                    End If
                Next
                If k > 0 Then
                    Debug.Print(tempy)
                    dBvalues12 = interp1(freqvalues, dBvalues, twelfth)
                    For i = 0 To UBound(dBvalues12)
                        rmses(ear, r - 1, i) = dBvalues12(i)
                    Next
                    levels(ear, r - 1) = Val(Microsoft.VisualBasic.Left(ThreshRowHeaders(r), 2))
                Else
                    levels(ear, r - 1) = 0.0
                End If
            Next

            ' MPO
            r = 7
            k = 0
            For c = 0 To ThreshTable(ear).Columns.Count - 1
                temp2 = Trim(ThreshTable(ear).Rows(r).Item(c).ToString)
                If Len(temp2) > 0 Then 'skip over missing values
                    ReDim Preserve dBvalues(k)
                    ReDim Preserve freqvalues(k)
                    dBvalues(k) = Val(temp2)
                    freqvalues(k) = audiometric(c)
                    k = k + 1
                End If
            Next
            If k > 0 Then
                dBvalues12 = interp1(freqvalues, dBvalues, twelfth)
                For i = 0 To UBound(dBvalues12)
                    mpo(ear, i) = dBvalues12(i)
                Next
            Else
                For i = 0 To UBound(mpo, 2)
                    mpo(ear, i) = -1000.0
                Next
            End If

            ' RECD
            r = 8
            k = 0
            For c = 0 To ThreshTable(ear).Columns.Count - 1
                temp2 = Trim(ThreshTable(ear).Rows(r).Item(c).ToString)
                If Len(temp2) > 0 Then 'skip over missing values 
                    recd1(ear, c) = Val(temp2)
                    ReDim Preserve dBvalues(k)
                    ReDim Preserve freqvalues(k)
                    dBvalues(k) = Val(temp2)
                    freqvalues(k) = audiometric(c)
                    k = k + 1
                Else
                    recd1(ear, c) = -1000.0
                End If
            Next
            For r = 0 To Me.cmbAge.Items.Count - 1
                temp = Me.cmbAge.Items(r).ToString
                For c = -1 To ThreshTable(ear).Columns.Count - 2
                    temp = temp & " " & RECDbyAge(r, c).ToString
                Next
                Debug.Print(temp)
            Next
            'If k > 0 Then
            '    dBvalues12 = interp1(freqvalues, dBvalues, twelfth)
            '    For i = 0 To UBound(dBvalues12)
            '        recd(ear, i) = dBvalues12(i)
            '    Next
            'End If
        Next

        ' Create I/O function at each rms point, compute new min, max using I/O function
        For ear = 0 To 1
            For i = 0 To UBound(rmses, 3)
                If twelfth(i) = 250 Then
                    Debug.Print("250")
                End If
                k = 0
                For j = 0 To UBound(levels, 2)
                    If levels(ear, j) <> 0 Then
                        ReDim Preserve IOx(k)
                        ReDim Preserve IOy(k)
                        IOx(k) = levels(ear, j)
                        IOy(k) = rmses(ear, j, i)
                        k = k + 1
                    End If
                Next j
                If k > 0 Then
                    For r = 1 To 6
                        If levels(ear, r - 1) <> 0 Then
                            peaks(ear, r - 1, i) = LeastSquaresPoint(IOx, IOy, levels(ear, r - 1) + 15)
                            valleys(ear, r - 1, i) = LeastSquaresPoint(IOx, IOy, levels(ear, r - 1) - 15)
                        End If
                    Next
                End If
            Next i

        Next

        ' Print the results

        Dim corrindex As Integer
        Dim thr As Double

        ' Get save filename
        If method = 0 Then 'Save
            If xmlname.Length = 0 Then
                xmlname = HomeDir & "\Untitled.xml"
                method = 1 'Force SaveAs if name was blank
            End If
        End If
        If method = 1 Then 'SaveAs
            If xmlname.Length = 0 Then
                xmlname = HomeDir & "\Untitled.xml"
            End If
            SaveFD.InitialDirectory = Path.GetDirectoryName(xmlname)
            SaveFD.Title = "Save As a Verifit style XML file"
            SaveFD.Filter = "Verifit XML files (*.xml) | *.xml"
            SaveFD.FilterIndex = 0
            Dim result1 As DialogResult = SaveFD.ShowDialog()
            If result1 = DialogResult.Cancel Then
                Return False
            End If
            xmlname = SaveFD.FileName
        End If

        Dim objWriter As New System.IO.StreamWriter(xmlname)

        objWriter.WriteLine("<?xml version=""1.0""?>")
        temp = "<session SessionID=" & QUOTE & sessno & QUOTE & " ClientID=" & QUOTE & Me.txtClientID.Text & QUOTE & " date=" & QUOTE & Me.DOTCtl.Value.ToString("MM/dd/yyyy") & QUOTE & ">"
        objWriter.WriteLine(temp)
        objWriter.WriteLine(" <equipment model=""SharpEntered"" serial=""SharpEntered"" xmlformat=""1.1"">")
        Model = "SharpEntered"
        objWriter.WriteLine(" </equipment>")
        objWriter.WriteLine("<test name=""frequencies"">")
        objWriter.WriteLine(" <data name=""12ths"" xunit=""Hz"" xscale=""12th"">200.0 210.0 225.0 235.0 250.0 265.0 280.0 300.0 315.0 335.0 355.0 375.0 400.0 420.0 450.0 470.0 500.0 530.0 560.0 595.0 630.0 670.0 710.0 750.0 800.0 840.0 900.0 945.0 1000.0 1060.0 1120.0 1190.0 1250.0 1335.0 1400.0 1500.0 1600.0 1680.0 1800.0 1890.0 2000.0 2120.0 2240.0 2380.0 2500.0 2670.0 2800.0 3000.0 3150.0 3365.0 3550.0 3775.0 4000.0 4240.0 4500.0 4760.0 5000.0 5340.0 5600.0 6000.0 6300.0 6725.0 7100.0 7550.0 8000.0</data>")
        objWriter.WriteLine(" <data name=""audiometric"" xunit=""Hz"" xscale=""audio"">250.0 500.0 750.0 1000.0 1500.0 2000.0 3000.0 4000.0 6000.0</data>")
        objWriter.WriteLine(" <data name=""3rds"" xunit=""Hz"" xscale=""3rd"">200.0 250.0 315.0 400.0 500.0 630.0 800.0 1000.0 1250.0 1600.0 2000.0 2500.0 3150.0 4000.0 5000.0 6300.0 8000.0</data>")
        objWriter.WriteLine("</test>")

        Dim agestr() As String
        agestr = Me.cmbAge.SelectedItem.ToString.Trim.ToLower.Split
        If agestr.Count = 2 Then
            temp = agestr(1) & agestr(0)
        Else
            temp = agestr(0)
        End If

        objWriter.WriteLine("<test name=""audiometry"" age=" & QUOTE & temp & QUOTE & ">")
        objWriter.WriteLine("</test>")

        HAstyle(0) = Me.cmbStyleL.SelectedItem.ToString
        HAstyle(1) = Me.cmbStyleR.SelectedItem.ToString
        StmType(0) = Me.cmbSpeechTypeL.SelectedItem.ToString
        StmType(1) = Me.cmbSpeechTypeR.SelectedItem.ToString
        sttype(0) = StimType(Me.cmbSpeechTypeL.SelectedIndex)
        sttype(1) = StimType(Me.cmbSpeechTypeR.SelectedIndex)

        Dim transstr As String
        If cmbTransducer.SelectedIndex = 0 Then
            transstr = "insertfoam"
        Else
            transstr = "headphone"
        End If
        temp = "<test name=""speechmap"" transducer=" & QUOTE & transstr & QUOTE & ">"
        objWriter.WriteLine(temp)
        temp = "</test>"
        objWriter.WriteLine(temp)

        For ear = 0 To 1
            stimulustype = QUOTE & StmType(ear) & QUOTE
            temp = "<test name=""speechmap"" side=" & QUOTE & sidename(ear) & QUOTE & " HI_Type=" & QUOTE & HAstyle(ear) & QUOTE & " reservegain=""10db"" stim_type=" & stimulustype & ">"
            objWriter.WriteLine(temp)
            stimulustype = QUOTE & sttype(ear) & QUOTE

            For r = 1 To 6
                If levels(ear, r - 1) <> 0.0 Then
                    testname = QUOTE & "test" & Trim$(Str$(r)) & "_on-ear" & QUOTE

                    internalname = QUOTE & "map_rearspl" & Trim$(Str$(r)) & "u" & QUOTE
                    temp = " <data name=" & testname & " yunit=""dBspl"" envelope=""peaks"" xscale=""12th"" xunit=""Hz"" internal=" & internalname & ">"
                    temp1 = ""
                    For c = 0 To UBound(rmses, 3)
                        temp1 = temp1 & Format(peaks(ear, r - 1, c), "##0.0") & " "
                    Next
                    temp = temp & temp1 & "</data>"
                    objWriter.WriteLine(temp)

                    stimlevel = QUOTE & ranges(r - 1) & QUOTE
                    internalname = QUOTE & "map_rearspl" & Trim$(Str$(r)) & QUOTE
                    temp = " <data name=" & testname & " yunit=""dBspl"" xscale=""12th"" xunit=""Hz"" display=""show"" envdisplay=""show"" stim_type=" & stimulustype & " stim_level=" & stimlevel & " internal=" & internalname & ">"
                    temp1 = ""
                    For c = 0 To UBound(rmses, 3)
                        temp1 = temp1 & Format(rmses(ear, r - 1, c), "##0.0") & " "
                    Next
                    temp = temp & temp1 & "</data>"
                    objWriter.WriteLine(temp)

                    internalname = QUOTE & "map_rearspl" & Trim$(Str$(r)) & "l" & QUOTE
                    temp = " <data name=" & testname & " yunit=""dBspl"" envelope=""valleys"" xscale=""12th"" xunit=""Hz"" internal=" & internalname & ">"
                    temp1 = ""
                    For c = 0 To UBound(rmses, 3)
                        temp1 = temp1 & Format(valleys(ear, r - 1, c), "##0.0") & " "
                    Next
                    temp = temp & temp1 & "</data>"
                    objWriter.WriteLine(temp)
                End If
            Next

            ' MPO
            r = 7
            testname = QUOTE & "test" & Trim$(Str$(r)) & "_on-ear" & QUOTE
            internalname = QUOTE & "map_rearspl" & Trim$(Str$(r)) & QUOTE
            temp = " <data name=" & testname & " yunit=""dBspl"" xscale=""12th"" xunit=""Hz"" display=""show"" envdisplay=""hide"" stim_type=""mpo"" mpo_level=""85"" vdisplay=""show"" venvdisplay=""hide"" internal=" & internalname & ">"
            temp1 = ""
            For c = 0 To UBound(mpo, 2)
                If mpo(ear, c) = -1000.0 Then
                    temp2 = "_"
                Else
                    temp2 = Format(mpo(ear, c), "##0.0")
                End If
                temp1 = temp1 & temp2 & " "
            Next
            temp = temp & temp1 & "</data>"
            objWriter.WriteLine(temp)

            ' threshold
            corrindex = Me.cmbTransducer.SelectedIndex '0 = HA2 w rigid tube for insert, 1 = phones TDH 49/50

            ' threshold in SPL
            temp = " <data name=""threshold"" yunit=""dBspl"" xunit=""Hz"" xscale=""audio""> "
            temp1 = ""
            For c = 0 To UBound(thresholds, 2)
                If thresholds(ear, c) = -1000.0 Then
                    temp2 = "_"
                Else
                    thr = thresholds(ear, c) + corr(corrindex, c) 'convert HL to SPL
                    If corrindex = 0 Then
                        If recd1(ear, c) = -1000.0 Then
                            thr = thr + RECDbyAge(cmbAge.SelectedIndex, c)
                        Else
                            thr = thr + recd1(ear, c)
                        End If
                    End If
                    temp2 = Format(thr, "##0.0")
                End If
                temp1 = temp1 & temp2 & " "
            Next
            temp = temp & temp1 & "</data>"
            objWriter.WriteLine(temp)
            ' threshold in HL
            temp = " <data name=""threshold"" yunit=""dBhl"" xunit=""Hz"" xscale=""audio""> "
            temp1 = ""
            For c = 0 To UBound(thresholds, 2)
                If thresholds(ear, c) = -1000.0 Then
                    temp2 = "_"
                Else
                    temp2 = Format(thresholds(ear, c), "##0.0")
                End If
                temp1 = temp1 & temp2 & " "
            Next
            temp = temp & temp1 & "</data>"
            objWriter.WriteLine(temp)
            ' RECD
            temp = " <data name=""recd"" yunit=""dBspl"" xunit=""Hz"" xscale=""audio""> "
            temp1 = ""
            For c = 0 To UBound(thresholds, 2)
                If recd1(ear, c) = -1000.0 Then
                    temp2 = "_"
                Else
                    temp2 = Format(recd1(ear, c), "##0.0")
                End If
                temp1 = temp1 & temp2 & " "
            Next
            temp = temp & temp1 & "</data>"
            objWriter.WriteLine(temp)
            objWriter.WriteLine("</test>")
        Next

        objWriter.WriteLine("</session>")
        objWriter.Close()
        Me.lblXMLname.Text = xmlname
        Me.lblXMLname.ForeColor = Color.DarkBlue
        Changed.Checked = False
        If String.Compare(SavedXMLname, xmlname.Trim) <> 0 Then
            Me.FileRecentFilesFilename.Text = SavedXMLname
        End If
        SavedXMLname = ""
        If Len(Me.lblXMLname.Text) = 0 Then
            Return True
        End If
        Call DoPlot()
        Changed.Checked = False
        Return True
    End Function

    Private Sub SaveParameters()
        Const QUOTE = """"
        Dim temp As String, prmfilename As String
        Dim lfcc As String, lfcr As String, rfcc As String, rfcr As String
        If Len(Me.lblXMLname.Text) = 0 Then
            Exit Sub
        End If

        temp = Trim(Me.txtLFCC.Text) & Trim(Me.txtLFCR.Text) & Trim(Me.txtRFCC.Text) & Trim(Me.txtRFCR.Text) & _
               Trim(Me.txtLFCC.Tag) & Trim(Me.txtLFCR.Tag) & Trim(Me.txtRFCC.Tag) & Trim(Me.txtRFCR.Tag)

        If chkLFreqComp.Checked Then
            lfcc = txtLFCC.Text
            lfcr = txtLFCR.Text
        Else
            lfcc = txtLFCC.Tag
            lfcr = txtLFCR.Tag
        End If
        If chkRFreqComp.Checked Then
            rfcc = txtRFCC.Text
            rfcr = txtRFCR.Text
        Else
            rfcc = txtRFCC.Tag
            rfcr = txtRFCR.Tag
        End If
        prmfilename = Path.ChangeExtension(Me.lblXMLname.Text, ".prm")
        If File.Exists(prmfilename) Or Len(temp) > 0 Then
            Dim sw As System.IO.StreamWriter = Nothing

            Try
                sw = New System.IO.StreamWriter(prmfilename, False)

                temp = "LFC=" & QUOTE & chkLFreqComp.CheckState.ToString & QUOTE & " " & _
                    "RFC=" & QUOTE & chkRFreqComp.CheckState.ToString & QUOTE & " " & _
                    "LFCC=" & QUOTE & lfcc & QUOTE & " " & _
                    "LFCR=" & QUOTE & lfcr & QUOTE & " " & _
                    "RFCC=" & QUOTE & rfcc & QUOTE & " " & _
                    "RFCR=" & QUOTE & rfcr & QUOTE
                sw.WriteLine(temp)
            Catch e As Exception
                MessageBox.Show("Error writing parameter file:" & vbCrLf & prmfilename & vbCrLf & "with message:" & vbCrLf & e.Message)
            Finally
                sw.Close()
            End Try
        End If
    End Sub
    Private Sub LoadParameters()
        Const QUOTE = """"
        Dim temp As String, temp1 As String, prmfilename As String, parts() As String, idx As Integer
        If Len(Me.lblXMLname.Text) = 0 Then
            Exit Sub
        End If
        Me.txtLFCC.Text = ""
        Me.txtLFCR.Text = ""
        Me.txtRFCC.Text = ""
        Me.txtRFCR.Text = ""
        Me.chkLFreqComp.Checked = False
        Me.chkRFreqComp.Checked = False

        prmfilename = Path.ChangeExtension(Me.lblXMLname.Text, ".prm")

        If File.Exists(prmfilename) Then
            Dim sr As IO.StreamReader = Nothing
            Try
                sr = New IO.StreamReader(prmfilename)
                temp1 = sr.ReadLine()
                parts = temp1.Split
                If parts.Count = 6 Then
                    idx = parts(0).IndexOf("LFC=") + 5
                    temp = parts(0).Substring(idx, parts(0).Length - idx - 1)
                    If temp.StartsWith("Checked") Then
                        chkLFreqComp.Tag = True 'tells chkfreqcomp.changed event not to plot, to prevent plotting twice
                        Me.chkLFreqComp.Checked = True
                        chkLFreqComp.Tag = False
                    End If
                    idx = parts(1).IndexOf("RFC=") + 5
                    temp = parts(1).Substring(idx, parts(1).Length - idx - 1)
                    If temp.StartsWith("Checked") Then
                        chkRFreqComp.Tag = True 'tells chkfreqcomp.changed event not to plot, to prevent plotting twice
                        Me.chkRFreqComp.Checked = True
                        chkRFreqComp.Tag = False
                    End If
                    idx = parts(2).IndexOf("LFCC=") + 6
                    temp = parts(2).Substring(idx, parts(2).Length - idx - 1)
                    If Me.chkLFreqComp.Checked = True Then
                        Me.txtLFCC.Text = temp
                        Me.txtLFCC.Tag = temp
                    Else
                        Me.txtLFCC.Text = ""
                        Me.txtLFCC.Tag = temp
                    End If
                    idx = parts(3).IndexOf("LFCR=") + 6
                    temp = parts(3).Substring(idx, parts(3).Length - idx - 1)
                    If Me.chkLFreqComp.Checked = True Then
                        Me.txtLFCR.Text = temp
                        Me.txtLFCR.Tag = temp
                    Else
                        Me.txtLFCR.Text = ""
                        Me.txtLFCR.Tag = temp
                    End If
                    idx = parts(4).IndexOf("RFCC=") + 6
                    temp = parts(4).Substring(idx, parts(4).Length - idx - 1)
                    If Me.chkRFreqComp.Checked = True Then
                        Me.txtRFCC.Text = temp
                        Me.txtRFCC.Tag = temp
                    Else
                        Me.txtRFCC.Text = ""
                        Me.txtRFCC.Tag = temp
                    End If
                    idx = parts(5).IndexOf("RFCR=") + 6
                    temp = parts(5).Substring(idx, parts(5).Length - idx - 1)
                    If Me.chkRFreqComp.Checked = True Then
                        Me.txtRFCR.Text = temp
                        Me.txtRFCR.Tag = temp
                    Else
                        Me.txtRFCR.Text = ""
                        Me.txtRFCR.Tag = temp
                    End If
                End If
            Catch e As Exception
                MessageBox.Show("Error reading parameter file:" & vbCrLf & prmfilename & vbCrLf & "with message:" & vbCrLf & e.Message)
            Finally
                sr.Close()
            End Try
        End If
    End Sub

    Private Sub LockMenuItems()
        Me.FileEditMenu.Enabled = False
        Me.FileNewMenu.Enabled = False
        Me.FileOpenMenu.Enabled = False
        Me.FileSaveMenu.Enabled = True
        Me.FileSaveAsMenu.Enabled = True
        Me.FileRecentFilesMenu.Enabled = False
        Me.FileExitMenu.Enabled = False
        Me.SettingsMenu.Enabled = False
        Me.PlotMenu.Enabled = False
        Me.NumbersMenu.Enabled = False
        Me.HelpMenu.Enabled = False
    End Sub
    Private Sub UnlockMenuItems()
        If Len(Me.lblXMLname.Text) > 0 And StrComp(Model, "SharpEntered") = 0 Then
            Me.FileEditMenu.Enabled = True
        End If
        Me.FileNewMenu.Enabled = True
        Me.FileOpenMenu.Enabled = True
        Me.FileSaveMenu.Enabled = False
        Me.FileSaveAsMenu.Enabled = False
        Me.FileRecentFilesMenu.Enabled = True
        Me.FileExitMenu.Enabled = True
        Me.SettingsMenu.Enabled = True
        Me.PlotMenu.Enabled = True
        Me.NumbersMenu.Enabled = True
        Me.HelpMenu.Enabled = True
    End Sub
    'Private Sub RefreshRowHeaders()
    '    'Private Sub frmEntry_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
    '    If Me.Tag = "virgin" Then
    '        Debug.Print(Me.Tag)
    '        For r = 0 To RThreshGrid.Rows.Count - 1
    '            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
    '        Next
    '        For r = 0 To LThreshGrid.Rows.Count - 1
    '            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
    '        Next
    '    End If
    '    Me.Tag = ""
    'End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub cmbMFC_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbMFC.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
    End Sub


    Private Sub FileOpenMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileOpenMenu.Click
        Dim xmlname As String

        Call SaveParameters()

        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    Exit Sub
                Case vbYes
                    Call SaveXML(1)
            End Select
        End If

        xmlname = Me.lblXMLname.Text.Trim
        If xmlname.Length = 0 Then
            OpenFD.InitialDirectory = HomeDir
        Else
            OpenFD.InitialDirectory = Path.GetDirectoryName(xmlname)
        End If
        OpenFD.Title = "Open a Verifit XML file"
        OpenFD.Filter = "Verifit files (*.xml) | *.xml"
        OpenFD.FilterIndex = 0
        OpenFD.FileName = "*.xml"
        Dim result1 As DialogResult = OpenFD.ShowDialog()
        If result1 = DialogResult.Cancel Then
            Exit Sub
        End If
        Me.lblXMLname.Text = OpenFD.FileName
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call LoadParameters()
        Call DoPlot()
        If xmlname.Length > 0 Then
            Me.FileRecentFilesFilename.Text = xmlname
        End If

        Me.Changed.Checked = False
    End Sub


    Private Sub PlotPrintMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlotPrintMenu.Click
        zgc.DoPrint()
    End Sub

    Private Sub FileNewMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileNewMenu.Click
        Dim r As Integer

        Call SaveParameters()

        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    Exit Sub
                Case vbYes
                    Call SaveXML(1)
            End Select
        End If

        Call LockMenuItems()
        SavedXMLname = Me.lblXMLname.Text
        Me.lblXMLname.Text = ""
        Call ClearEntryPanel()
        Me.txtLFCC.Text = ""
        Me.txtLFCR.Text = ""
        Me.txtRFCC.Text = ""
        Me.txtRFCR.Text = ""
        Me.chkLFreqComp.Checked = False
        Me.chkRFreqComp.Checked = False
        PlotPanel.Visible = False
        EditPanel.Visible = True
        Me.butFill.Visible = True
        For r = 0 To RThreshGrid.Rows.Count - 1
            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next
        For r = 0 To RThreshGrid.Rows.Count - 1
            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next

    End Sub

    Private Sub HelpAboutMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpAboutMenu.Click
        About.ShowDialog()
    End Sub

    Private Sub SettingsFilenameMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsFilenameMenu.Click
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        DoPlot()
    End Sub


    Private Sub butSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butSaveAs.Click
        If Not CheckEntries() Then
            Exit Sub
        End If
        If Not SaveXML(0) Then
            Exit Sub
        End If
        EditPanel.Visible = False
        PlotPanel.Visible = True
        Call UnlockMenuItems()
    End Sub


    Private Sub NumbersMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumbersMenu.Click
        Me.gpConditions.Select() ' force move away from FCR or FCC fields, in case not entered fully yet

        Debug.Print("")
        Debug.Print("ClientID: " & ClientID)

        Dim S As String
        For ear = 0 To 1
            Debug.Print("ear: " & earname(ear))
            S = ""
            For j = 0 To UBound(twelfth)
                S = S & Convert.ToString(twelfth(j)) & " "
            Next
            Debug.Print("freqs: " & S)
            For i = 0 To ranges.Count
                'peaks
                S = ""
                For j = 0 To UBound(peaks, 3)
                    S = S & Convert.ToString(peaks(ear, i, j)) & " "
                Next
                Debug.Print("peak: " & S)

                'rmses
                S = ""
                For j = 0 To UBound(rmses, 3)
                    S = S & Convert.ToString(rmses(ear, i, j)) & " "
                Next
                Debug.Print("rms: " & S)

                'valleys
                S = ""
                For j = 0 To UBound(valleys, 3)
                    S = S & Convert.ToString(valleys(ear, i, j)) & " "
                Next
                Debug.Print("valley: " & S)
            Next

            'mpo
            S = ""
            For j = 0 To UBound(mpo, 2)
                S = S & Convert.ToString(mpo(ear, j)) & " "
            Next
            Debug.Print("mpo: " & S)

            'threshold
            S = ""
            For j = 0 To UBound(thresholds, 2)
                S = S & Convert.ToString(thresholds(ear, j)) & " "
            Next
            Debug.Print("threshold: " & S)
        Next ear

        NumberZ.Show()
        Call ShowNumbers()

    End Sub

    Private Sub butDontSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDontSave.Click
        EditPanel.Visible = False
        PlotPanel.Visible = True
        If Len(Me.lblXMLname.Text) = 0 Then
            Me.lblXMLname.Text = SavedXMLname
        End If
        Call Extract(Me.lblXMLname.Text, 0) 'undo any changes by copying in last version of file
        Me.Changed.Checked = False
        Call UnlockMenuItems()
    End Sub

    Private Sub FileExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExitMenu.Click
        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    Exit Sub
                Case vbYes
                    Call SaveXML(1)
            End Select
        End If
        Call SaveParameters()
        My.Settings.RecentFile = Me.lblXMLname.Text
        If Me.SettingsFilenameMenu.Checked Then
            My.Settings.ShowFileName = True
        Else
            My.Settings.ShowFileName = False
        End If
        My.Settings.GraphStyle = Me.SettingsStyleCombo.SelectedItem.ToString
        If Me.SettingsShowSIIPointsMenu.Checked Then
            My.Settings.ShowSIIpoints = True
        Else
            My.Settings.ShowSIIpoints = False
        End If
        End
    End Sub

    Private Sub FileEditMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileEditMenu.Click
        Call LockMenuItems()
        Call SaveParameters()
        PlotPanel.Visible = False
        EditPanel.Visible = True
        Me.butFill.Visible = False
        For r = 0 To RThreshGrid.Rows.Count - 1
            RThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
            LThreshGrid.Rows(r).HeaderCell.Value = ThreshRowHeaders(r)
        Next
        RThreshGrid.CurrentCell = RThreshGrid.Rows(0).Cells(0) ' park at first cell
        RThreshGrid.CurrentCell = RThreshGrid.Rows(0).Cells(0) ' park at first cell
    End Sub

    Private Sub Sharp_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Me.Panel1.Width = Me.Width
        Me.Panel1.Top = Me.Height - 80
        Me.lblXMLname.Width = Me.Panel1.Width
    End Sub

    'Protected Overrides Sub Finalize()
    '    MyBase.Finalize()
    'End Sub

    Private Sub PlotFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlotFileMenu.Click
        Dim xmlname As String
        Dim s As String, ext As String

        ' Get image SaveAs filename
        xmlname = Me.lblXMLname.Text
        If xmlname.Length = 0 Then
            SaveFD.InitialDirectory = HomeDir
        Else
            SaveFD.InitialDirectory = Path.GetDirectoryName(xmlname)
        End If
        s = "Bitmap (BMP) | *.bmp" & _
            " | Enhanced metafile (EMF) | *.emf" & _
            " | Exchangeable Image File (Exif) | *.exif" & _
            " | Graphics Interchange Format (GIF) | *.gif" & _
            " | Joint Photographic Experts Group (JPEG) | .jpg" & _
            " | W3C Portable Network Graphics (PNG) | .png" & _
            " | Tagged Image File Format (TIFF) | .tiff" & _
            " | Windows metafile (WMF) | .wmf"
        SaveFD.Title = "Print Image to an image file"
        SaveFD.Filter = s
        SaveFD.FilterIndex = 0
        SaveFD.FileName = "Untitled"
        Dim result1 As DialogResult = SaveFD.ShowDialog()
        If result1 = DialogResult.Cancel Then
            Exit Sub
        End If
        ext = Path.GetExtension(SaveFD.FileName)
        Dim myPane As GraphPane = zgc.GraphPane
        myPane.GetImage().Save(SaveFD.FileName, ParseImageFormat(ext))
    End Sub
    Private Function ParseImageFormat(ByVal type As String) As System.Drawing.Imaging.ImageFormat

        Select Case type.ToLower()

            Case "jpg"
                Return System.Drawing.Imaging.ImageFormat.Jpeg
            Case "bmp"
                Return System.Drawing.Imaging.ImageFormat.Bmp
            Case "gif"
                Return System.Drawing.Imaging.ImageFormat.Gif
            Case "png"
                Return System.Drawing.Imaging.ImageFormat.Png
            Case "tiff"
                Return System.Drawing.Imaging.ImageFormat.Tiff
            Case "wmf"
                Return System.Drawing.Imaging.ImageFormat.Wmf
            Case "emf"
                Return System.Drawing.Imaging.ImageFormat.Emf
            Case "exif"
                Return System.Drawing.Imaging.ImageFormat.Exif
            Case Else
                Return System.Drawing.Imaging.ImageFormat.Jpeg

        End Select

    End Function

    Private Sub FileSaveMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSaveMenu.Click
        Call SaveParameters()
        If Not CheckEntries() Then
            Exit Sub
        End If
        Call SaveXML(0)
        EditPanel.Visible = False
        PlotPanel.Visible = True
        Call UnlockMenuItems()
    End Sub

    Private Sub FileSaveAsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSaveAsMenu.Click
        Call SaveParameters()
        If Not CheckEntries() Then
            Exit Sub
        End If
        Call SaveXML(1)
        EditPanel.Visible = False
        PlotPanel.Visible = True
        Call UnlockMenuItems()
    End Sub

    Private Sub LThreshGrid_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles LThreshGrid.CellClick
        LThreshGrid.BeginEdit(True)
    End Sub
    Private Sub ControlChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtClientID.TextChanged, LThreshGrid.CellEndEdit, RThreshGrid.CellEndEdit, DOTCtl.ValueChanged, cmbAge.SelectedIndexChanged, cmbStyleR.SelectedIndexChanged, cmbStyleL.SelectedIndexChanged, cmbSpeechTypeR.SelectedIndexChanged, cmbSpeechTypeL.SelectedIndexChanged, cmbTransducer.SelectedIndexChanged ', txtLFCC.TextChanged, txtLFCR.TextChanged, txtRFCC.TextChanged, txtRFCR.TextChanged
        Me.Changed.Checked = True
    End Sub

    Private Sub butRClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butRClear.Click
        For r = 0 To Me.RThreshTable.Rows.Count - 1
            For c = 0 To Me.RThreshTable.Columns.Count - 1
                Me.RThreshTable.Rows(r).Item(c) = ""
            Next
        Next
    End Sub

    Private Sub butLClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butLClear.Click
        For r = 0 To Me.LThreshTable.Rows.Count - 1
            For c = 0 To Me.LThreshTable.Columns.Count - 1
                Me.LThreshTable.Rows(r).Item(c) = ""
            Next
        Next
    End Sub

    Private Sub butExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butExit.Click
        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    Exit Sub
                Case vbYes
                    If Not CheckEntries() Then
                        Exit Sub
                    End If
                    Call SaveXML(0)
                Case vbNo
                    If Len(Me.lblXMLname.Text) = 0 Then
                        Me.lblXMLname.Text = SavedXMLname
                    End If
                    Extract(Me.lblXMLname.Text, 0) ' restore previous
                    LoadParameters()
                    Me.Changed.Checked = False
            End Select
        Else
            If Len(Me.lblXMLname.Text) = 0 Then
                Me.lblXMLname.Text = SavedXMLname
                LoadParameters()
            End If
        End If

        EditPanel.Visible = False
        PlotPanel.Visible = True
        Call UnlockMenuItems()
    End Sub

    Private Sub Sharp_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    e.Cancel = True
                Case vbYes
                    If Me.EditPanel.Visible Then
                        If Not CheckEntries() Then
                            e.Cancel = True
                            Exit Sub
                        End If
                    End If
                    Call SaveXML(1)
            End Select
        End If
        Call SaveParameters()
        My.Settings.RecentFile = Me.lblXMLname.Text
        If Me.SettingsFilenameMenu.Checked Then
            My.Settings.ShowFileName = True
        Else
            My.Settings.ShowFileName = False
        End If
        My.Settings.GraphStyle = Me.SettingsStyleCombo.SelectedItem.ToString
        If Me.SettingsShowSIIPointsMenu.Checked Then
            My.Settings.ShowSIIpoints = True
        Else
            My.Settings.ShowSIIpoints = False
        End If
    End Sub

    Private Sub butClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butClearAll.Click
        Call ClearEntryPanel()
    End Sub

    Private Sub HelpHelpMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpHelpMenu.Click
        frmManual.Show()
    End Sub

    Private Sub EditPanel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPanel.Click
        If (ModifierKeys And Keys.Control) <> 0 Then
            If butFill.Visible Then
                butFill.Visible = False
            Else
                butFill.Visible = True
            End If
        End If
    End Sub

    Private Sub RThreshGrid_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles RThreshGrid.CellContentClick
        RThreshGrid.BeginEdit(True)
    End Sub

    Private Sub FileRecentFilesFilename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileRecentFilesFilename.Click
        Dim xmlname As String

        Call SaveParameters()
        If Me.FileRecentFilesFilename.Text.Trim.Length = 0 Then
            Exit Sub
        End If
        xmlname = Me.FileRecentFilesFilename.Text.Trim

        Call ForceGridCellEndEdit(Me.LThreshGrid)
        Call ForceGridCellEndEdit(Me.RThreshGrid)
        If Me.Changed.Checked Then
            Dim Result As DialogResult = MessageBox.Show("Entries have changed. Save?", _
                        "File New", _
                        MessageBoxButtons.YesNoCancel, _
                        MessageBoxIcon.Question)
            Select Case Result
                Case vbCancel
                    Exit Sub
                Case vbYes
                    Call SaveXML(1)
            End Select
        End If
        If Not File.Exists(xmlname) Then
            MsgBox("File:" & vbCrLf & xmlname & vbCrLf & "Does not exist.")
            Me.FileRecentFilesFilename.Text = ""
            Exit Sub
        End If

        If Me.lblXMLname.Text.Trim.Length > 0 Then
            Me.FileRecentFilesFilename.Text = Me.lblXMLname.Text.Trim
        End If
        Me.lblXMLname.Text = xmlname
        Call LoadParameters()
        Call DoPlot()
        Me.Changed.Checked = False

    End Sub

    Private Sub chkLFreqComp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkLFreqComp.CheckedChanged
        If chkLFreqComp.Checked Then
            txtLFCC.Text = txtLFCC.Tag
            txtLFCR.Text = txtLFCR.Tag
        Else
            txtLFCC.Tag = txtLFCC.Text
            txtLFCR.Tag = txtLFCR.Text
            txtLFCC.Text = ""
            txtLFCR.Text = ""
        End If
        If chkLFreqComp.Checked Then
            If cmbEar.SelectedIndex = 0 Then
                txtLFCC.Enabled = True
                txtLFCR.Enabled = True
            Else
                txtLFCC.Enabled = False
                txtLFCR.Enabled = False
            End If
        Else
            txtLFCC.Enabled = False
            txtLFCR.Enabled = False
        End If
        If Not chkLFreqComp.Tag Then
            Call DoPlot()
        End If
    End Sub

    Private Sub handlesCR(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtLFCC.KeyDown, txtLFCR.KeyDown, txtRFCC.KeyDown, txtRFCR.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            e.Handled = True
            System.Windows.Forms.SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub SettingsShowSIIPointsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsShowSIIPointsMenu.Click
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        DoPlot()
    End Sub

    Private Sub chkRFreqComp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRFreqComp.CheckedChanged
        If chkRFreqComp.Checked Then
            txtRFCC.Text = txtRFCC.Tag
            txtRFCR.Text = txtRFCR.Tag
        Else
            txtRFCC.Tag = txtRFCC.Text
            txtRFCR.Tag = txtRFCR.Text
            txtRFCC.Text = ""
            txtRFCR.Text = ""
        End If
        If chkRFreqComp.Checked Then
            If cmbEar.SelectedIndex = 1 Then
                txtRFCC.Enabled = True
                txtRFCR.Enabled = True
            Else
                txtRFCC.Enabled = False
                txtRFCR.Enabled = False
            End If
        Else
            txtRFCC.Enabled = False
            txtRFCR.Enabled = False
        End If
        If Not chkRFreqComp.Tag Then
            Call DoPlot()
        End If
    End Sub

    Private Sub txtLFCR_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtLFCR.Validating
        Dim v As Double
        If Len(Trim$(txtLFCR.Text)) = 0 Then
            Call DoPlot()
            Exit Sub
        End If

        If Not IsNumeric(txtLFCR.Text) Then
            MsgBox("FCR must be numeric", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Val(txtLFCR.Text)
        If v < 1.5 Or v > 4.0 Then
            MsgBox("FCR must be in the range 1.5 to 4.0", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Math.Round(v, 1, MidpointRounding.AwayFromZero) ' round to nearest .1
        txtLFCR.Text = Format$(v, "0.0")
        Call DoPlot()
    End Sub

    Private Sub txtRFCR_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtRFCR.Validating
        Dim v As Double
        If Len(Trim$(txtRFCR.Text)) = 0 Then
            Call DoPlot()
            Exit Sub
        End If

        If Not IsNumeric(txtRFCR.Text) Then
            MsgBox("FCR must be numeric", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Val(txtRFCR.Text)
        If v < 1.5 Or v > 4.0 Then
            MsgBox("FCR must be in the range 1.5 to 4.0", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Math.Round(v, 1, MidpointRounding.AwayFromZero) ' round to nearest .1
        txtRFCR.Text = Format$(v, "0.0")
        Call DoPlot()
    End Sub

    Private Sub txtLFCC_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtLFCC.Validating
        Dim v As Double
        If Len(Trim$(txtLFCC.Text)) = 0 Then
            Call DoPlot()
            Exit Sub
        End If

        If Not IsNumeric(txtLFCC.Text) Then
            MsgBox("FCC must be numeric", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Val(txtLFCC.Text)
        If v < 1500 Or v > 6000 Then
            MsgBox("FCC must be in the range 1500 to 6000", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Math.Round(v / 100, 0, MidpointRounding.AwayFromZero) * 100 ' round to nearest 100
        txtLFCC.Text = Trim$(Str$(v))
        Call DoPlot()
    End Sub

    Private Sub txtRFCC_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtRFCC.Validating
        Dim v As Double
        If Len(Trim$(txtRFCC.Text)) = 0 Then
            Call DoPlot()
            Exit Sub
        End If

        If Not IsNumeric(txtRFCC.Text) Then
            MsgBox("FCC must be numeric", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Val(txtRFCC.Text)
        If v < 1500 Or v > 6000 Then
            MsgBox("FCC must be in the range 1500 to 6000", MsgBoxStyle.Information, "Parameter Error")
            e.Cancel = True
            Exit Sub
        End If
        v = Math.Round(v / 100, 0, MidpointRounding.AwayFromZero) * 100 ' round to nearest 100
        txtRFCC.Text = Trim$(Str$(v))
        Call DoPlot()
    End Sub


    'Private Sub zgc_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles zgc.MouseClick

    '    Dim x As Double, y As Double, x1 As Double
    '    Dim i As Integer
    '    Me.zgc.GraphPane.ReverseTransform(New PointF(e.X, e.Y), x, y)

    '    For i = 0 To UBound(meanshifted)
    '        x1 = FreqToX(fsh(i))
    '        If (x1 > x - 0.025) And (x1 < x + 0.025) _
    '            And (meanshifted(i) > y - 2) And (meanshifted(i) < y + 2) Then
    '            MsgBox(fsh(i).ToString & " " & meanshifted(i).ToString)
    '            Exit Sub
    '        End If
    '    Next

    'End Sub

    Private Function zgc_MouseDownEvent(ByVal sender As ZedGraph.ZedGraphControl, ByVal e As System.Windows.Forms.MouseEventArgs) As System.Boolean Handles zgc.MouseDownEvent
        Dim x As Double, y As Double, x1 As Double
        Dim i As Integer
        Dim temp As String

        If SettingsShowSIIPointsMenu.Checked Then
            Me.zgc.GraphPane.ReverseTransform(New PointF(e.X, e.Y), x, y)

            For i = 0 To UBound(meanshifted)
                x1 = FreqToX(fsh(i))
                If (x1 > x - 0.05) And (x1 < x + 0.05) _
                    And (meanshifted(i) > y - 2) And (meanshifted(i) < y + 2) Then
                    Me.lblTip.Left = e.X
                    Me.lblTip.Top = e.Y
                    Me.lblTip.Text = Format(fsh(i), " 0.00") & " Hz" & "  " & Format(meanshifted(i), " 0.00") & " dB "
                    If fsh(i) <> third(i) Then
                        Me.lblTip.Text = " [" & Format(third(i), "0.00") & "] " & Me.lblTip.Text
                    End If
                    Me.lblTip.Visible = True
                    Return True
                    Exit Function
                End If
            Next
        End If
        Return True
    End Function


    Private Function zgc_MouseUpEvent(ByVal sender As ZedGraph.ZedGraphControl, ByVal e As System.Windows.Forms.MouseEventArgs) As System.Boolean Handles zgc.MouseUpEvent
        Me.lblTip.Text = ""
        Me.lblTip.Visible = False
        Return True
    End Function


    'Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '        Dim MyStream As New AudioStream

    '        Do While MyStream.Busy

    '        Loop
    '        MyStream.Close()
    'End Sub

    Private Sub cmbRvS_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbRvS.SelectedIndexChanged
        If Len(Me.lblXMLname.Text) = 0 Then
            Return
        End If
        Call DoPlot()
    End Sub

 
End Class
