﻿Public Class frmManual

    Private Sub frmManual_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim manual As String
        manual = Application.StartupPath & "\SharpManual.pdf"
        'MsgBox(manual)
        AxAcroPDF1.LoadFile(manual)
        'AxAcroPDF1.src = manual 'avoid blocking shared file
    End Sub

    Private Sub frmManual_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        AxAcroPDF1.Top = Me.ClientRectangle.Top
        AxAcroPDF1.Left = Me.ClientRectangle.Left
        AxAcroPDF1.Width = Me.ClientRectangle.Width
        AxAcroPDF1.Height = Me.ClientRectangle.Height
    End Sub
End Class