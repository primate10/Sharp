﻿Public Class frmMyEula

    Private Sub frmMyEula_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim EULApath As String
        If Debugger.IsAttached Then
            Me.rtxtEULA.Text = "Debug mode."
        Else
            EULApath = Application.StartupPath & "\EULA_wannabe.rtf"
            Me.rtxtEula.LoadFile(EULApath, RichTextBoxStreamType.RichText)
        End If
        Me.butAccept.Enabled = False
        Me.chkEULA.Checked = False
    End Sub


    Private Sub chkEULA_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEULA.CheckedChanged
        If chkEULA.Checked Then
            butAccept.Enabled = True
        Else
            butAccept.Enabled = False
        End If
    End Sub

    Private Sub butAccept_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAccept.Click
        Dim EULApath As String
        'MsgBox("EULA started")
        If chkEULA.Checked = True Then
            Me.rtxtEULA.Text = Me.rtxtEULA.Text & "EULA Accepted on " & Format(Now, "General Date")
            EULApath = Application.StartupPath & "\EULA.rtf"
            Me.rtxtEULA.SaveFile(EULApath)
            Me.Close()
            'MsgBox("EULA written to " & EULApath)
        Else
            MsgBox("EULA not accepted.  Sharp program cannot be used until Licensing Agreement accepted.")
            End
        End If
     End Sub

    Private Sub butDecline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDecline.Click
        MsgBox("EULA not accepted.  Sharp program cannot be used until EULA accepted.")
        End
    End Sub
End Class